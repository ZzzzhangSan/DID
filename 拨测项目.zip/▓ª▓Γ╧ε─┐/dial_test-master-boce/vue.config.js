module.exports = {
  // publicPath: '/webTest/',
  publicPath: './',
  configureWebpack: {
    externals: {
        './cptable': 'var cptable'
    }
  }
  // publicPath: '/'
}