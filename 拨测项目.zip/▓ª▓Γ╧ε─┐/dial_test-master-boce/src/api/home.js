import { request } from '../utils/request'
import api from './index'

// export function getToken(query) {
//     return request({
//         url: api.GetToken,
//         method: 'get',
//         params: query
//     })
// }
// export function getUserToken(query) {
//     return request({
//         url: api.GetUserToken,
//         method: 'get',
//         params: query
//     })
// }

// export function getPCDeviceState() {
//     return request({
//         url: api.GetPCDeviceState,
//         method: 'get',
//     })
// }
// export function getPCStatisticsMap() {
//     return request({
//         url: api.GetPCStatisticsMap,
//         method: 'get',
//     })
// }