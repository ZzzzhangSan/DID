<template>
  <div id="abnormal-picture">
    <div class="abnormal-picture-info">
      <div>信息截图</div>
      <div class="abnormal-picture-info-div">
        <img class="abnormal-picture-info-img" :src="img" alt="">
      </div>
    </div>
    <div class="abnormal-picture-text">
      <div>路由信息</div>
      <div class="abnormal-picture-text-div">一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容
        一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容
        一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容
        一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容一些内容
        一些内容一些内容一些内容</div>
    </div>
  </div>

</template>
<script>
export default {
  name: "AbnormalPicture",
  data() {
    return {
      img: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Flmg.jj20.com%2Fup%2Fallimg%2F1114%2F040221103339%2F210402103339-7-1200.jpg&refer=http%3A%2F%2Flmg.jj20.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1672476153&t=6682243d7c6ad1946dc4cda5279af6bd',
    }
  }
}
</script>
<style lang="less" scoped>
#abnormal-picture{
  height: 600px;
  display: flex;
  flex-direction: column;
  .abnormal-picture-info{
    flex: 7;
    .abnormal-picture-info-div {
      height: 396px;
      padding: 16px 0px;
      // DIV样式（元素居中显示）
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .abnormal-picture-info-img {
      // 纵向拉伸，横向自动匹配大小
      width: 100%;
      height: auto; 
      max-height: 100%; 
      max-width: 100%;
    }
  }
  .abnormal-picture-text{
    flex: 3;
    .abnormal-picture-text-div {
      // overflow-y: scroll;
      height: 156px;
      padding: 16px 0px;
    }
  }
}
</style>