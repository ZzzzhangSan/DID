<template>
  <div id="result-query" class="el-main grid-content">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item>任务管理</el-breadcrumb-item>
      <el-breadcrumb-item breadcrumb-item>结果查询</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="block_base">
      <el-form ref="resultQueryFormQuery" :inline="true" :model="resultQueryFormQuery" class="demo-form-inline">
        <el-form-item label="拨测结果" prop="testResults">
          <el-select v-model="resultQueryFormQuery.testResults">
            <el-option label="全部" value="全部"></el-option>
            <el-option label="正常" value="正常"></el-option>
            <el-option label="异常" value="异常"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="完成时间" prop="startTime">
          <el-date-picker v-model="resultQueryFormQuery.startTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss" placement="bottom-start" placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <div style="float: left;padding: 0px 8px;">至</div>
          <el-date-picker v-model="resultQueryFormQuery.endTime" type="datetime" format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss" placement="bottom-start" placeholder="选择日期时间">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <div style="margin-left: 16px;">
        <el-button type="primary" @click="submitclientPCFormQuery('resultQueryFormQuery')">查询</el-button>
        <el-button type="info" @click="resetclientPCFormQuery('resultQueryFormQuery')">清空</el-button>
      </div>
    </div>
    <div style="float: right; width: calc(100% - 70px)">
      <!-- 设备数量展示 -->
      <div style="
          display: flex;
          justify-content: space-between;
          width: 100%;
          margin-bottom: 20px;">
        <div style="line-height: 40px;">
          <span class="client-device">任务ID: </span>
          <span class="client-device-num client-device-num-online">web_hlw_801</span>
          <span class="client-device" style="border-left: 1px solid #CECECE; padding-left: 24px;">任务名称: </span>
          <span class="client-device-num client-device-num-outline">0902_测试任务1</span>
        </div>
        <div>
          <el-button style="width: 140px;background-color: #F39300;">
            <i class="el-icon-document-copy"></i>
            <span style="margin-left: 8px;">导出查询结果</span>
          </el-button>
        </div>
      </div>
      <!-- 表格 -->
      <div class="block_base base_table" style="width:calc(100% - 40px)">
        <el-table v-loading="clientTableDataLoading" element-loading-text="数据加载中"
          element-loading-spinner="el-icon-loading" element-loading-background="#f5f7f9" ref="clientPCTable"
          :data="clientTableData" tooltip-effect="dark" style="width: 100%" :row-style="{ height: '60px' }">
          <el-table-column type="selection" width="55"> </el-table-column>
          <el-table-column prop="num" label="序号" width="60">
          </el-table-column>
          <el-table-column prop="taskID" label="任务ID" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="taskName" label="任务名称" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="testContent" label="测试内容" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="taskTag" label="任务标签" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="businessTag" label="业务标签" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="testResult" label="拨测结果" width="90">
            <template slot-scope="scope">
              <span v-if="scope.row.testResult === '正常'">正常</span>
              <span v-else @click="abnormal(scope.$index, scope.row)" class="table-operator"
                style="color: #F74E57;cursor: pointer;text-decoration:underline;">异常</span>
              <div v-if="abnormalDialogVisible">
                <el-dialog title="结果信息" :visible.sync="abnormalDialogVisible">
                  <AbnormalPicture></AbnormalPicture>
                  <span slot="footer" class="dialog-footer">
                    <el-button type="primary" @click="abnormalDialogVisible = false">确认</el-button>
                    <el-button style="color: #666666;" @click="abnormalDialogVisible = false">取消</el-button>
                  </span>
                </el-dialog>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="intranetIP" label="内网IP" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="internetIP" label="外网IP" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="testLocation" label="测试地" :show-overflow-tooltip="true" width="90">
          </el-table-column>
          <el-table-column prop="operator" label="运营商" :show-overflow-tooltip="true" width="90">
          </el-table-column>
          <el-table-column prop="monitoringQuantity" label="监测数量" :show-overflow-tooltip="true" width="90">
          </el-table-column>
          <el-table-column prop="issuingTime" label="下发时间" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="finishTime" label="完成时间" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="testMachine" label="测试机" :show-overflow-tooltip="true" width="140">
          </el-table-column>
          <el-table-column prop="sourceAddress" label="源地址" :show-overflow-tooltip="true" width="140">
          </el-table-column>

        </el-table>
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
          :current-page="taskCurrentPage" :page-sizes="[10, 20, 50]" :page-size="taskPageSize"
          layout="total, sizes, prev, pager, next, jumper" :total="taskTotal" style="float: right;margin-top: 16px">
        </el-pagination>
      </div>

    </div>
  </div>
</template>
<script>
// import "@/assets/css/scrollbar.css";
import "@/assets/css/query-form-style.css";
import "@/assets/css/breadcrumb-tabs-style.css"
import AbnormalPicture from "./AbnormalPicture.vue"
export default {
  name: "ResultQuery",
  components: {
    AbnormalPicture,
  },
  data() {
    return {
      resultQueryFormQuery: {
        IntranetIP: "",
        ExtranetIP: "",
        testResults: "全部",
        startTime: "全部",
      },
      clientTableData: [
        {
          num: 1,
          taskID: "web_hlw_0901",
          taskName: "0902_测试任务1",
          testContent: "123",
          taskTag: "task-tag1",
          businessTag: "business-tag1",
          testResult: "正常",
          intranetIP: '255.255.255.255',
          internetIP: '1.1.1.1',
          testLocation: '北京',
          operator: '移动',
          monitoringQuantity: 12,
          issuingTime: '2016-05-04 12:12:12',
          finishTime: '2016-05-04 12:12:12',
          testMachine: '1.1.1.1',
          sourceAddress: '1.1.1.1',
        },
        {
          num: 2,
          taskID: "web_hlw_0902",
          taskName: "0902_测试任务2",
          testContent: "123",
          taskTag: "task-tag2",
          businessTag: "business-tag2",
          testResult: "异常",
          intranetIP: '2.2.2.2',
          internetIP: '2.2.2.2',
          testLocation: '天津',
          operator: '电信',
          monitoringQuantity: 12,
          issuingTime: '2017-05-04 12:12:12',
          finishTime: '2017-05-04 12:12:12',
          testMachine: '2.2.2.2',
          sourceAddress: '2.2.2.2',
        },
        {
          num: 3,
          taskID: "web_hlw_0903",
          taskName: "0902_测试任务3",
          testContent: "123",
          taskTag: "task-tag3",
          businessTag: "business-tag3",
          testResult: "正常",
          intranetIP: '3.3.3.3',
          internetIP: '3.3.3.3',
          testLocation: '上海',
          operator: '联通',
          monitoringQuantity: 12,
          issuingTime: '2018-05-04 12:12:12',
          finishTime: '2018-05-04 12:12:12',
          testMachine: '1.3.3.3',
          sourceAddress: '3.3.3.1',
        },

      ],
      taskPageNum: 1,
      taskPageSize: 10,
      taskTotal: 0,
      taskCurrentPage: 1,
      // 表格加载动画
      clientTableDataLoading: false,
      // clientTableDataLoading: true,
      // 异常图片显示
      abnormalDialogVisible: false,
    };
  },
  methods: {
    submitclientPCFormQuery() { },
    resetclientPCFormQuery() { },
    handleSizeChange(val) { },
    handleCurrentChange(val) { },
    abnormal(index, row) {
      console.log('******************************')
      this.abnormalDialogVisible = true
      console.log(index, row)
      // this.$router.push('/client_management/client_pc_detail_modify')
    },
  },
};
</script>
<style lang="less" scoped>
// 面包屑
:deep(.el-breadcrumb__item:last-child .el-breadcrumb__inner) {
  color: #1675d5 !important;
}

// 时间选择图标
:deep(.el-icon-time:before) {
  content: "";
}

// dialog
:deep(.el-dialog__header) {
  padding: 20px;
  border-bottom: 1px solid #DEE2E6;
}

:deep(.el-dialog__footer) {
  padding: 20px;
  border-top: 1px solid #DEE2E6;
}

:deep(.el-dialog__body) {
  font-family: 'Microsoft YaHei';
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  max-height: 620px;
  overflow-y: scroll;
  color: #333333;
  padding: 20px;

}

:deep(.el-form--inline .el-form-item) {
  display: inline-block;
  margin-right: 1px;
  vertical-align: top;
}

:deep(.el-select .el-input) {
  width: 93% !important;
}

.el-button {
  color: #ffffff;
  width: 70px;
  height: 40px;
  border-radius: 4px;
}

.el-button--primary {
  background: #162b5b;
  border-color: #162b5b;
}

.el-button--info {
  color: #333333;
  background: #d3d4dd;
  border-color: #d3d4dd;
}

.client-device {
  font-family: Microsoft YaHei;
  font-size: 16px;
  font-weight: 400;
  line-height: 22px;
  text-align: center;
  // margin-left: 24px;
}

.client-device-num {
  font-family: Microsoft YaHei;
  font-size: 16px;
  font-weight: 700;
  line-height: 22px;
  text-align: center;
  margin-right: 24px;
  color: #205BD4;
}

.table-operator {
  font-family: Microsoft YaHei;
  font-size: 17px;
  font-weight: 400;
  line-height: 22px;
  text-align: left;
  margin-right: 12px;
}

// .el-pagination__editor.el-input .el-input__inner {
//   height: 28px;
//   line-height: 28px;
//   border-radius: 3px;
// }
:deep(.el-pagination__editor.el-input .el-input__inner) {
  width: 28px;
  border-radius: 3px;
}

:deep(.el-pagination .el-select .el-input .el-input__inner) {
  width: 100px;
}

:deep(.cell) {
  padding: 0 5px !important;
}

:deep(.el-table thead) {
  color: #162b5b;
}

:deep(.el-table .el-table__cell) {
  padding: 4px 0 !important;
}
</style>
