import { request } from '../utils/request'
import api from './index'

export function getStatisticsAll(query) {
    return request({
        url: api.GetStatisticsAll,
        method: 'get',
        params: query
    })
}
export function getStatisticsTrend(query) {
    return request({
        url: api.GetStatisticsTrend,
        method: 'get',
        params: query
    })
}
export function getStatisticsFloor(query) {
    return request({
        url: api.GetStatisticsFloor,
        method: 'get',
        params: query
    })
}
export function getStatisticsCity(query) {
    return request({
        url: api.GetStatisticsCity,
        method: 'get',
        params: query
    })
}
export function getStatisticsKey(query) {
    return request({
        url: api.GetStatisticsKey,
        method: 'get',
        params: query
    })
}
export function getStatisticsISP(query) {
    return request({
        url: api.GetStatisticsISP,
        method: 'get',
        params: query
    })
}
