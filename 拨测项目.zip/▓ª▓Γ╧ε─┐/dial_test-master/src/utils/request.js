import axios from "axios";
import { getToken, getUserToken } from "../api/home";
import store from "@/store/index";

// development  开发环境
const defaultURL = "http://192.168.20.41:18080/taskService"
// const defaultURL = "http://111.204.101.209:8080/taskService/api";
// const defaultURL = "http://172.25.5.81:8080/taskService"

const request = axios.create({
  baseURL: defaultURL,
  timeout: 10000,
});

request.interceptors.request.use(
  (config) => {
    config.headers["token-key"] = localStorage.getItem("userToken");
    // config.headers["token-key"] = store.state.token;
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

request.interceptors.response.use(
  (response) => {
    if (response.data.code === 202) {
      getUserToken({password: 'password', userName: 'userName'}).then((res) => {
        if (res.code === 200) {
          localStorage.setItem('userToken', res.data)
        }
      });
      // getToken({ payload: 123456 }).then((res) => {
      //   if (res.code === 200) {
      //     store.commit("setToken", res.msg);
      //   }
      // });
      let config = response.config;
      config.headers["token-key"] = store.state.token;
      // TODO token 刷新后 重发请求
      return request(config);
    } else {
      return response.data;
    }
  },
  (error) => {
    return Promise.reject(error);
  }
);

export { request, defaultURL };
