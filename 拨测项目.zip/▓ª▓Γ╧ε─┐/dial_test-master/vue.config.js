module.exports = {
  publicPath: '/webTest/',
  // publicPath: '/'
}