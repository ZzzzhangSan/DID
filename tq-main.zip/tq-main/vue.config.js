const path = require('path')
//判断是否为生产环境
const isProd = process.env.NODE_ENV === 'production'

const devServerPort = 8334 // TODO: get this variable from setting.ts
const name = 'app' // TODO: get this variable from setting.ts

const publicPath = process.env.VUE_APP_PUBLIC_PATH
const version = process.env.VUE_APP_VERSION

const mockServer = 'http://172.21.10.225:1233/' //二部
const mockServerQi = 'http://172.19.19.154:8000/' //七部
// const mockServer = 'http://127.0.0.1:4523/m1/1107647-0-default/'

function resolve(dir) {
  //此处使用path.resolve 或path.join 可自行调整
  return path.join(__dirname, dir)
}
module.exports = {
  publicPath: publicPath,
  lintOnSave: !isProd,
  outputDir: 'dist',
  assetsDir: 'static',
  productionSourceMap: false,
  devServer: {
    port: devServerPort,
    open: false,
    overlay: {
      warnings: false,
      errors: true
    },
    proxy: {
      [process.env.VUE_APP_BASE_API]: {
        target: mockServer,
        changeOrigin: true, // needed for virtual hosted sites
        ws: true, // proxy websockets
        pathRewrite: {
          ['^' + process.env.VUE_APP_BASE_API]: ''
        }
      }
    }
  },
  css: {
    requireModuleExtension: true,
    loaderOptions: {
      css: {
        modules: {
          localIdentName: '[name]_[hash:base64:8]'
        },
        localsConvention: 'camelCaseOnly'
      }
    }
  },
  pluginOptions: {
    // 'style-resources-loader': {
    //   preProcessor: 'scss',
    //   patterns: [path.resolve(__dirname, 'src/styles/_variables.scss'), path.resolve(__dirname, 'src/styles/_mixins.scss')]
    // }
  },
  configureWebpack(cfg) {
    if (isProd) {
      cfg.optimization.minimizer[0].options.terserOptions.compress.drop_console = true
    }
  },
  chainWebpack(config) {
    // provide the app's title in webpack's name field, so that
    // it can be accessed in index.html to inject the correct title.
    config.set('name', name)

    // https://webpack.js.org/configuration/devtool/#development
    config.when(!isProd, config => config.devtool('cheap-eval-source-map'))

    config.plugin('preload').tap(() => [
      {
        rel: 'preload',
        // to ignore runtime.js
        // https://github.com/vuejs/vue-cli/blob/dev/packages/@vue/cli-service/lib/config/app.js#L171
        fileBlacklist: [/\.map$/, /hot-update\.js$/, /runtime\..*\.js$/],
        include: 'initial'
      }
    ])

    if (isProd) {
      // config.optimization.minimize(true) // 代码压缩
      // 移除 prefetch 插件
      config.plugins.delete('prefetch')
      config.plugins.delete('preload')
      config.optimization.minimizer('terser').tap(args => {
        Object.assign(args[0].terserOptions.compress, {
          // 生产模式 console.log 去除
          // warnings: false , // 默认 false
          // drop_console:  ,
          drop_console: true,
          drop_debugger: true, // 默认也是true
          pure_funcs: ['console.log']
        })
        return args
      })
    }

    // remove vue-cli-service's progress output
    config.plugins.delete('progress')

    config.when(!isProd, config => {
      config.optimization.splitChunks({
        chunks: 'all',
        cacheGroups: {
          libs: {
            name: 'chunk-libs',
            test: /[\\/]node_modules[\\/]/,
            priority: 10,
            chunks: 'initial' // only package third parties that are initially dependent
          },
          elementUI: {
            name: 'chunk-elementUI', // split elementUI into a single package
            priority: 20, // the weight needs to be larger than libs and app or it will be packaged into libs or app
            test: /[\\/]node_modules[\\/]_?element-ui(.*)/ // in order to adapt to cnpm
          },
          commons: {
            name: 'chunk-commons',
            test: path.resolve(__dirname, 'src/components'),
            minChunks: 3, //  minimum common number
            priority: 5,
            reuseExistingChunk: true
          }
        }
      })
      config.optimization.runtimeChunk('single')
    })
  }
}
