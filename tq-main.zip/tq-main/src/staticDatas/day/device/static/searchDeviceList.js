export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'ztebladea320',
      traffic: 51458,
      proportion: 0.014733327,
      ranking: 1,
      deviceManufacturer: 'zte',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'z930l',
      traffic: 34187,
      proportion: 0.009788337,
      ranking: 2,
      deviceManufacturer: 'zte',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'cph1851',
      traffic: 33381,
      proportion: 0.009557565,
      ranking: 3,
      deviceManufacturer: 'oppo',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'vivo x9s l',
      traffic: 32021,
      proportion: 0.009168173,
      ranking: 4,
      deviceManufacturer: 'vivo',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'huawei matebook 14s',
      traffic: 32018,
      proportion: 0.0091673145,
      ranking: 5,
      deviceManufacturer: 'huawei',
      deviceType: 'PC'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'oppo a53t',
      traffic: 31326,
      proportion: 0.008969182,
      ranking: 6,
      deviceManufacturer: 'oppo',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'htconem9',
      traffic: 30395,
      proportion: 0.008702621,
      ranking: 7,
      deviceManufacturer: 'htc',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'redmi note 8t',
      traffic: 30217,
      proportion: 0.008651656,
      ranking: 8,
      deviceManufacturer: 'xiaomi',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'kiw al10',
      traffic: 29999,
      proportion: 0.008589239,
      ranking: 9,
      deviceManufacturer: 'honor',
      deviceType: '移动终端'
    },
    {
      mdate: '20220502',
      type: null,
      manufacturer: null,
      device: 'ztebladea506',
      traffic: 29936,
      proportion: 0.008571201,
      ranking: 10,
      deviceManufacturer: 'zte',
      deviceType: '移动终端'
    }
  ]
}
