export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    { mdate: '20220502', type: null, traffic: 3235176, proportion: 0.92628753, ranking: 1, deviceType: '移动终端' },
    { mdate: '20220502', type: null, traffic: 257450, proportion: 0.073712446, ranking: 2, deviceType: 'PC' }
  ],
  total: 2
}
