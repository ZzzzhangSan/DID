export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    { mdate: '20220502', manufacturer: null, traffic: 572797, proportion: 0.16400181, ranking: 1, deviceManufacturer: 'zte' },
    { mdate: '20220502', manufacturer: null, traffic: 445882, proportion: 0.12766382, ranking: 2, deviceManufacturer: 'htc' },
    { mdate: '20220502', manufacturer: null, traffic: 361793, proportion: 0.10358767, ranking: 3, deviceManufacturer: 'vivo' },
    { mdate: '20220502', manufacturer: null, traffic: 355201, proportion: 0.10170027, ranking: 4, deviceManufacturer: 'samsung' },
    { mdate: '20220502', manufacturer: null, traffic: 305365, proportion: 0.08743135, ranking: 5, deviceManufacturer: 'huawei' },
    { mdate: '20220502', manufacturer: null, traffic: 289661, proportion: 0.08293502, ranking: 6, deviceManufacturer: 'lenovo' },
    { mdate: '20220502', manufacturer: null, traffic: 282930, proportion: 0.081007816, ranking: 7, deviceManufacturer: 'xiaomi' },
    { mdate: '20220502', manufacturer: null, traffic: 254418, proportion: 0.07284433, ranking: 8, deviceManufacturer: 'oppo' },
    { mdate: '20220502', manufacturer: null, traffic: 227017, proportion: 0.06499895, ranking: 9, deviceManufacturer: 'apple' },
    { mdate: '20220502', manufacturer: null, traffic: 167985, proportion: 0.048097048, ranking: 10, deviceManufacturer: 'realme' },
    { mdate: '20220502', manufacturer: null, traffic: 125622, proportion: 0.03596778, ranking: 11, deviceManufacturer: 'honor' },
    { mdate: '20220502', manufacturer: null, traffic: 53084, proportion: 0.015198879, ranking: 12, deviceManufacturer: 'dell' },
    { mdate: '20220502', manufacturer: null, traffic: 50871, proportion: 0.014565258, ranking: 13, deviceManufacturer: 'oneplus' }
  ],
  total: 13
}
