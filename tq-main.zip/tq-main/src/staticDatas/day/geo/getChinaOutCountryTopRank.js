export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: null, country: '越南', traffic: 13142, proportion: 0.004331504, ranking: 1, inout: null },
    { mdate: null, country: '英属基地区', traffic: 12999, proportion: 0.0042843726, ranking: 2, inout: null },
    { mdate: null, country: '安圭拉', traffic: 12855, proportion: 0.004236911, ranking: 3, inout: null },
    { mdate: null, country: '斯瓦尔巴和扬马延', traffic: 12828, proportion: 0.004228012, ranking: 4, inout: null },
    { mdate: null, country: '西班牙', traffic: 12782, proportion: 0.0042128507, ranking: 5, inout: null },
    { mdate: null, country: '秘鲁', traffic: 12773, proportion: 0.0042098844, ranking: 6, inout: null },
    { mdate: null, country: '不丹', traffic: 12771, proportion: 0.004209225, ranking: 7, inout: null },
    { mdate: null, country: '老挝', traffic: 12736, proportion: 0.0041976897, ranking: 8, inout: null },
    { mdate: null, country: '芬兰', traffic: 12705, proportion: 0.004187472, ranking: 9, inout: null },
    { mdate: null, country: '英属印度洋领地', traffic: 12700, proportion: 0.004185824, ranking: 10, inout: null }
  ]
}
