export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: null, provinceCn: null, traffic: 91459, proportion: 0.030144196, ranking: 1, inout: null, country: null, province: '安徽省' },
    { mdate: null, provinceCn: null, traffic: 90433, proportion: 0.029806035, ranking: 2, inout: null, country: null, province: '湖北省' },
    { mdate: null, provinceCn: null, traffic: 90262, proportion: 0.029749675, ranking: 3, inout: null, country: null, province: '福建省' },
    { mdate: null, provinceCn: null, traffic: 90241, proportion: 0.029742753, ranking: 4, inout: null, country: null, province: '澳门' },
    { mdate: null, provinceCn: null, traffic: 90182, proportion: 0.029723307, ranking: 5, inout: null, country: null, province: '贵州省' },
    { mdate: null, provinceCn: null, traffic: 90098, proportion: 0.02969562, ranking: 6, inout: null, country: null, province: '重庆市' },
    { mdate: null, provinceCn: null, traffic: 90045, proportion: 0.029678153, ranking: 7, inout: null, country: null, province: '广东省' },
    { mdate: null, provinceCn: null, traffic: 90006, proportion: 0.029665299, ranking: 8, inout: null, country: null, province: '辽宁省' },
    { mdate: null, provinceCn: null, traffic: 89978, proportion: 0.02965607, ranking: 9, inout: null, country: null, province: '陕西省' },
    { mdate: null, provinceCn: null, traffic: 89962, proportion: 0.029650796, ranking: 10, inout: null, country: null, province: '北京市' }
  ]
}
