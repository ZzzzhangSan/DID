export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: null, country: '马恩岛', traffic: 12815, proportion: 0.004237609, ranking: 1, inout: null },
    { mdate: null, country: '安哥拉', traffic: 12795, proportion: 0.0042309957, ranking: 2, inout: null },
    { mdate: null, country: '泽西岛', traffic: 12787, proportion: 0.0042283502, ranking: 3, inout: null },
    { mdate: null, country: '摩洛哥', traffic: 12777, proportion: 0.004225043, ranking: 4, inout: null },
    { mdate: null, country: '圭亚那', traffic: 12773, proportion: 0.0042237206, ranking: 5, inout: null },
    { mdate: null, country: '韩国', traffic: 12645, proportion: 0.0041813944, ranking: 6, inout: null },
    { mdate: null, country: '瑞典', traffic: 12627, proportion: 0.004175442, ranking: 7, inout: null },
    { mdate: null, country: '贝宁', traffic: 12608, proportion: 0.004169159, ranking: 8, inout: null },
    { mdate: null, country: '圣卢西亚', traffic: 12608, proportion: 0.004169159, ranking: 9, inout: null },
    { mdate: null, country: '黎巴嫩', traffic: 12599, proportion: 0.004166183, ranking: 10, inout: null }
  ]
}
