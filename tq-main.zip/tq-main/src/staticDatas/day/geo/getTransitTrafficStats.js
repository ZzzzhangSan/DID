export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: null, transit: null, traffic: 22157040, proportion: 0.7857117, transitType: '过境' },
    { mdate: null, transit: null, traffic: 6042921, proportion: 0.21428828, transitType: '非过境' }
  ]
}
