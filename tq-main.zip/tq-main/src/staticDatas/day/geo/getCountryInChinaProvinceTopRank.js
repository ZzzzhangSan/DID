export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: null, provinceCn: null, traffic: 90489, proportion: 0.029922513, ranking: 1, inout: null, country: null, province: '香港' },
    { mdate: null, provinceCn: null, traffic: 90420, proportion: 0.029899696, ranking: 2, inout: null, country: null, province: '山东省' },
    { mdate: null, provinceCn: null, traffic: 90337, proportion: 0.02987225, ranking: 3, inout: null, country: null, province: '甘肃省' },
    { mdate: null, provinceCn: null, traffic: 90161, proportion: 0.029814051, ranking: 4, inout: null, country: null, province: '浙江省' },
    { mdate: null, provinceCn: null, traffic: 90108, proportion: 0.029796526, ranking: 5, inout: null, country: null, province: '山西省' },
    { mdate: null, provinceCn: null, traffic: 90096, proportion: 0.029792557, ranking: 6, inout: null, country: null, province: '广西壮族自治区' },
    { mdate: null, provinceCn: null, traffic: 89922, proportion: 0.02973502, ranking: 7, inout: null, country: null, province: '宁夏回族自治区' },
    { mdate: null, provinceCn: null, traffic: 89688, proportion: 0.029657641, ranking: 8, inout: null, country: null, province: '吉林省' },
    { mdate: null, provinceCn: null, traffic: 89498, proportion: 0.029594813, ranking: 9, inout: null, country: null, province: '河南省' },
    { mdate: null, provinceCn: null, traffic: 89490, proportion: 0.029592168, ranking: 10, inout: null, country: null, province: '天津市' }
  ]
}
