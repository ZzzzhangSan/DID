export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: '20220502', country1: '利比亚', country2: '布韦岛', traffic: 1040, ranking: 1 },
    { mdate: '20220502', country1: '尼加拉瓜', country2: '斐济', traffic: 1000, ranking: 2 },
    { mdate: '20220502', country1: '不丹', country2: '福克兰群岛', traffic: 992, ranking: 3 },
    { mdate: '20220502', country1: '列支敦士登', country2: '基里巴斯', traffic: 992, ranking: 4 },
    { mdate: '20220502', country1: '北马其顿共和国', country2: '纽埃', traffic: 986, ranking: 5 },
    { mdate: '20220502', country1: '法属南部领地', country2: '荷兰', traffic: 981, ranking: 6 },
    { mdate: '20220502', country1: '密克罗尼西亚', country2: '爱沙尼亚', traffic: 977, ranking: 7 },
    { mdate: '20220502', country1: '以色列', country2: '圣文森特和格林纳丁斯', traffic: 977, ranking: 8 },
    { mdate: '20220502', country1: '古巴', country2: '马来西亚', traffic: 973, ranking: 9 },
    { mdate: '20220502', country1: '危地马拉', country2: '科摩罗', traffic: 972, ranking: 10 }
  ]
}
