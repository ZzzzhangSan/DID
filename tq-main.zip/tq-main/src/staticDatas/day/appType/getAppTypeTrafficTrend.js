export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: '20220509',
      mhour: '00',
      type: '便捷生活',
      traffic: 7494,
      appType: '便捷生活',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '儿童',
      traffic: 4143,
      appType: '儿童',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '出行导航',
      traffic: 10892,
      appType: '出行导航',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '商务',
      traffic: 16935,
      appType: '商务',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '实用工具',
      traffic: 8876,
      appType: '实用工具',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '影音娱乐',
      traffic: 9244,
      appType: '影音娱乐',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '拍照美化',
      traffic: 12605,
      appType: '拍照美化',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '教育',
      traffic: 13804,
      appType: '教育',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '新闻阅读',
      traffic: 18516,
      appType: '新闻阅读',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '旅游住宿',
      traffic: 5621,
      appType: '旅游住宿',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '汽车',
      traffic: 4167,
      appType: '汽车',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '社交通讯',
      traffic: 7533,
      appType: '社交通讯',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '美食',
      traffic: 8916,
      appType: '美食',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '购物比价',
      traffic: 9083,
      appType: '购物比价',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '运动健康',
      traffic: 5155,
      appType: '运动健康',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '00',
      type: '金融理财',
      traffic: 11773,
      appType: '金融理财',
      time: '00'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '便捷生活',
      traffic: 5503,
      appType: '便捷生活',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '儿童',
      traffic: 2772,
      appType: '儿童',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '出行导航',
      traffic: 5841,
      appType: '出行导航',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '商务',
      traffic: 8168,
      appType: '商务',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '实用工具',
      traffic: 7733,
      appType: '实用工具',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '影音娱乐',
      traffic: 3824,
      appType: '影音娱乐',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '拍照美化',
      traffic: 8427,
      appType: '拍照美化',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '教育',
      traffic: 9374,
      appType: '教育',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '新闻阅读',
      traffic: 12745,
      appType: '新闻阅读',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '旅游住宿',
      traffic: 3012,
      appType: '旅游住宿',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '汽车',
      traffic: 3368,
      appType: '汽车',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '社交通讯',
      traffic: 7049,
      appType: '社交通讯',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '美食',
      traffic: 5148,
      appType: '美食',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '购物比价',
      traffic: 7024,
      appType: '购物比价',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '运动健康',
      traffic: 2930,
      appType: '运动健康',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '01',
      type: '金融理财',
      traffic: 8780,
      appType: '金融理财',
      time: '01'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '新闻阅读',
      traffic: 13948,
      appType: '新闻阅读',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '儿童',
      traffic: 2482,
      appType: '儿童',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '出行导航',
      traffic: 6613,
      appType: '出行导航',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '商务',
      traffic: 9288,
      appType: '商务',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '实用工具',
      traffic: 6424,
      appType: '实用工具',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '影音娱乐',
      traffic: 4473,
      appType: '影音娱乐',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '拍照美化',
      traffic: 6275,
      appType: '拍照美化',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '教育',
      traffic: 7979,
      appType: '教育',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '便捷生活',
      traffic: 5050,
      appType: '便捷生活',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '旅游住宿',
      traffic: 3717,
      appType: '旅游住宿',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '汽车',
      traffic: 3134,
      appType: '汽车',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '社交通讯',
      traffic: 6130,
      appType: '社交通讯',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '美食',
      traffic: 7224,
      appType: '美食',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '购物比价',
      traffic: 5482,
      appType: '购物比价',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '运动健康',
      traffic: 2654,
      appType: '运动健康',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '02',
      type: '金融理财',
      traffic: 9275,
      appType: '金融理财',
      time: '02'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '新闻阅读',
      traffic: 5378,
      appType: '新闻阅读',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '儿童',
      traffic: 1984,
      appType: '儿童',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '出行导航',
      traffic: 3788,
      appType: '出行导航',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '商务',
      traffic: 4480,
      appType: '商务',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '实用工具',
      traffic: 3410,
      appType: '实用工具',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '影音娱乐',
      traffic: 2476,
      appType: '影音娱乐',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '拍照美化',
      traffic: 3884,
      appType: '拍照美化',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '教育',
      traffic: 3538,
      appType: '教育',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '便捷生活',
      traffic: 2916,
      appType: '便捷生活',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '旅游住宿',
      traffic: 1838,
      appType: '旅游住宿',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '汽车',
      traffic: 1484,
      appType: '汽车',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '社交通讯',
      traffic: 2939,
      appType: '社交通讯',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '美食',
      traffic: 3688,
      appType: '美食',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '购物比价',
      traffic: 3720,
      appType: '购物比价',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '运动健康',
      traffic: 1008,
      appType: '运动健康',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '03',
      type: '金融理财',
      traffic: 3833,
      appType: '金融理财',
      time: '03'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '便捷生活',
      traffic: 2525,
      appType: '便捷生活',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '儿童',
      traffic: 736,
      appType: '儿童',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '出行导航',
      traffic: 4394,
      appType: '出行导航',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '商务',
      traffic: 4309,
      appType: '商务',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '实用工具',
      traffic: 2993,
      appType: '实用工具',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '影音娱乐',
      traffic: 2253,
      appType: '影音娱乐',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '拍照美化',
      traffic: 4927,
      appType: '拍照美化',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '教育',
      traffic: 3728,
      appType: '教育',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '新闻阅读',
      traffic: 6631,
      appType: '新闻阅读',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '旅游住宿',
      traffic: 1699,
      appType: '旅游住宿',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '汽车',
      traffic: 1444,
      appType: '汽车',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '社交通讯',
      traffic: 3264,
      appType: '社交通讯',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '美食',
      traffic: 2750,
      appType: '美食',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '购物比价',
      traffic: 3812,
      appType: '购物比价',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '运动健康',
      traffic: 1344,
      appType: '运动健康',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '04',
      type: '金融理财',
      traffic: 4535,
      appType: '金融理财',
      time: '04'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '新闻阅读',
      traffic: 14381,
      appType: '新闻阅读',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '儿童',
      traffic: 3518,
      appType: '儿童',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '出行导航',
      traffic: 6285,
      appType: '出行导航',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '商务',
      traffic: 8150,
      appType: '商务',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '实用工具',
      traffic: 6494,
      appType: '实用工具',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '影音娱乐',
      traffic: 4521,
      appType: '影音娱乐',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '拍照美化',
      traffic: 8116,
      appType: '拍照美化',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '教育',
      traffic: 8447,
      appType: '教育',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '便捷生活',
      traffic: 4263,
      appType: '便捷生活',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '旅游住宿',
      traffic: 3207,
      appType: '旅游住宿',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '汽车',
      traffic: 3707,
      appType: '汽车',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '社交通讯',
      traffic: 6643,
      appType: '社交通讯',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '美食',
      traffic: 6343,
      appType: '美食',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '购物比价',
      traffic: 5132,
      appType: '购物比价',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '运动健康',
      traffic: 3040,
      appType: '运动健康',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '05',
      type: '金融理财',
      traffic: 8732,
      appType: '金融理财',
      time: '05'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '便捷生活',
      traffic: 7930,
      appType: '便捷生活',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '儿童',
      traffic: 3723,
      appType: '儿童',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '出行导航',
      traffic: 10185,
      appType: '出行导航',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '商务',
      traffic: 10851,
      appType: '商务',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '实用工具',
      traffic: 9083,
      appType: '实用工具',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '影音娱乐',
      traffic: 7280,
      appType: '影音娱乐',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '拍照美化',
      traffic: 10007,
      appType: '拍照美化',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '教育',
      traffic: 13342,
      appType: '教育',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '新闻阅读',
      traffic: 21618,
      appType: '新闻阅读',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '旅游住宿',
      traffic: 4140,
      appType: '旅游住宿',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '汽车',
      traffic: 5654,
      appType: '汽车',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '社交通讯',
      traffic: 9812,
      appType: '社交通讯',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '美食',
      traffic: 11925,
      appType: '美食',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '购物比价',
      traffic: 10442,
      appType: '购物比价',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '运动健康',
      traffic: 4422,
      appType: '运动健康',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '06',
      type: '金融理财',
      traffic: 11023,
      appType: '金融理财',
      time: '06'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '便捷生活',
      traffic: 14928,
      appType: '便捷生活',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '儿童',
      traffic: 6489,
      appType: '儿童',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '出行导航',
      traffic: 14156,
      appType: '出行导航',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '商务',
      traffic: 21451,
      appType: '商务',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '实用工具',
      traffic: 13218,
      appType: '实用工具',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '影音娱乐',
      traffic: 15329,
      appType: '影音娱乐',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '拍照美化',
      traffic: 22097,
      appType: '拍照美化',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '教育',
      traffic: 16450,
      appType: '教育',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '新闻阅读',
      traffic: 34952,
      appType: '新闻阅读',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '旅游住宿',
      traffic: 7040,
      appType: '旅游住宿',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '汽车',
      traffic: 7900,
      appType: '汽车',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '社交通讯',
      traffic: 10370,
      appType: '社交通讯',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '美食',
      traffic: 20329,
      appType: '美食',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '购物比价',
      traffic: 14712,
      appType: '购物比价',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '运动健康',
      traffic: 7268,
      appType: '运动健康',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '07',
      type: '金融理财',
      traffic: 25264,
      appType: '金融理财',
      time: '07'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '便捷生活',
      traffic: 14633,
      appType: '便捷生活',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '儿童',
      traffic: 9673,
      appType: '儿童',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '出行导航',
      traffic: 28791,
      appType: '出行导航',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '商务',
      traffic: 28061,
      appType: '商务',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '实用工具',
      traffic: 15134,
      appType: '实用工具',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '影音娱乐',
      traffic: 12216,
      appType: '影音娱乐',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '拍照美化',
      traffic: 25778,
      appType: '拍照美化',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '教育',
      traffic: 25999,
      appType: '教育',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '新闻阅读',
      traffic: 42243,
      appType: '新闻阅读',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '旅游住宿',
      traffic: 8510,
      appType: '旅游住宿',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '汽车',
      traffic: 9383,
      appType: '汽车',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '社交通讯',
      traffic: 16096,
      appType: '社交通讯',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '美食',
      traffic: 18648,
      appType: '美食',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '购物比价',
      traffic: 16891,
      appType: '购物比价',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '运动健康',
      traffic: 6654,
      appType: '运动健康',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '08',
      type: '金融理财',
      traffic: 27819,
      appType: '金融理财',
      time: '08'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '便捷生活',
      traffic: 29207,
      appType: '便捷生活',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '儿童',
      traffic: 9129,
      appType: '儿童',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '出行导航',
      traffic: 21290,
      appType: '出行导航',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '商务',
      traffic: 34173,
      appType: '商务',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '实用工具',
      traffic: 23755,
      appType: '实用工具',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '影音娱乐',
      traffic: 21928,
      appType: '影音娱乐',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '拍照美化',
      traffic: 32074,
      appType: '拍照美化',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '教育',
      traffic: 31412,
      appType: '教育',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '新闻阅读',
      traffic: 49019,
      appType: '新闻阅读',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '旅游住宿',
      traffic: 9718,
      appType: '旅游住宿',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '汽车',
      traffic: 17682,
      appType: '汽车',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '社交通讯',
      traffic: 21211,
      appType: '社交通讯',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '美食',
      traffic: 25740,
      appType: '美食',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '购物比价',
      traffic: 29860,
      appType: '购物比价',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '运动健康',
      traffic: 11447,
      appType: '运动健康',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '09',
      type: '金融理财',
      traffic: 43223,
      appType: '金融理财',
      time: '09'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '便捷生活',
      traffic: 23693,
      appType: '便捷生活',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '儿童',
      traffic: 9438,
      appType: '儿童',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '出行导航',
      traffic: 34778,
      appType: '出行导航',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '商务',
      traffic: 36474,
      appType: '商务',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '实用工具',
      traffic: 22811,
      appType: '实用工具',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '影音娱乐',
      traffic: 30483,
      appType: '影音娱乐',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '拍照美化',
      traffic: 34098,
      appType: '拍照美化',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '教育',
      traffic: 42861,
      appType: '教育',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '新闻阅读',
      traffic: 54241,
      appType: '新闻阅读',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '旅游住宿',
      traffic: 15307,
      appType: '旅游住宿',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '汽车',
      traffic: 13774,
      appType: '汽车',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '社交通讯',
      traffic: 27749,
      appType: '社交通讯',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '美食',
      traffic: 18668,
      appType: '美食',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '购物比价',
      traffic: 36453,
      appType: '购物比价',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '运动健康',
      traffic: 10689,
      appType: '运动健康',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '10',
      type: '金融理财',
      traffic: 40956,
      appType: '金融理财',
      time: '10'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '运动健康',
      traffic: 13977,
      appType: '运动健康',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '购物比价',
      traffic: 24995,
      appType: '购物比价',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '便捷生活',
      traffic: 28684,
      appType: '便捷生活',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '儿童',
      traffic: 15120,
      appType: '儿童',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '出行导航',
      traffic: 31397,
      appType: '出行导航',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '商务',
      traffic: 29630,
      appType: '商务',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '实用工具',
      traffic: 29599,
      appType: '实用工具',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '影音娱乐',
      traffic: 19225,
      appType: '影音娱乐',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '拍照美化',
      traffic: 33073,
      appType: '拍照美化',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '教育',
      traffic: 29344,
      appType: '教育',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '新闻阅读',
      traffic: 47944,
      appType: '新闻阅读',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '旅游住宿',
      traffic: 12912,
      appType: '旅游住宿',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '汽车',
      traffic: 15603,
      appType: '汽车',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '社交通讯',
      traffic: 21662,
      appType: '社交通讯',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '美食',
      traffic: 21156,
      appType: '美食',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '11',
      type: '金融理财',
      traffic: 39605,
      appType: '金融理财',
      time: '11'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '金融理财',
      traffic: 32866,
      appType: '金融理财',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '便捷生活',
      traffic: 18860,
      appType: '便捷生活',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '儿童',
      traffic: 7869,
      appType: '儿童',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '出行导航',
      traffic: 19596,
      appType: '出行导航',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '商务',
      traffic: 24224,
      appType: '商务',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '实用工具',
      traffic: 26664,
      appType: '实用工具',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '影音娱乐',
      traffic: 17744,
      appType: '影音娱乐',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '拍照美化',
      traffic: 24316,
      appType: '拍照美化',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '教育',
      traffic: 26787,
      appType: '教育',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '新闻阅读',
      traffic: 48955,
      appType: '新闻阅读',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '旅游住宿',
      traffic: 11465,
      appType: '旅游住宿',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '汽车',
      traffic: 10924,
      appType: '汽车',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '社交通讯',
      traffic: 25470,
      appType: '社交通讯',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '美食',
      traffic: 21013,
      appType: '美食',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '购物比价',
      traffic: 22155,
      appType: '购物比价',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '12',
      type: '运动健康',
      traffic: 9648,
      appType: '运动健康',
      time: '12'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '便捷生活',
      traffic: 28178,
      appType: '便捷生活',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '儿童',
      traffic: 11267,
      appType: '儿童',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '出行导航',
      traffic: 25099,
      appType: '出行导航',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '商务',
      traffic: 31424,
      appType: '商务',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '实用工具',
      traffic: 34208,
      appType: '实用工具',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '影音娱乐',
      traffic: 22776,
      appType: '影音娱乐',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '拍照美化',
      traffic: 30148,
      appType: '拍照美化',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '教育',
      traffic: 36958,
      appType: '教育',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '新闻阅读',
      traffic: 48266,
      appType: '新闻阅读',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '旅游住宿',
      traffic: 18622,
      appType: '旅游住宿',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '汽车',
      traffic: 15424,
      appType: '汽车',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '社交通讯',
      traffic: 25796,
      appType: '社交通讯',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '美食',
      traffic: 22859,
      appType: '美食',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '购物比价',
      traffic: 22289,
      appType: '购物比价',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '运动健康',
      traffic: 12087,
      appType: '运动健康',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '13',
      type: '金融理财',
      traffic: 22501,
      appType: '金融理财',
      time: '13'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '便捷生活',
      traffic: 20159,
      appType: '便捷生活',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '儿童',
      traffic: 10334,
      appType: '儿童',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '出行导航',
      traffic: 24253,
      appType: '出行导航',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '商务',
      traffic: 31659,
      appType: '商务',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '实用工具',
      traffic: 18696,
      appType: '实用工具',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '影音娱乐',
      traffic: 19960,
      appType: '影音娱乐',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '拍照美化',
      traffic: 36263,
      appType: '拍照美化',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '教育',
      traffic: 35069,
      appType: '教育',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '新闻阅读',
      traffic: 49879,
      appType: '新闻阅读',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '旅游住宿',
      traffic: 13049,
      appType: '旅游住宿',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '汽车',
      traffic: 10641,
      appType: '汽车',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '社交通讯',
      traffic: 22960,
      appType: '社交通讯',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '美食',
      traffic: 26641,
      appType: '美食',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '购物比价',
      traffic: 30881,
      appType: '购物比价',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '运动健康',
      traffic: 12108,
      appType: '运动健康',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '14',
      type: '金融理财',
      traffic: 40095,
      appType: '金融理财',
      time: '14'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '新闻阅读',
      traffic: 67455,
      appType: '新闻阅读',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '儿童',
      traffic: 12651,
      appType: '儿童',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '出行导航',
      traffic: 39671,
      appType: '出行导航',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '商务',
      traffic: 34395,
      appType: '商务',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '实用工具',
      traffic: 25623,
      appType: '实用工具',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '影音娱乐',
      traffic: 21159,
      appType: '影音娱乐',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '拍照美化',
      traffic: 28388,
      appType: '拍照美化',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '教育',
      traffic: 36102,
      appType: '教育',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '便捷生活',
      traffic: 21107,
      appType: '便捷生活',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '旅游住宿',
      traffic: 15217,
      appType: '旅游住宿',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '汽车',
      traffic: 14457,
      appType: '汽车',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '社交通讯',
      traffic: 23106,
      appType: '社交通讯',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '美食',
      traffic: 26487,
      appType: '美食',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '购物比价',
      traffic: 38133,
      appType: '购物比价',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '运动健康',
      traffic: 11555,
      appType: '运动健康',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '15',
      type: '金融理财',
      traffic: 40361,
      appType: '金融理财',
      time: '15'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '便捷生活',
      traffic: 24745,
      appType: '便捷生活',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '儿童',
      traffic: 6292,
      appType: '儿童',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '出行导航',
      traffic: 38405,
      appType: '出行导航',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '商务',
      traffic: 32944,
      appType: '商务',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '实用工具',
      traffic: 28831,
      appType: '实用工具',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '影音娱乐',
      traffic: 27222,
      appType: '影音娱乐',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '拍照美化',
      traffic: 38364,
      appType: '拍照美化',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '教育',
      traffic: 41496,
      appType: '教育',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '新闻阅读',
      traffic: 53899,
      appType: '新闻阅读',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '旅游住宿',
      traffic: 12364,
      appType: '旅游住宿',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '汽车',
      traffic: 14673,
      appType: '汽车',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '社交通讯',
      traffic: 30088,
      appType: '社交通讯',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '美食',
      traffic: 33642,
      appType: '美食',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '购物比价',
      traffic: 31727,
      appType: '购物比价',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '运动健康',
      traffic: 17141,
      appType: '运动健康',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '16',
      type: '金融理财',
      traffic: 38162,
      appType: '金融理财',
      time: '16'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '新闻阅读',
      traffic: 58078,
      appType: '新闻阅读',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '儿童',
      traffic: 14275,
      appType: '儿童',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '出行导航',
      traffic: 28714,
      appType: '出行导航',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '商务',
      traffic: 33368,
      appType: '商务',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '实用工具',
      traffic: 23673,
      appType: '实用工具',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '影音娱乐',
      traffic: 24345,
      appType: '影音娱乐',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '拍照美化',
      traffic: 33059,
      appType: '拍照美化',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '教育',
      traffic: 35831,
      appType: '教育',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '便捷生活',
      traffic: 20549,
      appType: '便捷生活',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '旅游住宿',
      traffic: 10834,
      appType: '旅游住宿',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '汽车',
      traffic: 15706,
      appType: '汽车',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '社交通讯',
      traffic: 18880,
      appType: '社交通讯',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '美食',
      traffic: 17087,
      appType: '美食',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '购物比价',
      traffic: 27181,
      appType: '购物比价',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '运动健康',
      traffic: 8045,
      appType: '运动健康',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '17',
      type: '金融理财',
      traffic: 33165,
      appType: '金融理财',
      time: '17'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '新闻阅读',
      traffic: 51997,
      appType: '新闻阅读',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '儿童',
      traffic: 7857,
      appType: '儿童',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '出行导航',
      traffic: 23345,
      appType: '出行导航',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '商务',
      traffic: 26893,
      appType: '商务',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '实用工具',
      traffic: 18834,
      appType: '实用工具',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '影音娱乐',
      traffic: 18653,
      appType: '影音娱乐',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '拍照美化',
      traffic: 25977,
      appType: '拍照美化',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '教育',
      traffic: 26860,
      appType: '教育',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '便捷生活',
      traffic: 13915,
      appType: '便捷生活',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '旅游住宿',
      traffic: 9010,
      appType: '旅游住宿',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '汽车',
      traffic: 13557,
      appType: '汽车',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '社交通讯',
      traffic: 22388,
      appType: '社交通讯',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '美食',
      traffic: 19928,
      appType: '美食',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '购物比价',
      traffic: 20804,
      appType: '购物比价',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '运动健康',
      traffic: 11868,
      appType: '运动健康',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '18',
      type: '金融理财',
      traffic: 33890,
      appType: '金融理财',
      time: '18'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '便捷生活',
      traffic: 24313,
      appType: '便捷生活',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '儿童',
      traffic: 12321,
      appType: '儿童',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '出行导航',
      traffic: 25278,
      appType: '出行导航',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '商务',
      traffic: 30080,
      appType: '商务',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '实用工具',
      traffic: 22816,
      appType: '实用工具',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '影音娱乐',
      traffic: 22021,
      appType: '影音娱乐',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '拍照美化',
      traffic: 25575,
      appType: '拍照美化',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '教育',
      traffic: 33620,
      appType: '教育',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '新闻阅读',
      traffic: 48940,
      appType: '新闻阅读',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '旅游住宿',
      traffic: 9533,
      appType: '旅游住宿',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '汽车',
      traffic: 13583,
      appType: '汽车',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '社交通讯',
      traffic: 22658,
      appType: '社交通讯',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '美食',
      traffic: 26704,
      appType: '美食',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '购物比价',
      traffic: 18388,
      appType: '购物比价',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '运动健康',
      traffic: 12374,
      appType: '运动健康',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '19',
      type: '金融理财',
      traffic: 37735,
      appType: '金融理财',
      time: '19'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '新闻阅读',
      traffic: 69746,
      appType: '新闻阅读',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '儿童',
      traffic: 10443,
      appType: '儿童',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '出行导航',
      traffic: 24730,
      appType: '出行导航',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '商务',
      traffic: 39736,
      appType: '商务',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '实用工具',
      traffic: 26155,
      appType: '实用工具',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '影音娱乐',
      traffic: 26981,
      appType: '影音娱乐',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '拍照美化',
      traffic: 32369,
      appType: '拍照美化',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '教育',
      traffic: 30570,
      appType: '教育',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '便捷生活',
      traffic: 28213,
      appType: '便捷生活',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '旅游住宿',
      traffic: 12239,
      appType: '旅游住宿',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '汽车',
      traffic: 14908,
      appType: '汽车',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '社交通讯',
      traffic: 23433,
      appType: '社交通讯',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '美食',
      traffic: 23899,
      appType: '美食',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '购物比价',
      traffic: 35315,
      appType: '购物比价',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '运动健康',
      traffic: 17491,
      appType: '运动健康',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '20',
      type: '金融理财',
      traffic: 35192,
      appType: '金融理财',
      time: '20'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '便捷生活',
      traffic: 25959,
      appType: '便捷生活',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '儿童',
      traffic: 16066,
      appType: '儿童',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '出行导航',
      traffic: 38077,
      appType: '出行导航',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '商务',
      traffic: 35015,
      appType: '商务',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '实用工具',
      traffic: 26423,
      appType: '实用工具',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '影音娱乐',
      traffic: 24035,
      appType: '影音娱乐',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '拍照美化',
      traffic: 28474,
      appType: '拍照美化',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '教育',
      traffic: 49241,
      appType: '教育',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '新闻阅读',
      traffic: 51786,
      appType: '新闻阅读',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '旅游住宿',
      traffic: 17592,
      appType: '旅游住宿',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '汽车',
      traffic: 14492,
      appType: '汽车',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '社交通讯',
      traffic: 23295,
      appType: '社交通讯',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '美食',
      traffic: 26451,
      appType: '美食',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '购物比价',
      traffic: 28912,
      appType: '购物比价',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '运动健康',
      traffic: 12966,
      appType: '运动健康',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '21',
      type: '金融理财',
      traffic: 36697,
      appType: '金融理财',
      time: '21'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '便捷生活',
      traffic: 13684,
      appType: '便捷生活',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '儿童',
      traffic: 8405,
      appType: '儿童',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '出行导航',
      traffic: 16874,
      appType: '出行导航',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '商务',
      traffic: 18085,
      appType: '商务',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '实用工具',
      traffic: 14669,
      appType: '实用工具',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '影音娱乐',
      traffic: 12497,
      appType: '影音娱乐',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '拍照美化',
      traffic: 16677,
      appType: '拍照美化',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '教育',
      traffic: 21890,
      appType: '教育',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '新闻阅读',
      traffic: 32010,
      appType: '新闻阅读',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '旅游住宿',
      traffic: 7881,
      appType: '旅游住宿',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '汽车',
      traffic: 8148,
      appType: '汽车',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '社交通讯',
      traffic: 13255,
      appType: '社交通讯',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '美食',
      traffic: 16487,
      appType: '美食',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '购物比价',
      traffic: 19560,
      appType: '购物比价',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '运动健康',
      traffic: 8954,
      appType: '运动健康',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '22',
      type: '金融理财',
      traffic: 24887,
      appType: '金融理财',
      time: '22'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '便捷生活',
      traffic: 7817,
      appType: '便捷生活',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '儿童',
      traffic: 6762,
      appType: '儿童',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '出行导航',
      traffic: 17022,
      appType: '出行导航',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '商务',
      traffic: 18809,
      appType: '商务',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '实用工具',
      traffic: 13210,
      appType: '实用工具',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '影音娱乐',
      traffic: 6871,
      appType: '影音娱乐',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '拍照美化',
      traffic: 16631,
      appType: '拍照美化',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '教育',
      traffic: 15043,
      appType: '教育',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '新闻阅读',
      traffic: 28239,
      appType: '新闻阅读',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '旅游住宿',
      traffic: 3267,
      appType: '旅游住宿',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '汽车',
      traffic: 5066,
      appType: '汽车',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '社交通讯',
      traffic: 12812,
      appType: '社交通讯',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '美食',
      traffic: 11276,
      appType: '美食',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '购物比价',
      traffic: 14887,
      appType: '购物比价',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '运动健康',
      traffic: 3181,
      appType: '运动健康',
      time: '23'
    },
    {
      mdate: '20220509',
      mhour: '23',
      type: '金融理财',
      traffic: 21477,
      appType: '金融理财',
      time: '23'
    }
  ]
}
