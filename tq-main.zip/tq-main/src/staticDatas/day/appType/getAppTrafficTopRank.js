export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 35982,
      proportion: 0.005047143,
      ranking: 1,
      appName: '腾讯地图',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 33535,
      proportion: 0.004703906,
      ranking: 2,
      appName: '美团优选',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31927,
      proportion: 0.004478354,
      ranking: 3,
      appName: '曹操出行',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31739,
      proportion: 0.0044519836,
      ranking: 4,
      appName: '天弘基金',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31710,
      proportion: 0.0044479156,
      ranking: 5,
      appName: '神州租车',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31688,
      proportion: 0.0044448297,
      ranking: 6,
      appName: '盒马',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31492,
      proportion: 0.004417337,
      ranking: 7,
      appName: 'Soul',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31359,
      proportion: 0.004398681,
      ranking: 8,
      appName: '招联金融',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 31269,
      proportion: 0.004386057,
      ranking: 9,
      appName: '马蜂窝',
      appSubtype: null,
      appType: null
    },
    {
      mdate: null,
      type: null,
      subtype: null,
      app: null,
      traffic: 30615,
      proportion: 0.0042943214,
      ranking: 10,
      appName: '阿卡索英语',
      appSubtype: null,
      appType: null
    }
  ]
}
