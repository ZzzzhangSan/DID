export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: null,
      encryptionType: '加密',
      traffic: 21213708,
      proportion: 0.7531178,
      peakValue: null,
      valleyValue: null,
      peakToValue: null,
      averageValue: null,
      peakToAverage: null,
      valleyToAverage: null,
      time: null
    },
    {
      mdate: null,
      encryptionType: '非密',
      traffic: 6954140,
      proportion: 0.24688219,
      peakValue: null,
      valleyValue: null,
      peakToValue: null,
      averageValue: null,
      peakToAverage: null,
      valleyToAverage: null,
      time: null
    }
  ]
}
