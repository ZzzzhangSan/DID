export const data = {
  status: 200,
  message: 'success',
  data: [
    {
      protocol: 'FTP',
      traffic: '30',
      proportion: 7.35,
      ranking: 1
    },
    {
      protocol: 'HTTP',
      traffic: '60',
      proportion: 7.78,
      ranking: 2
    },
    {
      protocol: 'HTTPS',
      traffic: '90',
      proportion: 4.58,
      ranking: 3
    },
    {
      protocol: 'SSL',
      traffic: '120',
      proportion: 3.1,
      ranking: 4
    },
    {
      protocol: 'XXL',
      traffic: '150',
      proportion: 6.1,
      ranking: 5
    }
  ]
}
