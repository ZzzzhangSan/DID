export const data = {
  code: 200,
  msg: 'success',
  data: [
    {
      transitType: '过境',
      proportion: '0.000361741',
      traffic: '42222601782'
    },
    {
      transitType: '境内',
      proportion: '0.096452053',
      traffic: '11257928150162'
    },
    {
      transitType: '出境',
      proportion: '0.185245250',
      traffic: '21621911057526'
    },
    {
      transitType: '入境',
      proportion: '0.717940956',
      traffic: '83798399643703'
    }
  ]
}
