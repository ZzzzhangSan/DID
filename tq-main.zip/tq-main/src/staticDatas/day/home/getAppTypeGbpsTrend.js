export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '00',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '00',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '00',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '00',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '00',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '00',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '00',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '00',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '00',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '00',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '01',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '01',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '01',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '01',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '01',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '01',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '01',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '01',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '01',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '01',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '02',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '02',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '02',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '02',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '02',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '02',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '02',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '02',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '02',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '02',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '03',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '03',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '03',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '03',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '03',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '03',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '03',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '03',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '03',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '03',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '04',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '04',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '04',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '04',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '04',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '04',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '04',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '04',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '04',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '04',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '05',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '05',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '05',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '05',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '05',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '05',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '05',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '05',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '05',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '05',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '06',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '06',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '06',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '06',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '06',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '06',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '06',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '06',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '06',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '06',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '07',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '07',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '07',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '07',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '07',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '07',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '07',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '07',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '07',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '07',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '08',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '08',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '08',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '08',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '08',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '08',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '08',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '08',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '08',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '08',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '09',
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '09',
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '09',
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '09',
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '09',
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '09',
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '09',
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '09',
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '09',
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '09',
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 10,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 10,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 10,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 10,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 10,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 10,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 10,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 10,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 10,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 10,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 11,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 11,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 11,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 11,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 11,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 11,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 11,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 11,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 11,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 11,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 12,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 12,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 12,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 12,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 12,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 12,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 12,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 12,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 12,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 12,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 13,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 13,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 13,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 13,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 13,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 13,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 13,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 13,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 13,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 13,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 14,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 14,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 14,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 14,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 14,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 14,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 14,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 14,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 14,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 14,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 15,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 15,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 15,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 15,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 15,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 15,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 15,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 15,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 15,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 15,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 16,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 16,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 16,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 16,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 16,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 16,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 16,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 16,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 16,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 16,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 17,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 17,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 17,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 17,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 17,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 17,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 17,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 17,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 17,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 17,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 18,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 18,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 18,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 18,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 18,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 18,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 18,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 18,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 18,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 18,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 19,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 19,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 19,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 19,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 19,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 19,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 19,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 19,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 19,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 19,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 20,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 20,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 20,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 20,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 20,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 20,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 20,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 20,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 20,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 20,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 21,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 21,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 21,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 21,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 21,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 21,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 21,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 21,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 21,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 21,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 22,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 22,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 22,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 22,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 22,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 22,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 22,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 22,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 22,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 22,
      gbps: 0.00855516
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 23,
      gbps: 8.888504
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 23,
      gbps: 0.84735
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 23,
      gbps: 0.6642821
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 23,
      gbps: 0.19980058
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 23,
      gbps: 0.11565394
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 23,
      gbps: 0.026777346
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 23,
      gbps: 0.026615458
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 23,
      gbps: 0.012608602
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 23,
      gbps: 0.009109453
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 23,
      gbps: 0.00855516
    }
  ]
}
