export const data = {
  code: 200,
  msg: 'ok',
  data: {
    all: {
      totalFlow: 16807746449366967,
      minFlow: 0,
      maxFlow: 2801291074876150
    },
    app: [
      {
        name: 'HTTP协议',
        value: 2303900212727500
      },
      {
        name: '未知流量',
        value: 219633121026423
      },
      {
        name: '常用协议',
        value: 172181913605470
      }
    ],
    ipver: [
      {
        name: 'IPv4',
        value: 2664001205773470
      },
      {
        name: 'IPv6',
        value: 137289869102675
      }
    ],
    transfer: [
      {
        name: 'TCP',
        value: 2383371022619320
      },
      {
        name: 'UDP',
        value: 417920052256919
      },
      {
        name: 'ICMP',
        value: 0
      },
      {
        name: 'IPv6-ICMP',
        value: 0
      }
    ],
    encryption: [
      {
        name: '加密',
        value: 2032182171752700
      },
      {
        name: '非加密',
        value: 549096105965768
      },
      {
        name: '未知',
        value: 220012797157682
      }
    ]
  }
}
