export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      proportion: 7.91598e-4,
      appType: '网络电话',
      traffic: 2217497462377
    },
    {
      proportion: 8.42886e-4,
      appType: '移动应用',
      traffic: 2361170222593
    },
    {
      proportion: 0.001166658,
      appType: '商业系统',
      traffic: 3268149750905
    },
    {
      proportion: 0.002462695,
      appType: '网络电视',
      traffic: 6898726646342
    },
    {
      proportion: 0.002477675,
      appType: '网络游戏',
      traffic: 6940687975760
    },
    {
      proportion: 0.010701316,
      appType: '社交',
      traffic: 29977500744673
    },
    {
      proportion: 0.0184873,
      appType: 'P2P下载',
      traffic: 51788311395778
    },
    {
      proportion: 0.0614652,
      appType: '常用协议',
      traffic: 172181913605470
    },
    {
      proportion: 0.07840425,
      appType: '未知流量',
      traffic: 219633121026423
    },
    {
      proportion: 0.8224423,
      appType: 'HTTP协议',
      traffic: 2303900212727500
    }
  ]
}
