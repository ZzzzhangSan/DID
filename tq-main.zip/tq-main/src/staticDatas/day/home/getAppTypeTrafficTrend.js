export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '00',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '00',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '00',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '00',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '00',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '00',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '00',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '00',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '00',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '00',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '01',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '01',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '01',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '01',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '01',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '01',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '01',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '01',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '01',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '01',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '02',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '02',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '02',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '02',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '02',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '02',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '02',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '02',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '02',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '02',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '03',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '03',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '03',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '03',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '03',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '03',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '03',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '03',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '03',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '03',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '04',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '04',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '04',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '04',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '04',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '04',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '04',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '04',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '04',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '04',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '05',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '05',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '05',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '05',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '05',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '05',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '05',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '05',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '05',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '05',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '06',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '06',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '06',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '06',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '06',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '06',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '06',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '06',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '06',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '06',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '07',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '07',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '07',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '07',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '07',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '07',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '07',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '07',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '07',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '07',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '08',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '08',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '08',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '08',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '08',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '08',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '08',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '08',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '08',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '08',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: '09',
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: '09',
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: '09',
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: '09',
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: '09',
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: '09',
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: '09',
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: '09',
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: '09',
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: '09',
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 10,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 10,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 10,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 10,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 10,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 10,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 10,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 10,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 10,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 10,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 11,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 11,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 11,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 11,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 11,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 11,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 11,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 11,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 11,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 11,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 12,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 12,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 12,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 12,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 12,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 12,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 12,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 12,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 12,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 12,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 13,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 13,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 13,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 13,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 13,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 13,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 13,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 13,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 13,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 13,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 14,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 14,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 14,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 14,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 14,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 14,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 14,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 14,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 14,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 14,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 15,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 15,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 15,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 15,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 15,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 15,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 15,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 15,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 15,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 15,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 16,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 16,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 16,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 16,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 16,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 16,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 16,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 16,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 16,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 16,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 17,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 17,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 17,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 17,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 17,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 17,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 17,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 17,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 17,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 17,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 18,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 18,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 18,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 18,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 18,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 18,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 18,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 18,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 18,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 18,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 19,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 19,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 19,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 19,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 19,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 19,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 19,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 19,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 19,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 19,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 20,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 20,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 20,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 20,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 20,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 20,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 20,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 20,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 20,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 20,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 21,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 21,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 21,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 21,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 21,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 21,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 21,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 21,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 21,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 21,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 22,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 22,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 22,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 22,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 22,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 22,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 22,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 22,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 22,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 22,
      traffic: 92395727599
    },
    {
      mdate: '20220927',
      appType: 'HTTP协议',
      time: 23,
      traffic: 95995842196979
    },
    {
      mdate: '20220927',
      appType: '未知流量',
      time: 23,
      traffic: 9151380042768
    },
    {
      mdate: '20220927',
      appType: '常用协议',
      time: 23,
      traffic: 7174246400228
    },
    {
      mdate: '20220927',
      appType: 'P2P下载',
      time: 23,
      traffic: 2157846308157
    },
    {
      mdate: '20220927',
      appType: '社交',
      time: 23,
      traffic: 1249062531028
    },
    {
      mdate: '20220927',
      appType: '网络游戏',
      time: 23,
      traffic: 289195332323
    },
    {
      mdate: '20220927',
      appType: '网络电视',
      time: 23,
      traffic: 287446943598
    },
    {
      mdate: '20220927',
      appType: '商业系统',
      time: 23,
      traffic: 136172906288
    },
    {
      mdate: '20220927',
      appType: '移动应用',
      time: 23,
      traffic: 98382092608
    },
    {
      mdate: '20220927',
      appType: '网络电话',
      time: 23,
      traffic: 92395727599
    }
  ]
}
