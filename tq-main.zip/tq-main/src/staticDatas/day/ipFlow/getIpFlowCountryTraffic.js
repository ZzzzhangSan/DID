export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: '20220510', country: '帕劳', ipver: 'ipv4', traffic: 83230, proportion: 0.8203152 },
    { mdate: '20220510', country: '贝宁', ipver: 'ipv4', traffic: 80994, proportion: 0.8153293 },
    { mdate: '20220510', country: '瑙鲁', ipver: 'ipv4', traffic: 81870, proportion: 0.81438375 },
    { mdate: '20220510', country: '黑山', ipver: 'ipv4', traffic: 82636, proportion: 0.81337845 },
    { mdate: '20220510', country: '马约特', ipver: 'ipv4', traffic: 81479, proportion: 0.81272566 },
    { mdate: '20220510', country: '洪都拉斯', ipver: 'ipv4', traffic: 81311, proportion: 0.8122734 },
    { mdate: '20220510', country: '塞浦路斯', ipver: 'ipv4', traffic: 81966, proportion: 0.8121959 },
    { mdate: '20220510', country: '匈牙利', ipver: 'ipv4', traffic: 82434, proportion: 0.81217366 },
    { mdate: '20220510', country: '西撒哈拉', ipver: 'ipv4', traffic: 82767, proportion: 0.8118312 },
    { mdate: '20220510', country: '东帝汶', ipver: 'ipv4', traffic: 80657, proportion: 0.81171626 }
  ]
}
