export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: '20220509', ipver: 'ipv4', dim: '曹操出行', traffic: 25695, proportion: 0.005, ranking: 1, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: 'Soul', traffic: 25113, proportion: 0.005, ranking: 2, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '腾讯地图', traffic: 24864, proportion: 0.005, ranking: 3, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '第一财经', traffic: 24044, proportion: 0.005, ranking: 4, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '招联金融', traffic: 23908, proportion: 0.005, ranking: 5, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '货拉拉', traffic: 23879, proportion: 0.005, ranking: 6, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '搜狗输入法', traffic: 23175, proportion: 0.005, ranking: 7, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '马蜂窝', traffic: 22870, proportion: 0.005, ranking: 8, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '阿卡索英语', traffic: 22580, proportion: 0.005, ranking: 9, dtype: null },
    { mdate: '20220509', ipver: 'ipv4', dim: '神州租车', traffic: 22409, proportion: 0.004, ranking: 10, dtype: null }
  ]
}
