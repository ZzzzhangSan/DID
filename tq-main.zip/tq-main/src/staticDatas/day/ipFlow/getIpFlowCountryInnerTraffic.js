export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: '20220510', country: '拉脱维亚', ipver: 'ipv4', traffic: 81641, proportion: 0.8088793 },
    { mdate: '20220510', country: '新加坡', ipver: 'ipv4', traffic: 82029, proportion: 0.8082551 },
    { mdate: '20220510', country: '美属萨摩亚', ipver: 'ipv4', traffic: 81759, proportion: 0.80609506 },
    { mdate: '20220510', country: '埃塞俄比亚', ipver: 'ipv4', traffic: 80208, proportion: 0.8023127 },
    { mdate: '20220510', country: '南非', ipver: 'ipv4', traffic: 81192, proportion: 0.8 },
    { mdate: '20220510', country: '法属南部领地', ipver: 'ipv4', traffic: 81664, proportion: 0.79887307 },
    { mdate: '20220510', country: '中国', ipver: 'ipv4', traffic: 2404067, proportion: 0.7972583 },
    { mdate: '20220510', country: '塞内加尔', ipver: 'ipv4', traffic: 82339, proportion: 0.79722506 },
    { mdate: '20220510', country: '马达加斯加', ipver: 'ipv4', traffic: 79025, proportion: 0.78846806 },
    { mdate: '20220510', country: '泽西岛', ipver: 'ipv4', traffic: 80059, proportion: 0.7840313 },
    { mdate: '20220510', country: '泽西岛', ipver: 'ipv6', traffic: 22053, proportion: 0.21596874 },
    { mdate: '20220510', country: '马达加斯加', ipver: 'ipv6', traffic: 21201, proportion: 0.21153194 },
    { mdate: '20220510', country: '塞内加尔', ipver: 'ipv6', traffic: 20943, proportion: 0.20277493 },
    { mdate: '20220510', country: '中国', ipver: 'ipv6', traffic: 611351, proportion: 0.20274171 },
    { mdate: '20220510', country: '法属南部领地', ipver: 'ipv6', traffic: 20560, proportion: 0.20112693 },
    { mdate: '20220510', country: '南非', ipver: 'ipv6', traffic: 20298, proportion: 0.2 },
    { mdate: '20220510', country: '埃塞俄比亚', ipver: 'ipv6', traffic: 19763, proportion: 0.19768733 },
    { mdate: '20220510', country: '美属萨摩亚', ipver: 'ipv6', traffic: 19667, proportion: 0.19390492 },
    { mdate: '20220510', country: '新加坡', ipver: 'ipv6', traffic: 19460, proportion: 0.19174492 },
    { mdate: '20220510', country: '拉脱维亚', ipver: 'ipv6', traffic: 19290, proportion: 0.19112067 }
  ]
}
