export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { mdate: '20220510', ipver: 'ipv4', traffic: 22518782, proportion: 0.79961276 },
    { mdate: '20220510', ipver: 'ipv6', traffic: 5643327, proportion: 0.20038722 }
  ]
}
