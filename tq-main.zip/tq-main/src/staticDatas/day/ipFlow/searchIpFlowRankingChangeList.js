export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    { mdate: '20220509', dim: 'telnet', rankingV4: 9, rankingV6: 17, change: -8, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'pop3s', rankingV4: 1, rankingV6: 7, change: -6, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'snmp', rankingV4: 11, rankingV6: 16, change: -5, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'srtp', rankingV4: 3, rankingV6: 8, change: -5, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'dns', rankingV4: 16, rankingV6: 18, change: -2, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'ntp', rankingV4: 12, rankingV6: 14, change: -2, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'rtp', rankingV4: 10, rankingV6: 11, change: -1, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'smtp', rankingV4: 19, rankingV6: 19, change: 0, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'tftp', rankingV4: 15, rankingV6: 15, change: 0, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'http', rankingV4: 13, rankingV6: 12, change: 1, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'ssh', rankingV4: 6, rankingV6: 5, change: 1, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'scp', rankingV4: 2, rankingV6: 1, change: 1, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'imaps', rankingV4: 8, rankingV6: 6, change: 2, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'https', rankingV4: 5, rankingV6: 3, change: 2, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'sftp', rankingV4: 4, rankingV6: 2, change: 2, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'ssmtp', rankingV4: 7, rankingV6: 4, change: 3, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'pop3', rankingV4: 17, rankingV6: 13, change: 4, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'imap', rankingV4: 14, rankingV6: 10, change: 4, dtype: null, trafficV4: null, trafficV6: null },
    { mdate: '20220509', dim: 'ftp', rankingV4: 18, rankingV6: 9, change: 9, dtype: null, trafficV4: null, trafficV6: null }
  ],
  total: 19
}
