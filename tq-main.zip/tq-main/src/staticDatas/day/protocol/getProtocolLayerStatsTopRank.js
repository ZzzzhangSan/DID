export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mdate: null,
      protocolLayer: '应用层',
      traffic: 28167848,
      proportion: 1,
      ranking: null
    }
  ]
}
