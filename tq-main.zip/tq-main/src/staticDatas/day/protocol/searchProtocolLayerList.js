export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    {
      mdate: '20220509',
      protocolLayer: '应用层',
      traffic: 28167848,
      proportion: 1,
      ranking: null
    }
  ],
  total: 1
}
