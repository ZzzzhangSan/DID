export const data = {
  code: 200,
  msg: 'ok',
  data: []
}
