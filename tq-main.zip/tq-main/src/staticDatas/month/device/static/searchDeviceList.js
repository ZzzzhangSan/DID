export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'ztebladea320',
      traffic: 1391363,
      proportion: 0.014122363,
      ranking: 1,
      deviceManufacturer: 'zte',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'vivoy15',
      traffic: 740852,
      proportion: 0.0075196633,
      ranking: 2,
      deviceManufacturer: 'vivo',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'lenovo pb1 750m',
      traffic: 739543,
      proportion: 0.0075063766,
      ranking: 3,
      deviceManufacturer: 'lenovo',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'sm a716u1',
      traffic: 732481,
      proportion: 0.0074346974,
      ranking: 4,
      deviceManufacturer: 'samsung',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'lenovol78121',
      traffic: 729657,
      proportion: 0.0074060336,
      ranking: 5,
      deviceManufacturer: 'lenovo',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'realme rmx1901',
      traffic: 727937,
      proportion: 0.0073885755,
      ranking: 6,
      deviceManufacturer: 'realme',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'macbook air m2',
      traffic: 725773,
      proportion: 0.007366611,
      ranking: 7,
      deviceManufacturer: 'apple',
      deviceType: 'PC',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'huawei jer an20',
      traffic: 725691,
      proportion: 0.0073657786,
      ranking: 8,
      deviceManufacturer: 'huawei',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'redminote',
      traffic: 725163,
      proportion: 0.0073604197,
      ranking: 9,
      deviceManufacturer: 'xiaomi',
      deviceType: '移动终端',
      mdate: '202205'
    },
    {
      mmonth: null,
      type: null,
      manufacturer: null,
      device: 'htc 0p6b6',
      traffic: 724991,
      proportion: 0.0073586735,
      ranking: 10,
      deviceManufacturer: 'htc',
      deviceType: '移动终端',
      mdate: '202205'
    }
  ]
}
