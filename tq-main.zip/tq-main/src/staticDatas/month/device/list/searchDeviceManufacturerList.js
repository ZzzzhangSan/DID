export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    { mmonth: null, manufacturer: null, traffic: 16132468, proportion: 0.16374488, ranking: 1, deviceManufacturer: 'zte', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 12620474, proportion: 0.12809807, ranking: 2, deviceManufacturer: 'htc', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 10460487, proportion: 0.10617416, ranking: 3, deviceManufacturer: 'samsung', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 9744546, proportion: 0.098907344, ranking: 4, deviceManufacturer: 'vivo', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 9045151, proportion: 0.09180847, ranking: 5, deviceManufacturer: 'lenovo', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 8289894, proportion: 0.084142596, ranking: 6, deviceManufacturer: 'huawei', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 7750456, proportion: 0.07866729, ranking: 7, deviceManufacturer: 'xiaomi', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 6982730, proportion: 0.070874855, ranking: 8, deviceManufacturer: 'oppo', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 6277413, proportion: 0.063715875, ranking: 9, deviceManufacturer: 'apple', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 4901713, proportion: 0.04975249, ranking: 10, deviceManufacturer: 'realme', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 3530465, proportion: 0.035834294, ranking: 11, deviceManufacturer: 'honor', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 1416888, proportion: 0.014381442, ranking: 12, deviceManufacturer: 'dell', mdate: '202205' },
    { mmonth: null, manufacturer: null, traffic: 1369281, proportion: 0.01389823, ranking: 13, deviceManufacturer: 'oneplus', mdate: '202205' }
  ],
  total: 13
}
