export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    { mmonth: null, type: null, traffic: 91483011, proportion: 0.9285545, ranking: 1, mdate: '202205', deviceType: '移动终端' },
    { mmonth: null, type: null, traffic: 7038955, proportion: 0.07144554, ranking: 2, mdate: '202205', deviceType: 'PC' }
  ],
  total: 2
}
