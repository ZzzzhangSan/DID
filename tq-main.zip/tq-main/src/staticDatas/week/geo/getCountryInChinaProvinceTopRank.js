export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 625802,
      proportion: 0.029580524,
      ranking: 1,
      inout: null,
      province: '宁夏回族自治区'
    },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 625655, proportion: 0.029573577, ranking: 2, inout: null, province: '山西省' },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 625324,
      proportion: 0.02955793,
      ranking: 3,
      inout: null,
      province: '新疆维吾尔自治区'
    },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 624860, proportion: 0.029535998, ranking: 4, inout: null, province: '北京市' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 624676, proportion: 0.029527301, ranking: 5, inout: null, province: '安徽省' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 624498, proportion: 0.029518887, ranking: 6, inout: null, province: '云南省' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 624115, proportion: 0.029500782, ranking: 7, inout: null, province: '贵州省' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 624099, proportion: 0.029500026, ranking: 8, inout: null, province: '广东省' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 623938, proportion: 0.029492417, ranking: 9, inout: null, province: '上海市' },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 623825, proportion: 0.029487075, ranking: 10, inout: null, province: '陕西省' }
  ]
}
