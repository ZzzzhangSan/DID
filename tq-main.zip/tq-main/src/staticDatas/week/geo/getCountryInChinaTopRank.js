export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: null, edate: null, country: '马达加斯加', traffic: 87196, proportion: 0.0041215965, ranking: 1, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '玻利维亚', traffic: 86609, proportion: 0.00409385, ranking: 2, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '基里巴斯', traffic: 86485, proportion: 0.0040879888, ranking: 3, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '匈牙利', traffic: 86293, proportion: 0.0040789135, ranking: 4, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '法属南部领地', traffic: 86273, proportion: 0.004077968, ranking: 5, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '索马里', traffic: 86230, proportion: 0.0040759356, ranking: 6, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '根西岛', traffic: 86179, proportion: 0.004073525, ranking: 7, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '老挝', traffic: 86068, proportion: 0.0040682782, ranking: 8, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '阿富汗', traffic: 86015, proportion: 0.004065773, ranking: 9, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '阿尔及利亚', traffic: 85913, proportion: 0.0040609515, ranking: 10, inout: null, mdate: 'null-null' }
  ]
}
