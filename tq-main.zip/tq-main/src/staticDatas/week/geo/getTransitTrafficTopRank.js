export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: '20220502', edate: '20220508', country1: '利比里亚', country2: '洪都拉斯', traffic: 5873, ranking: 1, mdate: '20220502-20220508' },
    { sdate: '20220502', edate: '20220508', country1: '塞尔维亚', country2: '美属维尔京群岛', traffic: 5821, ranking: 2, mdate: '20220502-20220508' },
    {
      sdate: '20220502',
      edate: '20220508',
      country1: '埃塞俄比亚',
      country2: '英属印度洋领地',
      traffic: 5793,
      ranking: 3,
      mdate: '20220502-20220508'
    },
    { sdate: '20220502', edate: '20220508', country1: '巴林', country2: '马约特', traffic: 5738, ranking: 4, mdate: '20220502-20220508' },
    { sdate: '20220502', edate: '20220508', country1: '匈牙利', country2: '法罗群岛', traffic: 5736, ranking: 5, mdate: '20220502-20220508' },
    {
      sdate: '20220502',
      edate: '20220508',
      country1: '巴西',
      country2: '赫德岛和麦克唐纳群岛',
      traffic: 5717,
      ranking: 6,
      mdate: '20220502-20220508'
    },
    { sdate: '20220502', edate: '20220508', country1: '埃塞俄比亚', country2: '爱尔兰', traffic: 5711, ranking: 7, mdate: '20220502-20220508' },
    { sdate: '20220502', edate: '20220508', country1: '哈萨克斯坦', country2: '纽埃', traffic: 5687, ranking: 8, mdate: '20220502-20220508' },
    { sdate: '20220502', edate: '20220508', country1: '埃塞俄比亚', country2: '安道尔', traffic: 5682, ranking: 9, mdate: '20220502-20220508' },
    { sdate: '20220502', edate: '20220508', country1: '北马里亚纳群岛', country2: '安哥拉', traffic: 5670, ranking: 10, mdate: '20220502-20220508' }
  ]
}
