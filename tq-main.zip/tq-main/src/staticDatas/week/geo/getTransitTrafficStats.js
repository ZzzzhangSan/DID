export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: null, edate: null, transit: null, traffic: 154959531, proportion: 0.78555655, transitType: '过境' },
    { sdate: null, edate: null, transit: null, traffic: 42301291, proportion: 0.21444345, transitType: '非过境' }
  ]
}
