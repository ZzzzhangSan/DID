export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    {
      sdate: '20220502',
      edate: '20220508',
      country: '乌兹别克斯坦',
      traffic: 174312,
      proportion: 0.004121745,
      ranking: 1,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '莫桑比克',
      traffic: 173034,
      proportion: 0.004091526,
      ranking: 2,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '泰国',
      traffic: 172936,
      proportion: 0.004089209,
      ranking: 3,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '美国',
      traffic: 172738,
      proportion: 0.0040845266,
      ranking: 4,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '布基纳法索',
      traffic: 172610,
      proportion: 0.0040815,
      ranking: 5,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '摩洛哥',
      traffic: 172570,
      proportion: 0.004080554,
      ranking: 6,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '匈牙利',
      traffic: 172484,
      proportion: 0.0040785205,
      ranking: 7,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '马拉维',
      traffic: 172450,
      proportion: 0.0040777167,
      ranking: 8,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '荷属圣马丁',
      traffic: 172444,
      proportion: 0.0040775747,
      ranking: 9,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '托克劳',
      traffic: 172372,
      proportion: 0.0040758722,
      ranking: 10,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '美属维尔京群岛',
      traffic: 172356,
      proportion: 0.004075494,
      ranking: 11,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '阿塞拜疆',
      traffic: 172298,
      proportion: 0.0040741228,
      ranking: 12,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '汤加',
      traffic: 172132,
      proportion: 0.004070197,
      ranking: 13,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '智利',
      traffic: 172112,
      proportion: 0.0040697246,
      ranking: 14,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '莱索托',
      traffic: 172040,
      proportion: 0.004068022,
      ranking: 15,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '几内亚',
      traffic: 171958,
      proportion: 0.004066083,
      ranking: 16,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '阿鲁巴',
      traffic: 171900,
      proportion: 0.0040647117,
      ranking: 17,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '新喀里多尼亚',
      traffic: 171828,
      proportion: 0.004063009,
      ranking: 18,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '古巴',
      traffic: 171814,
      proportion: 0.004062678,
      ranking: 19,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '黑山',
      traffic: 171586,
      proportion: 0.004057287,
      ranking: 20,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '土耳其',
      traffic: 171576,
      proportion: 0.00405705,
      ranking: 21,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '斯洛伐克',
      traffic: 171548,
      proportion: 0.004056388,
      ranking: 22,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '塔吉克斯坦',
      traffic: 171456,
      proportion: 0.004054213,
      ranking: 23,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '冰岛',
      traffic: 171442,
      proportion: 0.004053882,
      ranking: 24,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '保加利亚',
      traffic: 171432,
      proportion: 0.0040536453,
      ranking: 25,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '法属南部领地',
      traffic: 171412,
      proportion: 0.004053172,
      ranking: 26,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '圣多美和普林西比',
      traffic: 171296,
      proportion: 0.0040504294,
      ranking: 27,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '伊朗',
      traffic: 171256,
      proportion: 0.0040494837,
      ranking: 28,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '多米尼加共和国',
      traffic: 171236,
      proportion: 0.0040490106,
      ranking: 29,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '澳大利亚',
      traffic: 171228,
      proportion: 0.0040488215,
      ranking: 30,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '塞拉利昂',
      traffic: 171158,
      proportion: 0.0040471666,
      ranking: 31,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '纳米比亚',
      traffic: 171110,
      proportion: 0.0040460313,
      ranking: 32,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '印度',
      traffic: 171090,
      proportion: 0.0040455586,
      ranking: 33,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '坦桑尼亚',
      traffic: 171068,
      proportion: 0.004045038,
      ranking: 34,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '瑞典',
      traffic: 171068,
      proportion: 0.004045038,
      ranking: 35,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '乌干达',
      traffic: 171060,
      proportion: 0.004044849,
      ranking: 36,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '波黑',
      traffic: 171054,
      proportion: 0.0040447074,
      ranking: 37,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '马尔代夫',
      traffic: 171050,
      proportion: 0.0040446124,
      ranking: 38,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '新加坡',
      traffic: 170968,
      proportion: 0.004042674,
      ranking: 39,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '巴哈马',
      traffic: 170956,
      proportion: 0.00404239,
      ranking: 40,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '巴巴多斯',
      traffic: 170926,
      proportion: 0.0040416806,
      ranking: 41,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '格鲁吉亚',
      traffic: 170914,
      proportion: 0.004041397,
      ranking: 42,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '萨摩亚',
      traffic: 170912,
      proportion: 0.0040413495,
      ranking: 43,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '马提尼克',
      traffic: 170904,
      proportion: 0.0040411605,
      ranking: 44,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '格陵兰（丹）',
      traffic: 170804,
      proportion: 0.004038796,
      ranking: 45,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '爱沙尼亚',
      traffic: 170792,
      proportion: 0.004038512,
      ranking: 46,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '挪威',
      traffic: 170766,
      proportion: 0.004037897,
      ranking: 47,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '突尼斯',
      traffic: 170764,
      proportion: 0.00403785,
      ranking: 48,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '安哥拉',
      traffic: 170716,
      proportion: 0.004036715,
      ranking: 49,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '列支敦士登',
      traffic: 170668,
      proportion: 0.00403558,
      ranking: 50,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '安道尔',
      traffic: 170650,
      proportion: 0.0040351544,
      ranking: 51,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '东帝汶',
      traffic: 170612,
      proportion: 0.0040342556,
      ranking: 52,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '多哥',
      traffic: 170592,
      proportion: 0.004033783,
      ranking: 53,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '尼泊尔',
      traffic: 170588,
      proportion: 0.0040336885,
      ranking: 54,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '瑞士',
      traffic: 170586,
      proportion: 0.004033641,
      ranking: 55,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '斯瓦尔巴和扬马延',
      traffic: 170566,
      proportion: 0.004033168,
      ranking: 56,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '蒙古',
      traffic: 170558,
      proportion: 0.004032979,
      ranking: 57,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '爱尔兰',
      traffic: 170556,
      proportion: 0.0040329318,
      ranking: 58,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '博茨瓦纳',
      traffic: 170532,
      proportion: 0.004032364,
      ranking: 60,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '德国',
      traffic: 170532,
      proportion: 0.004032364,
      ranking: 59,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '洪都拉斯',
      traffic: 170452,
      proportion: 0.0040304726,
      ranking: 61,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '阿尔巴尼亚',
      traffic: 170400,
      proportion: 0.004029243,
      ranking: 62,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '巴布亚新几内亚',
      traffic: 170376,
      proportion: 0.004028675,
      ranking: 63,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '尼加拉瓜',
      traffic: 170298,
      proportion: 0.004026831,
      ranking: 64,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '黎巴嫩',
      traffic: 170284,
      proportion: 0.0040265,
      ranking: 65,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '皮特凯恩群岛',
      traffic: 170282,
      proportion: 0.0040264525,
      ranking: 66,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '塞内加尔',
      traffic: 170282,
      proportion: 0.0040264525,
      ranking: 67,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '以色列',
      traffic: 170256,
      proportion: 0.004025838,
      ranking: 68,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '哈萨克斯坦',
      traffic: 170200,
      proportion: 0.0040245135,
      ranking: 69,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '乌拉圭',
      traffic: 170168,
      proportion: 0.004023757,
      ranking: 70,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '厄立特里亚',
      traffic: 170148,
      proportion: 0.004023284,
      ranking: 71,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '卢旺达',
      traffic: 170132,
      proportion: 0.0040229056,
      ranking: 73,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '乍得',
      traffic: 170132,
      proportion: 0.0040229056,
      ranking: 72,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '巴林',
      traffic: 170108,
      proportion: 0.0040223384,
      ranking: 75,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '威尔士',
      traffic: 170108,
      proportion: 0.0040223384,
      ranking: 74,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '瑙鲁',
      traffic: 170002,
      proportion: 0.004019832,
      ranking: 76,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '马来西亚',
      traffic: 169994,
      proportion: 0.0040196427,
      ranking: 77,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '加沙地带',
      traffic: 169982,
      proportion: 0.004019359,
      ranking: 78,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '英属基地区',
      traffic: 169966,
      proportion: 0.0040189805,
      ranking: 79,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '乌克兰',
      traffic: 169916,
      proportion: 0.004017798,
      ranking: 80,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '约旦',
      traffic: 169888,
      proportion: 0.004017136,
      ranking: 82,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '克罗地亚',
      traffic: 169888,
      proportion: 0.004017136,
      ranking: 81,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '加蓬',
      traffic: 169880,
      proportion: 0.004016947,
      ranking: 84,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '斐济',
      traffic: 169880,
      proportion: 0.004016947,
      ranking: 83,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '苏丹',
      traffic: 169862,
      proportion: 0.0040165214,
      ranking: 85,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '圣皮埃尔和密克隆群岛',
      traffic: 169828,
      proportion: 0.0040157177,
      ranking: 86,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '吉布提',
      traffic: 169824,
      proportion: 0.0040156227,
      ranking: 87,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '安圭拉',
      traffic: 169816,
      proportion: 0.0040154336,
      ranking: 88,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '海地',
      traffic: 169802,
      proportion: 0.0040151025,
      ranking: 89,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '毛里塔尼亚',
      traffic: 169798,
      proportion: 0.004015008,
      ranking: 90,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '直布罗陀',
      traffic: 169784,
      proportion: 0.004014677,
      ranking: 91,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '罗马尼亚',
      traffic: 169762,
      proportion: 0.0040141568,
      ranking: 92,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '苏格兰',
      traffic: 169722,
      proportion: 0.004013211,
      ranking: 93,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '北马里亚纳群岛',
      traffic: 169710,
      proportion: 0.0040129274,
      ranking: 94,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '特克斯和凯科斯群岛',
      traffic: 169692,
      proportion: 0.004012502,
      ranking: 95,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '科科斯群岛',
      traffic: 169682,
      proportion: 0.0040122652,
      ranking: 96,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '荷兰',
      traffic: 169672,
      proportion: 0.0040120287,
      ranking: 97,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '西班牙',
      traffic: 169670,
      proportion: 0.004011981,
      ranking: 98,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '瓦努阿图',
      traffic: 169648,
      proportion: 0.004011461,
      ranking: 99,
      inout: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      country: '科特迪瓦',
      traffic: 169646,
      proportion: 0.004011414,
      ranking: 101,
      inout: null,
      mdate: '20220502-20220508'
    }
  ],
  total: 250
}
