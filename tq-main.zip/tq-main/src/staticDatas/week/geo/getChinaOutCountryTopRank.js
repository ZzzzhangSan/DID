export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: null, edate: null, country: '乌兹别克斯坦', traffic: 174312, proportion: 0.004121745, ranking: 1, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '莫桑比克', traffic: 173034, proportion: 0.004091526, ranking: 2, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '泰国', traffic: 172936, proportion: 0.004089209, ranking: 3, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '美国', traffic: 172738, proportion: 0.0040845266, ranking: 4, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '布基纳法索', traffic: 172610, proportion: 0.0040815, ranking: 5, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '摩洛哥', traffic: 172570, proportion: 0.004080554, ranking: 6, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '匈牙利', traffic: 172484, proportion: 0.0040785205, ranking: 7, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '马拉维', traffic: 172450, proportion: 0.0040777167, ranking: 8, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '荷属圣马丁', traffic: 172444, proportion: 0.0040775747, ranking: 9, inout: null, mdate: 'null-null' },
    { sdate: null, edate: null, country: '托克劳', traffic: 172372, proportion: 0.0040758722, ranking: 10, inout: null, mdate: 'null-null' }
  ]
}
