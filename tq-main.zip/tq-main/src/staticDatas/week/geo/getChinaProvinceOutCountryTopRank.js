export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1251170,
      proportion: 0.029584905,
      ranking: 1,
      inout: null,
      province: '浙江省'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1250658,
      proportion: 0.029572798,
      ranking: 2,
      inout: null,
      province: '贵州省'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1249352,
      proportion: 0.029541917,
      ranking: 3,
      inout: null,
      province: '云南省'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1249104,
      proportion: 0.029536052,
      ranking: 4,
      inout: null,
      province: '青海省'
    },
    { sdate: '20220502', edate: '20220508', provinceCn: null, traffic: 1249018, proportion: 0.02953402, ranking: 5, inout: null, province: '澳门' },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1248646,
      proportion: 0.029525222,
      ranking: 6,
      inout: null,
      province: '天津市'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1248282,
      proportion: 0.029516615,
      ranking: 7,
      inout: null,
      province: '四川省'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1248210,
      proportion: 0.029514913,
      ranking: 8,
      inout: null,
      province: '吉林省'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1248024,
      proportion: 0.029510515,
      ranking: 9,
      inout: null,
      province: '上海市'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      provinceCn: null,
      traffic: 1247852,
      proportion: 0.029506449,
      ranking: 10,
      inout: null,
      province: '湖南省'
    }
  ]
}
