export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: null, edate: null, encryptionType: '加密', traffic: 148642005, proportion: 0.7534236 },
    { sdate: null, edate: null, encryptionType: '非密', traffic: 48646764, proportion: 0.24657644 }
  ]
}
