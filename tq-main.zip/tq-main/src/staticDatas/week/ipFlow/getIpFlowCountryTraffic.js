export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: '20220523', edate: '20220529', country: '多哥', ipver: 'ipv4', traffic: 566691, proportion: 0.8069946 },
    { sdate: '20220523', edate: '20220529', country: '马耳他', ipver: 'ipv4', traffic: 567094, proportion: 0.8059067 },
    { sdate: '20220523', edate: '20220529', country: '法国', ipver: 'ipv4', traffic: 570596, proportion: 0.80576265 },
    { sdate: '20220523', edate: '20220529', country: '丹麦', ipver: 'ipv4', traffic: 565479, proportion: 0.8054981 },
    { sdate: '20220523', edate: '20220529', country: '西撒哈拉', ipver: 'ipv4', traffic: 569590, proportion: 0.80500823 },
    { sdate: '20220523', edate: '20220529', country: '德国', ipver: 'ipv4', traffic: 569861, proportion: 0.8048918 },
    { sdate: '20220523', edate: '20220529', country: '开曼群岛', ipver: 'ipv4', traffic: 565372, proportion: 0.8044965 },
    { sdate: '20220523', edate: '20220529', country: '土库曼斯坦', ipver: 'ipv4', traffic: 568832, proportion: 0.80445766 },
    { sdate: '20220523', edate: '20220529', country: '尼日尔', ipver: 'ipv4', traffic: 564209, proportion: 0.80442584 },
    { sdate: '20220523', edate: '20220529', country: '根西岛', ipver: 'ipv4', traffic: 567751, proportion: 0.8044203 }
  ]
}
