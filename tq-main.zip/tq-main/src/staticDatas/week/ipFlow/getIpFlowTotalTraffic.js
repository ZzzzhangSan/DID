export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: '20220502', edate: '20220508', ipver: 'ipv4', traffic: 157814065, proportion: 0.80002743, mdate: null },
    { sdate: '20220502', edate: '20220508', ipver: 'ipv6', traffic: 39446757, proportion: 0.19997258, mdate: null }
  ]
}
