export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '咕咚',
      traffic: 141875,
      proportion: 0.0040295925,
      ranking: 1,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '口袋故事',
      traffic: 138505,
      proportion: 0.0039338763,
      ranking: 2,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '咪咕阅读',
      traffic: 138501,
      proportion: 0.0039337627,
      ranking: 3,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '小豆苗',
      traffic: 137456,
      proportion: 0.003904082,
      ranking: 4,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '网易有道词典',
      traffic: 136679,
      proportion: 0.0038820135,
      ranking: 5,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '爱回收',
      traffic: 135677,
      proportion: 0.0038535544,
      ranking: 6,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '钉钉',
      traffic: 135116,
      proportion: 0.0038376206,
      ranking: 7,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '云闪付',
      traffic: 135044,
      proportion: 0.0038355757,
      ranking: 8,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '美柚',
      traffic: 134444,
      proportion: 0.003818534,
      ranking: 9,
      dtype: null,
      mdate: '20220502-20220508'
    },
    {
      sdate: '20220502',
      edate: '20220508',
      ipver: 'ipv4',
      dim: '番茄免费小说',
      traffic: 134263,
      proportion: 0.0038133934,
      ranking: 10,
      dtype: null,
      mdate: '20220502-20220508'
    }
  ]
}
