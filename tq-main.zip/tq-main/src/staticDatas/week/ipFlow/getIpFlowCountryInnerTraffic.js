export const data = {
  code: 200,
  msg: 'ok',
  data: [
    { sdate: '20220523', edate: '20220529', country: '法属南部领地', ipver: 'ipv4', traffic: 568706, proportion: 0.80337054 },
    { sdate: '20220523', edate: '20220529', country: '泽西岛', ipver: 'ipv4', traffic: 568508, proportion: 0.8029343 },
    { sdate: '20220523', edate: '20220529', country: '拉脱维亚', ipver: 'ipv4', traffic: 570278, proportion: 0.8022063 },
    { sdate: '20220523', edate: '20220529', country: '新加坡', ipver: 'ipv4', traffic: 566530, proportion: 0.80155575 },
    { sdate: '20220523', edate: '20220529', country: '南非', ipver: 'ipv4', traffic: 566737, proportion: 0.80121493 },
    { sdate: '20220523', edate: '20220529', country: '马达加斯加', ipver: 'ipv4', traffic: 566675, proportion: 0.8012077 },
    { sdate: '20220523', edate: '20220529', country: '中国', ipver: 'ipv4', traffic: 16939126, proportion: 0.7997035 },
    { sdate: '20220523', edate: '20220529', country: '塞内加尔', ipver: 'ipv4', traffic: 561779, proportion: 0.79614043 },
    { sdate: '20220523', edate: '20220529', country: '埃塞俄比亚', ipver: 'ipv4', traffic: 563922, proportion: 0.79566276 },
    { sdate: '20220523', edate: '20220529', country: '美属萨摩亚', ipver: 'ipv4', traffic: 561105, proportion: 0.7938757 },
    { sdate: '20220523', edate: '20220529', country: '美属萨摩亚', ipver: 'ipv6', traffic: 145687, proportion: 0.20612429 },
    { sdate: '20220523', edate: '20220529', country: '埃塞俄比亚', ipver: 'ipv6', traffic: 144823, proportion: 0.20433724 },
    { sdate: '20220523', edate: '20220529', country: '塞内加尔', ipver: 'ipv6', traffic: 143849, proportion: 0.20385954 },
    { sdate: '20220523', edate: '20220529', country: '中国', ipver: 'ipv6', traffic: 4242633, proportion: 0.20029654 },
    { sdate: '20220523', edate: '20220529', country: '马达加斯加', ipver: 'ipv6', traffic: 140601, proportion: 0.19879226 },
    { sdate: '20220523', edate: '20220529', country: '南非', ipver: 'ipv6', traffic: 140610, proportion: 0.19878504 },
    { sdate: '20220523', edate: '20220529', country: '新加坡', ipver: 'ipv6', traffic: 140258, proportion: 0.19844423 },
    { sdate: '20220523', edate: '20220529', country: '拉脱维亚', ipver: 'ipv6', traffic: 140609, proportion: 0.19779374 },
    { sdate: '20220523', edate: '20220529', country: '泽西岛', ipver: 'ipv6', traffic: 139530, proportion: 0.1970657 },
    { sdate: '20220523', edate: '20220529', country: '法属南部领地', ipver: 'ipv6', traffic: 139194, proportion: 0.19662946 }
  ]
}
