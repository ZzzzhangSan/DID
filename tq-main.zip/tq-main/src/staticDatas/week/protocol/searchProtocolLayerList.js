export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    {
      sdate: '20220509',
      edate: '20220515',
      protocolLayer: '应用层',
      traffic: 197288769,
      proportion: 1,
      mdate: '20220509-20220515'
    }
  ],
  total: 1
}
