export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: null,
      edate: null,
      protocolLayer: '应用层',
      traffic: 197260822,
      proportion: 1,
      mdate: 'null-null'
    }
  ]
}
