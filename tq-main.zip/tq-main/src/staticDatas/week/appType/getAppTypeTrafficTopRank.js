export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: null,
      edate: null,
      type: '新闻阅读',
      traffic: 6614032,
      proportion: 0.13140231,
      ranking: 1,
      mdate: 'null-null',
      appType: '新闻阅读'
    },
    {
      sdate: null,
      edate: null,
      type: '金融理财',
      traffic: 4474443,
      proportion: 0.08889466,
      ranking: 2,
      mdate: 'null-null',
      appType: '金融理财'
    },
    {
      sdate: null,
      edate: null,
      type: '教育',
      traffic: 4132283,
      proportion: 0.0820969,
      ranking: 3,
      mdate: 'null-null',
      appType: '教育'
    },
    {
      sdate: null,
      edate: null,
      type: '商务',
      traffic: 4126081,
      proportion: 0.08197369,
      ranking: 4,
      mdate: 'null-null',
      appType: '商务'
    },
    {
      sdate: null,
      edate: null,
      type: '拍照美化',
      traffic: 3861950,
      proportion: 0.07672614,
      ranking: 5,
      mdate: 'null-null',
      appType: '拍照美化'
    },
    {
      sdate: null,
      edate: null,
      type: '购物比价',
      traffic: 3390778,
      proportion: 0.067365274,
      ranking: 6,
      mdate: 'null-null',
      appType: '购物比价'
    },
    {
      sdate: null,
      edate: null,
      type: '出行导航',
      traffic: 3241917,
      proportion: 0.06440782,
      ranking: 7,
      mdate: 'null-null',
      appType: '出行导航'
    },
    {
      sdate: null,
      edate: null,
      type: '实用工具',
      traffic: 3111731,
      proportion: 0.061821386,
      ranking: 8,
      mdate: 'null-null',
      appType: '实用工具'
    },
    {
      sdate: null,
      edate: null,
      type: '美食',
      traffic: 3038536,
      proportion: 0.060367208,
      ranking: 9,
      mdate: 'null-null',
      appType: '美食'
    },
    {
      sdate: null,
      edate: null,
      type: '便捷生活',
      traffic: 2878485,
      proportion: 0.05718744,
      ranking: 10,
      mdate: 'null-null',
      appType: '便捷生活'
    }
  ]
}
