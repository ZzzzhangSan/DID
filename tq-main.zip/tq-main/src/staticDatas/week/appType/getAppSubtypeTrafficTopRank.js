export const data = {
  code: 200,
  msg: 'ok',
  data: [
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1909859,
      proportion: 0.0378728,
      ranking: 1,
      appSubtype: '新闻',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1557632,
      proportion: 0.030888082,
      ranking: 2,
      appSubtype: '银行',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1553620,
      proportion: 0.030808523,
      ranking: 3,
      appSubtype: '电子书',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1406255,
      proportion: 0.027886253,
      ranking: 4,
      appSubtype: '办公软件',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1362716,
      proportion: 0.027022868,
      ranking: 5,
      appSubtype: '学习',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1204013,
      proportion: 0.023875762,
      ranking: 6,
      appSubtype: '英文',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1144401,
      proportion: 0.022693647,
      ranking: 7,
      appSubtype: '用车',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1069832,
      proportion: 0.021214932,
      ranking: 8,
      appSubtype: '招聘',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1035832,
      proportion: 0.020540707,
      ranking: 9,
      appSubtype: '商城',
      appType: null,
      mdate: 'null-null'
    },
    {
      sdate: null,
      edate: null,
      type: null,
      subtype: null,
      traffic: 1017001,
      proportion: 0.020167286,
      ranking: 10,
      appSubtype: '股票基金',
      appType: null,
      mdate: 'null-null'
    }
  ]
}
