export const data = {
  code: 200,
  msg: '查询成功',
  data: [
    {
      sdate: '20220509',
      edate: '20220515',
      type: '新闻阅读',
      traffic: 6614032,
      proportion: 0.13140231,
      ranking: 1,
      mdate: '20220509-20220515',
      appType: '新闻阅读'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '金融理财',
      traffic: 4474443,
      proportion: 0.08889466,
      ranking: 2,
      mdate: '20220509-20220515',
      appType: '金融理财'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '教育',
      traffic: 4132283,
      proportion: 0.0820969,
      ranking: 3,
      mdate: '20220509-20220515',
      appType: '教育'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '商务',
      traffic: 4126081,
      proportion: 0.08197369,
      ranking: 4,
      mdate: '20220509-20220515',
      appType: '商务'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '拍照美化',
      traffic: 3861950,
      proportion: 0.07672614,
      ranking: 5,
      mdate: '20220509-20220515',
      appType: '拍照美化'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '购物比价',
      traffic: 3390778,
      proportion: 0.067365274,
      ranking: 6,
      mdate: '20220509-20220515',
      appType: '购物比价'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '出行导航',
      traffic: 3241917,
      proportion: 0.06440782,
      ranking: 7,
      mdate: '20220509-20220515',
      appType: '出行导航'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '实用工具',
      traffic: 3111731,
      proportion: 0.061821386,
      ranking: 8,
      mdate: '20220509-20220515',
      appType: '实用工具'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '美食',
      traffic: 3038536,
      proportion: 0.060367208,
      ranking: 9,
      mdate: '20220509-20220515',
      appType: '美食'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '便捷生活',
      traffic: 2878485,
      proportion: 0.05718744,
      ranking: 10,
      mdate: '20220509-20220515',
      appType: '便捷生活'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '社交通讯',
      traffic: 2759855,
      proportion: 0.054830596,
      ranking: 11,
      mdate: '20220509-20220515',
      appType: '社交通讯'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '影音娱乐',
      traffic: 2614966,
      proportion: 0.051952057,
      ranking: 12,
      mdate: '20220509-20220515',
      appType: '影音娱乐'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '汽车',
      traffic: 1706736,
      proportion: 0.03390807,
      ranking: 13,
      mdate: '20220509-20220515',
      appType: '汽车'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '旅游住宿',
      traffic: 1547521,
      proportion: 0.030744912,
      ranking: 14,
      mdate: '20220509-20220515',
      appType: '旅游住宿'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '运动健康',
      traffic: 1498899,
      proportion: 0.02977893,
      ranking: 15,
      mdate: '20220509-20220515',
      appType: '运动健康'
    },
    {
      sdate: '20220509',
      edate: '20220515',
      type: '儿童',
      traffic: 1336002,
      proportion: 0.02654262,
      ranking: 16,
      mdate: '20220509-20220515',
      appType: '儿童'
    }
  ],
  total: 16
}
