<template>
  <div>
    <div class="navbar">
      <!-- 图标 -->
      <!-- <hamburger id="hamburger-container" :is-active="sidebar.opened" class="hamburger-container" @toggle-click="toggleSideBar" /> -->
      <!-- <div class="breadcrumb">
        <breadcrumb />
      </div> -->
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
import Breadcrumb from '../Breadcrumb/index.vue'
import Hamburger from '../Hamburger/index.vue'
import { AppModule } from '@/store/modules/app'
import { UserModule } from '@/store/modules/user'

@Component({
  name: 'Navbar',
  components: {
    Breadcrumb,
    Hamburger
  }
})
export default class extends Vue {
  // 获取当前菜单展开折叠状态
  get sidebar() {
    // console.log('tags', AppModule.sidebar)
    return AppModule.sidebar
  }
  // 切换菜单栏展开 收起
  toggleSideBar() {
    AppModule.ToggleSideBar(false)
  }
  private async logout() {
    await UserModule.LogOut()
    this.$router.push(`/login?redirect=${this.$route.fullPath}`).catch(err => {
      console.warn(err)
    })
  }
}
</script>

<style lang="less">
.navbar {
  overflow: hidden;
  position: relative;
  // background: #f6f8f9;

  .hamburger-container {
    height: 100%;
    cursor: pointer;
    color: #666;
    padding: 0 7px;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;
    margin-top: 2px;

    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }
}
</style>
