<template>
  <div class="app-header-container">
    <div class="fixed-header">
      <Navbar />
    </div>
    <!-- <div class="right-menu">
      <div class="avatarIcon">
        <el-avatar class="avatarBox"></el-avatar>
      </div>

      <div class="avatar-box">
        <div class="user-name">
          <span>您好，admin</span>
        </div>
      </div>
      <i
        :class="isScreenFull ? 'iconfont icon-quxiaoquanping_o logoutIcon' : 'iconfont icon-quanping_o logoutIcon'"
        @click="handleClick"
        :title="isScreenFull ? '退出全屏' : '进入全屏'"
      ></i>
      <i class="iconfont icon-CZ_038 logoutIcon" @click="handleLogout" title="退出系统"></i>
    </div> -->
    <el-dialog title="修改密码" :visible.sync="dialogShow" width="500px">
      <VForm :option="dialogFormOpt" ref="dialogForm"></VForm>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleSave">保 存</el-button>
        <el-button @click="dialogShow = false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch, Ref } from 'vue-property-decorator'
import { trim, assign } from 'lodash'
import settings from '@/settings'
import { http } from '@/common/request'
import { UserModule } from '@/store/modules/user'
import Navbar from '../Navbar/index.vue'
import { removeToken } from '@/utils/cookies'
import screenfull from 'screenfull'

@Component({
  components: {
    Navbar
  }
})
export default class HeaderBar extends Vue {
  @Ref() readonly dialogForm!: VP.VForm
  // @Prop({ required: true }) private collapse!: boolean
  private isScreenFull: any = false
  private title = settings.title
  private dialogShow = false
  private id = ''
  private alarmCount = 0
  private msgList = [
    { title: '告警消息账号列表', id: '1', type: 'account' },
    { title: '告警消息视频列表', id: '2', type: 'video' }
  ]
  private dialogParams = {
    id: '',
    // username: '',
    nickname: '',
    password: '',
    passwordConfirm: ''
  }
  private dialogFormOpt: any = {
    inline: true,
    labelWidth: 100,
    items: [
      {
        label: '用户名：',
        type: 'text',
        wrap: true,
        required: true,
        comOpt: {
          id: 'username',
          width: 220,
          disabled: true
        }
      },
      {
        label: '姓名：',
        type: 'text',
        wrap: true,
        required: true,
        comOpt: {
          id: 'nickname',
          width: 220
        }
      },
      {
        label: '密码：',
        type: 'text',
        wrap: true,
        required: true,
        comOpt: {
          id: 'password',
          type: 'password',
          width: 220
        }
      },
      {
        label: '确认密码：',
        type: 'text',
        wrap: true,
        required: true,
        comOpt: {
          id: 'passwordConfirm',
          type: 'password',
          width: 220
        }
      }
    ]
  }

  get sysUserName() {
    return UserModule.getUserName
  }
  handleLogout() {
    UserModule.ResetToken()
    removeToken()
  }
  handleGoMsgPage() {
    this.$router.push({ name: '消息管理' })
  }
  handleClick() {
    if (!screenfull.isEnabled) {
      this.$message({
        message: '您的浏览器不支持全屏',
        type: 'warning'
      })
      return false
    }
    screenfull.toggle()
    this.isScreenFull = !this.isScreenFull
  }
  @Watch('$route')
  private onRouteChange(newVal, val) {
    if (val.path === '/MenuIndex') {
      this.init()
    }
  }
  mounted() {}
  init() {}
  // 修改密码
  handleEdit() {
    this.dialogShow = true
    const me = this
    this.$nextTick(() => {
      me.dialogForm.clearValue()
      me.dialogForm.setValue([{ id: 'username', value: UserModule.getUserName }])
    })
  }
  //保存
  handleSave() {
    assign(this.dialogParams, this.dialogForm.getValue())
    // this.dialogParams.password = trim(this.dialogParams.password) === '' ? '' : window.md5(window.md5(trim(this.dialogParams.password)))
    this.dialogParams.nickname = trim(this.dialogParams.nickname)
    this.dialogParams.password = trim(this.dialogParams.password)
  }
  // 必选项校验
  handleRequired() {
    if (this.dialogParams.password === '') {
      this.$message({
        type: 'error',
        message: '请输入密码'
      })
      return false
    }
    if (this.dialogParams.passwordConfirm === '') {
      this.$message({
        type: 'error',
        message: '请输入确认密码'
      })
      return false
    }
    if (this.dialogParams.password != this.dialogParams.passwordConfirm) {
      this.$message({
        type: 'error',
        message: '两次密码输入不一致，请重新输入密码'
      })
      return false
    }
    return true
  }
}
</script>

<style lang="less">
.app-header-container {
  width: 100%;
  position: relative;
  background-color: #fff;
}
@media (min-height: 700px) and (max-height: 2000px) {
  .app-header-container {
    height: 60px;
    line-height: 60px;
    z-index: 1;
  }
}
@media (max-height: 700px) {
  .app-header-container {
    height: 40px;
    line-height: 40px;
  }
}

.titleBox {
  display: inline-block;
  font-size: 18px;
  font-weight: 600;
  font-family: Avenir, Helvetica Neue, Arial, Helvetica, sans-serif;
  vertical-align: middle;
  position: absolute;
  top: 14px;
  left: 66px;
  color: #3d3d3d;
}
.avatar-box:hover {
  background-color: #f6f6f6;
}
.avatar-box {
  display: flex;
  align-items: center;
}
.right-menu {
  height: 100%;
  position: absolute;
  right: 10px;
  top: 0px;
  display: flex;
  align-items: center;
  .notice-box {
    display: inline-block;
    width: 28px;
    height: 28px;
    margin-right: 20px;
    line-height: 28px;
    text-align: center;
    font-size: 14px;
    color: #0c2743;
    position: relative;
    .iconfont {
      font-size: 18px;
    }
    &:hover {
      cursor: pointer;
    }
  }
  .notice-number {
    width: 18px;
    height: 18px;
    line-height: 16px;
    text-align: center;
    border-radius: 50%;
    color: #fff;
    padding: 2px;
    background: #dd2626;
    font-size: 10px;
    position: absolute;
    right: -7px;
    top: -5px;
  }
  @media (min-height: 700px) and (max-height: 2000px) {
    .el-avatar {
      width: 40px;
      height: 40px;
      line-height: 40px;
      background: #f6f6f6;
    }
  }
  @media (max-height: 700px) {
    .el-avatar {
      width: 28px;
      height: 28px;
      line-height: 28px;
      background: #f6f6f6;
    }
  }

  &:focus {
    outline: none;
  }
  .avatarIcon {
    cursor: pointer;
    display: flex;
    align-items: center;
    .avatarBox {
      background: url('~@/assets/images/login/avatar.png') no-repeat;
      background-size: cover;
    }
  }
  .user-name {
    color: #202225;
    // display: flex;
    margin-left: 10px;
    // align-items: center;
    span {
      border-bottom: 1px solid rgba(255, 255, 255, 0.3);
      color: #202225;
      height: 26px;
      line-height: 26px;
      padding: 0 3px;
      cursor: pointer;
      &:hover {
        color: #202225;
        border-bottom: 1px solid rgba(255, 255, 255, 0.8);
      }
    }
  }
  .logoutIcon {
    color: #0c2743;
    margin-left: 15px;
    cursor: pointer;
    margin-right: 23px;
    font-size: 18px;
  }
  .right-menu-item {
    display: inline-block;
    padding: 0 8px;
    height: 100%;
    font-size: 16px;
    color: #fff;
    // color: #5a5e66;
    vertical-align: text-bottom;
    &.hover-effect {
      cursor: pointer;
      transition: background 0.3s;
      &:hover {
        background: rgba(0, 0, 0, 0.025);
      }
    }
  }
}
.alarmSingle {
  .alarmMore {
    text-align: center;
    height: 40px;
    line-height: 40px;
    color: #fff;
  }
  li {
    height: 40px;
    line-height: 40px;
    padding: 0 12px;
    &:hover {
      cursor: pointer;
      background: #2c3647;
    }
  }
}
</style>
