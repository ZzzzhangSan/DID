<template>
  <div class="tagsBox">
    <div class="tags-view-container">
      <el-tabs type="card" :closable="isAffix(selectedTag) ? true : false" v-model="activeName" @tab-click="tabClick" @tab-remove="closeSelectedTag">
        <el-tab-pane v-for="(tag, index) in visitedViews" :index="index" :key="tag.path" :name="tag.path">
          <span slot="label">
            <i :class="['iconfont', 'fontIconBox', tag.meta.icon]"></i>
            {{ tag.meta.title }}
          </span>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div class="tags-view-iconContain">
      <i class="iconBox homeIcon iconfont icon-all-fill" @click.prevent.stop="openMenu(selectedTag, $event)"></i>
    </div>
    <ul v-show="visible" :style="{ left: left + 'px', top: top + 'px' }" class="contextmenu">
      <li @click="refreshSelectedTag(selectedTag)">
        <i class="iconBox iconfont icon-icon-ys-refresh"></i>
        刷新
      </li>
      <template v-if="isAffix(selectedTag)">
        <li @click="closeSelectedTag(selectedTag.path)">
          <i class="iconBox iconfont icon-dangqiandingwei"></i>
          关闭当前页
        </li>
        <li @click="closeOthersTags">
          <i class="iconBox iconfont icon-other"></i>
          关闭其他页面
        </li>
        <li @click="closeAllTags(selectedTag)">
          <i class="iconBox iconfont icon-close"></i>
          关闭所有
        </li>
      </template>
    </ul>
  </div>
</template>

<script lang="ts">
import path from 'path'
import { Component, Vue, Watch } from 'vue-property-decorator'
import { TagsViewModule, ITagView } from '@/store/modules/tags-view'
import { AppModule } from '@/store/modules/app'
import Hamburger from '../Hamburger/index.vue'

@Component({
  name: 'TagsView',
  components: {
    Hamburger
  }
})
export default class TagsView extends Vue {
  private visible = false
  private top = 0
  private left = 0
  private selectedTag: ITagView = {}
  private affixTags: ITagView[] = []
  private showCloseAll = false
  private showCloseOn = false
  private activeName = ''
  get sidebar() {
    return AppModule.sidebar
  }
  get visitedViews() {
    return TagsViewModule.visitedViews
  }
  mounted() {
    const me = this
    this.addTags()
    this.activeName = this.$route.fullPath
    // 获取dom
    const tabTopDom = document.body.getElementsByClassName('el-tabs__nav is-top') as any
    // 使用原生js 为单个dom绑定鼠标右击事件
    tabTopDom[0].oncontextmenu = function(e) {
      me.openMenu('', e)
    }
    // console.log(this.selectedTag)
  }
  private isAffix(tag: ITagView) {
    if (this.visitedViews.length < 2) {
      return false
    }
    return tag.meta
  }

  private addTags() {
    const { name } = this.$route
    if (name === 'Refresh' || name === 'login') {
      return false
    }
    if (name) {
      TagsViewModule.addView(this.$route)
    }
    return false
  }
  private tabClick(tab) {
    this.$router.push({
      path: tab.name
    })
  }
  private closeSelectedTag(val) {
    this.visitedViews.map(item => {
      if (item.path === val) {
        TagsViewModule.delView(item)
        this.toLastView(TagsViewModule.visitedViews, item)
      }
    })
  }

  private toLastView(visitedViews: ITagView[], view: ITagView) {
    const latestView = visitedViews.slice(-1)[0]
    if (latestView !== undefined && latestView.fullPath !== undefined) {
      this.$router.push(latestView.fullPath).catch(err => {
        console.warn(err)
      })
    }
  }

  private refreshSelectedTag(view: ITagView) {
    this.$router.replace({
      path: '/refresh'
    })
  }
  private closeOthersTags() {
    if (this.selectedTag.fullPath !== this.$route.path && this.selectedTag.fullPath !== undefined) {
      this.$router.push(this.selectedTag.fullPath).catch(err => {
        console.warn(err)
      })
    }
    TagsViewModule.delOthersViews(this.selectedTag)
  }

  private closeAllTags(view: ITagView) {
    TagsViewModule.delAllViews()
    this.$router.push({
      path: '/home'
    })
    // if (this.$route.path === '/home-page') {
    //   this.refreshSelectedTag(this.selectedTag)
    // } else {
    //   this.$router.push({
    //     path: '/home-page'
    //   })
    // }
  }
  private openMenu(selectedTag, e: any) {
    e.preventDefault() //防止默认菜单弹出
    const tag = ''
    const menuMinWidth = 130
    const offsetLeft = this.$el.getBoundingClientRect().left
    const offsetWidth = (this.$el as HTMLElement).offsetWidth
    const maxLeft = offsetWidth - menuMinWidth
    const left = e.clientX - offsetLeft - 10
    if (left > maxLeft) {
      this.left = maxLeft
    } else {
      this.left = left
    }
    this.top = e.clientY - 35
    this.visible = true
    if (tag === '') {
      const currentContextTabId = e.srcElement.id.split('-')[1]
      this.visitedViews.map(item => {
        if (item.path === currentContextTabId) {
          this.selectedTag = item
        }
      })
    } else {
      this.selectedTag = tag
    }
  }
  private closeMenu() {
    this.visible = false
  }

  @Watch('$route')
  private onRouteChange(oldVal, val) {
    this.addTags()
    this.activeName = this.$route.fullPath
    // 跳转到导航页时删除页签已存在的页面
    if (oldVal.path === '/MenuIndex') {
      TagsViewModule.delAllViews()
    }
  }
  @Watch('visible')
  private onVisibleChange(value: boolean) {
    if (value) {
      document.body.addEventListener('click', this.closeMenu)
    } else {
      document.body.removeEventListener('click', this.closeMenu)
    }
  }
  @Watch('activeName')
  private activeNameChange(val) {
    this.visitedViews.map(item => {
      if (item.path === val) {
        this.selectedTag = item
      }
    })
  }
}
</script>
<style lang="less">
.tagsBox {
  background: #fff;
  position: relative;
  height: 48px;
  box-shadow: 0px 4px 10px 1px rgba(162, 162, 162, 0.3);
  border-top: 1px solid #d8d8d8;
}

.tags-view-iconContain {
  margin-right: -10px;
  position: absolute;
  right: 10px;
  z-index: 1;
  bottom: 5px;
  .iconBox {
    display: inline-block;
    height: 40px;
    line-height: 48px;
    color: #808080;
    text-align: center;
    font-size: 20px;
    margin-right: 16px;
    // &:hover {
    //   cursor: pointer;
    //   background: rgba(0, 0, 0, 0.025);
    // }
  }
  .homeIcon {
    transition: All 0.4s ease-in-out;
    &:hover {
      cursor: pointer;
      color: #6654f9;
      // transform: rotate(360deg);
    }
  }
}

.fontIconBox {
  font-size: 14px !important;
  margin-right: 5px;
}

.hamburger-container {
  float: left;
  margin-right: 10px;
  color: #666;
  text-align: center;
  // margin-left: 10px;
  cursor: pointer;
}

.tags-view-container {
  margin-left: 16px;
  width: calc(100% - 130px);
  height: 48px;
  background: #ffffff;
  .el-tabs--card > .el-tabs__header .el-tabs__item .el-icon-close {
    color: #6654f9;
  }
  .el-tabs__item .el-icon-close:hover {
    background: #f1f1f1;
  }
  .el-tabs__nav-wrap {
    margin-bottom: 0;
  }
  .el-tabs__header {
    padding: 0;
    position: relative;
    margin: 0px;
  }

  .el-tabs__item {
    // margin-right: -30px;
    // height: 38px;
    // margin-top: 11px;
    // line-height: 38px;
    text-align: center;
    border: 0;
    transition: padding 0.3s cubic-bezier(0.645, 0.045, 0.355, 1) !important;
  }
  .el-tabs--card > .el-tabs__header {
    border-bottom: 0;
  }
  .el-tabs--card > .el-tabs__header .el-tabs__item {
    border: 0;
    padding: 0 10px 0 10px;
  }
  .el-tabs__header .el-tabs__item.is-active,
  .el-tabs__header .el-tabs__item.is-active:hover,
  .el-tabs__header .el-tabs__item:hover {
    padding: 0 10px 0 10px;
    color: #6654f9;
    background: #f0eefe;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    mask-size: 100% 100%;
  }

  .el-tabs__item {
    color: #57595b;
  }

  .el-tabs--card > .el-tabs__header .el-tabs__item.is-active {
    height: 100%;
  }

  .el-tabs--card > .el-tabs__header .el-tabs__item.is-active.is-closable {
    padding: 0 10px 0 10px;
    background: #f0eefe;
  }
  .el-tabs--card > .el-tabs__header .el-tabs__item.is-closable:hover {
    padding: 0 10px 0 10px;
  }

  .el-tabs__header .el-tabs__item:hover {
    padding: 0 10px 0 10px;
    color: #6654f9;
    background: linear-gradient(transparent 0%, #f9f9f9 25%);
  }

  .el-tabs--card > .el-tabs__header .el-tabs__nav {
    border: 0;
  }

  .el-tabs__header .el-tabs__item.is-active:before {
    background-color: #409eff;
  }
}

@media (min-height: 700px) and (max-height: 2000px) {
  .tags-view-container {
    height: 47px;
    overflow: hidden;
    .el-tabs__item {
      height: 35px;
      line-height: 35px;
      margin-top: 12px;
    }
  }
}
@media (max-height: 700px) {
  .tags-view-container {
    height: 38px;
    .el-tabs__item {
      height: 38px;
      margin-top: 5px;
      line-height: 38px;
    }
  }
}

.contextmenu {
  margin: 0;
  background: #fff;
  z-index: 3000;
  position: absolute;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);

  li {
    margin: 0;
    padding: 7px 16px;
    cursor: pointer;
    &:hover {
      background: #eee;
    }
  }
}
</style>
