<template>
  <div>
    <!-- <transition name="sidebarLogoFade" v-if="showLogo">
      <router-link key="expand" to="/home">
        <div class="weBtitle">
          <i class="iconBox"></i>
          {{ title }}
        </div>
      </router-link>
    </transition> -->
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <side-item />
    </el-scrollbar>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
import { AppModule } from '@/store/modules/app'
import { SettingsModule } from '@/store/modules/settings'
import SideItem from './SideItem.vue'

@Component({
  name: 'SideBar',
  components: {
    SideItem
  }
})
export default class extends Vue {
  private title = process.env.VUE_APP_NAME
  get sidebar() {
    return AppModule.sidebar
  }

  get isCollapse() {
    return !this.sidebar.opened
  }

  // 是否显示菜单上方系统logo和名字
  get showLogo() {
    return SettingsModule.showSidebarLogo
  }

  get activeMenu() {
    const route = this.$route
    const { meta, path } = route
    // if set path, the sidebar will highlight the path you set
    if (meta.activeMenu) {
      return meta.activeMenu
    }
    return path
  }
}
</script>

<style lang="less">
.sidebarLogoFade-enter-active {
  transition: opacity 1.5s;
}

.sidebarLogoFade-enter,
.sidebarLogoFade-leave-to {
  opacity: 0;
}

.sidebar-container {
  margin-top: 20px;
  // reset element-ui css
  .horizontal-collapse-transition {
    transition: 0s width ease-in-out, 0s padding-left ease-in-out, 0s padding-right ease-in-out;
  }

  .scrollbar-wrapper {
    overflow-x: hidden !important;
  }

  .el-scrollbar__view {
    height: 100%;
    // user-select: none;
  }

  .el-scrollbar__bar {
    &.is-vertical {
      right: 0px;
    }

    &.is-horizontal {
      display: none;
    }
  }
}
.el-scrollbar {
  height: calc(100% - 98px);
}

.el-menu {
  border: none !important;
  height: 100%;
  width: 100% !important;
  background-size: cover;
}
.weBtitle {
  height: 60px;
  line-height: 64px;
  background-color: #fff;
  color: #282c34;
  font-size: 18px;
  font-weight: bold;
  padding-left: 20px;
  .iconBox {
    width: 28px;
    height: 28px;
    float: left;
    background: url('~@/assets/images/login/logo.png') no-repeat;
    margin-top: 18px;
    margin-right: 8px;
  }

  i {
    font-size: 24px;
    vertical-align: bottom;
  }
}
</style>
