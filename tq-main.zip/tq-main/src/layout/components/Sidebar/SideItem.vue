<template>
  <el-menu
    :default-active="activeMenu"
    :active-text-color="menuActiveTextColor"
    :default-openeds="openeds"
    :collapse-transition="true"
    :unique-opened="true"
    :collapse="isCollapse"
    @select="handlerMenuSelect"
    router
    ref="navMenu"
  >
    <template v-for="(menu, index) in mlist">
      <template v-if="menu.children && menu.children.length > 0">
        <el-submenu :index="menu.id" :key="index" :class="{ 'is-active': isActive }" ref="submenu">
          <template slot="title">
            <i :class="['iconfont', SideItem.icon, menu.meta.icon]"></i>
            <span slot="title">{{ menu.name }}</span>
          </template>
          <template v-for="(cMenu, cIndex) in menu.children">
            <template v-if="cMenu.children && cMenu.children.length > 0">
              <el-submenu :index="cMenu.id" :ref="cMenu.path" :key="cIndex">
                <template slot="title">
                  <span slot="title">{{ cMenu.name }}</span>
                </template>
                <template v-for="(cCMenu, cCIndex) in cMenu.children">
                  <el-menu-item :index="`/${cCMenu.path}`" :key="cCIndex">
                    <span slot="title">{{ cCMenu.name }}</span>
                  </el-menu-item>
                  <!-- <el-menu-item :index="`${menu.path}/${cMenu.path}/${cCMenu.path}`" :key="cCIndex">{{ cCMenu.name }}</el-menu-item> -->
                </template>
              </el-submenu>
            </template>
            <template v-else>
              <el-menu-item :index="`/${cMenu.path}`" :key="cIndex">
                <span slot="title">{{ cMenu.name }}</span>
              </el-menu-item>
            </template>
          </template>
        </el-submenu>
      </template>
      <template v-else>
        <el-menu-item :index="`/${menu.path}`" :key="menu.id">
          <template>
            <i :class="['iconfont', 'gradient-text', SideItem.icon, menu.meta.icon]"></i>
            <span slot="title">{{ menu.name }}</span>
          </template>
        </el-menu-item>
      </template>
    </template>
  </el-menu>
</template>
<script lang="ts">
import { Component, Vue, Watch, Ref } from 'vue-property-decorator'
import { AppModule } from '@/store/modules/app'
import { SettingsModule } from '@/store/modules/settings'
import { PermissionModule } from '@/store/modules/permission'
// import { USER_LEVEL_KEY, TOKEN_KEY } from '@/store/modules/user'
// import { getLocalStorage } from '@/utils/cookiesUtil'
// const token_key = getLocalStorage(TOKEN_KEY)
// const user_level = getLocalStorage(USER_LEVEL_KEY)
// import { useSysMenuData } from '@/menu'

export interface IScssVariables {
  menuBg: string
  menuText: string
  menuActiveText: string
}

const variables: IScssVariables = {
  menuBg: 'rgba(37, 37, 77, 0.95)',
  menuText: 'rgb(191, 203, 217)',
  menuActiveText: 'rgba(60, 139, 235, 1)'
}

@Component({
  name: 'SideItem',
  components: {}
})
export default class extends Vue {
  @Ref() readonly navMenu!: any | Element
  @Ref() readonly submenu!: any | Element

  // private menuList = getMenu()
  private menuList: any = []
  private isActive = false
  private SideItem: any
  private lastPath = ''
  private openeds: string[] = []
  get sidebar() {
    return AppModule.sidebar
  }

  get menuActiveTextColor() {
    if (SettingsModule.sidebarTextTheme) {
      return SettingsModule.theme
    } else {
      return variables.menuActiveText
    }
  }

  get mlist() {
    return PermissionModule.menus
  }

  get variables() {
    return variables
  }

  get activeMenu() {
    if (this.$route.path === '/refresh') {
      return this.lastPath
    }
    return this.$route.path
  }

  get isCollapse() {
    console.log(!this.sidebar.opened)
    return !this.sidebar.opened
  }
  // @Watch('mlist', { deep: true })
  // onMenuChange(newVal, val) {
  //   this.menuList = []
  //   this.menuList = this.menuList.concat(newVal)
  // }

  created() {
    // if (token_key !== null && user_level !== null) {
    //   const { menu } = useSysMenuData(Number(user_level))
    //   this.menuList = menu
    // } else {
    //   this.menuList = []
    // }
  }
  getMenuData() {
    this.initMenuData()
    // http.get(`/menu/menuList?username=${this.userInfo.username}`).then(resp => {
    //   if (resp.data) {
    //     // this.menuList = resp.data
    //     this.menuList = menuList
    //     setMenu(resp.data)
    //     this.initMenuData()
    //   }
    // })
  }
  initMenuData() {
    // const val = this.$route.meta.parentId
    // this.mlist.unshift({
    //   name: '鹰视视频巡查管理平台',
    //   path: 'home',
    //   title: '鹰视视频巡查管理平台',
    //   meta: {
    //     icon: 'icon-ys-home',
    //     title: '鹰视视频巡查管理平台'
    //   }
    // })
    // this.mlist = newList && newList[0]?.children
    // if (this.mlist && this.mlist.length > 0) {
    //   this.openeds = this.ergodicData(this.mlist)
    // }
  }
  ergodicData(data) {
    const lists: string[] = []
    data.forEach(item => {
      if (item['children'] instanceof Array && item['children'].length > 0) {
        lists.push(item.id)
        dataEach(item['children'])
      }
    })
    function dataEach(item) {
      item.forEach(it => {
        if (it['children'] instanceof Array && it['children'].length > 0) {
          dataEach(it['children'])
          lists.push(it.id)
        }
      })
    }
    return lists
  }
  handlerMenuSelect(index, indexPath) {
    // if (index === '/database/accountlist') {
    //   localStorage.removeItem('accountListRouteQuery')
    // }
    // if (index === '/database/videolist') {
    //   localStorage.removeItem('videoListRouteQuery')
    // }
  }
}
</script>
<style module="SideItem">
.icon {
  display: inline-block;
  font-size: 34px !important;
  color: #e8ecf1 !important;
  width: 40px;
  height: 40px;
  transform: scale(0.6);
  margin-right: 0;
}
</style>
<style>
.systemInfo {
  font-size: 17px;
  color: #fff;
  padding: 0 20px;
  height: 42px;
  background: #2e1b60;
  line-height: 42px;
  display: flex;
  text-align: center;
  justify-content: center;
}
.systemInfo .iconfont {
  font-size: 48px !important;
  margin-right: 5px;
}
</style>
