<template>
  <div class="app-breadcrumbBox">
    <span class="posLabel">
      <i class="iconBox iconfont"></i>
      当前位置：
    </span>
    <!-- <span class="parentLabel" v-show="menuIcon != 'icon-shouye'">{{ parentChild }}</span> -->
    <span class="parentLabel" v-if="fatherChild && menuIcon != 'icon-tq-'">{{ fatherChild }}</span>
    <!-- <el-breadcrumb class="app-breadcrumb" separator="/">
      <el-breadcrumb-item v-for="(item, index) in breadcrumbs" :key="index">
        <span class="no-redirect">
          {{ item.meta.title }}
        </span>
      </el-breadcrumb-item>
    </el-breadcrumb> -->
  </div>
</template>

<script lang="ts">
import { compile } from 'path-to-regexp'
import { Component, Vue, Watch } from 'vue-property-decorator'
import { RouteRecord, Route } from 'vue-router'

@Component({
  name: 'Breadcrumb'
})
export default class extends Vue {
  private breadcrumbs: RouteRecord[] = []
  private parentChild = ''
  private fatherChild = ''
  private menuIcon = ''
  @Watch('$route')
  private onRouteChange(route: Route) {
    if (route.path !== '/refresh') {
      this.getBreadcrumb()
    }
  }

  created() {
    this.getBreadcrumb()
  }

  private getBreadcrumb() {
    const matched = this.$route.matched.filter(item => item.meta && item.meta.title)
    this.parentChild = this.$route.meta.parent
    this.fatherChild = this.$route.meta.title
    this.menuIcon = this.$route.meta.icon
    const first = matched[0]
    this.breadcrumbs = matched.filter(item => {
      return item.meta && item.meta.title && item.meta.breadcrumb !== false
    })
  }

  // private isDashboard(route: RouteRecord) {
  //   const name = route && route.name
  //   if (!name) {
  //     return false
  //   }
  //   return name.trim().toLocaleLowerCase() === 'Dashboard'.toLocaleLowerCase()
  // }

  private pathCompile(path: string) {
    // To solve this problem https://github.com/PanJiaChen/vue-element-admin/issues/561
    const { params } = this.$route
    const toPath = compile(path)
    return toPath(params)
  }

  private handleLink(item: any) {
    const { redirect, path } = item
    if (redirect) {
      this.$router.push(redirect).catch(err => {
        console.warn(err)
      })
      return
    }
    this.$router.push(this.pathCompile(path)).catch(err => {
      console.warn(err)
    })
  }
}
</script>

<style lang="less">
.breadcrumb {
  display: inline-block;
  margin-top: 20px;
  margin-bottom: 6px;
  margin-left: 6px;
}
.el-breadcrumb__inner,
.el-breadcrumb__inner a {
  font-weight: 400 !important;
}

.app-breadcrumbBox {
  margin-top: 2px;
  font-size: 14px;
}
.app-breadcrumb.el-breadcrumb {
  display: inline-block;
  margin: 0 9px;
  color: #c0c4cc;

  .no-redirect {
    color: #202225;
    cursor: text;
  }
}
.posLabel {
  .iconBox {
    margin-left: 10px;
    color: #666;
  }
  float: left;
  color: #202225;
}
.parentLabel {
  float: left;
  margin-left: 4px;
  color: #202225;
}
</style>
