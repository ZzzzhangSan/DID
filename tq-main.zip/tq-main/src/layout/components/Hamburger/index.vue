<template>
  <div @click="toggleClick">
    <!-- <svg-icon name="hamburger" width="20" height="20" /> -->
    <!-- <i class="fa fa-align-right" aria-hidden="true"></i> -->
    <i class="iconfont icon-icon-ys-toggleDown" aria-hidden="true" v-if="isActive"></i>
    <i class="iconfont icon-icon-ys-toggleUp" aria-hidden="true" v-else></i>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component({
  name: 'Hamburger'
})
export default class extends Vue {
  // 菜单当前展开折叠状态
  @Prop({ default: false }) private isActive!: boolean

  private toggleClick() {
    this.$emit('toggle-click')
  }
}
</script>

<style lang="less" scoped>
.svg-icon {
  vertical-align: middle;
}

.is-active {
  transform: rotate(180deg);
  padding-bottom: 55px;
}
</style>
