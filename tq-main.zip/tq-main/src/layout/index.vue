<template>
  <div class="mainBox" v-if="showMain">
    <div :class="classObj" class="app-wrapper">
      <div v-if="classObj.mobile && sidebar.opened" class="drawer-bg" @click="handleClickOutside" />
      <div class="webTitle">{{ title }}</div>
      <!-- 侧边栏 -->
      <Sidebar class="sidebar-container" />
      <div :class="{ hasTagsView: showTagsView }" class="main-container">
        <!-- <HeaderBar /> -->
        <!-- 页签 -->
        <!-- <div class="tagsViewBox">
          <tags-view v-if="showTagsView" />
        </div> -->
        <div class="breadcrumb">
          <breadcrumb />
        </div>
        <app-main />
      </div>
    </div>
  </div>
  <div class="mainBox" v-else>
    <app-main />
  </div>
</template>

<script lang="ts">
import { Component, Watch } from 'vue-property-decorator'
import { mixins } from 'vue-class-component'
import { DeviceType, AppModule } from '@/store/modules/app'
import { SettingsModule } from '@/store/modules/settings'
import { AppMain, Navbar, Sidebar, TagsView, HeaderBar } from './components'
import Breadcrumb from './components/Breadcrumb/index.vue'
import ResizeMixin from './mixin/resize'
import router from '@/router/index'
import { UserModule } from '@/store/modules/user'
import { setToken } from '@/utils/cookies'
@Component({
  name: 'Layout',
  components: {
    AppMain,
    Navbar,
    Sidebar,
    TagsView,
    HeaderBar,
    Breadcrumb
  }
})
export default class extends mixins(ResizeMixin) {
  private showMain = false
  private title = process.env.VUE_APP_NAME
  @Watch('$route')
  private routeChange(val) {
    if (val.path !== '/login') {
      this.showMain = true
    }
  }
  get classObj() {
    return {
      hideSidebar: !this.sidebar.opened,
      openSidebar: this.sidebar.opened,
      withoutAnimation: this.sidebar.withoutAnimation,
      mobile: this.device === DeviceType.Mobile
    }
  }

  get showSettings() {
    return SettingsModule.showSettings
  }
  // 是否显示页签
  get showTagsView() {
    return SettingsModule.showTagsView
  }

  get fixedHeader() {
    return SettingsModule.fixedHeader
  }

  private handleClickOutside() {
    AppModule.CloseSideBar(false)
  }
  mounted(): void {
    UserModule.UserInfoAction('admin').then(re => {
      setToken('admin')
      router.push({ path: 'realAlarm' })
    })
    //console.log(this.sidebar)
  }
}
</script>

<style lang="less">
.mainBox {
  width: 100%;
  height: 100%;
  /*user-select: none;*/
}
.app-wrapper {
  height: 100%;
  width: 100%;
  background: #f3f6ff;
  .webTitle {
    width: 100%;
    height: 64px;
    line-height: 64px;
    background: #ffffff;
    color: #205bd4;
    font-size: 28px;
    font-weight: 700;
    padding-left: 30px;
    box-shadow: 0px 0px 18px 16px #d2def6;
  }
}
/**, border 0s, background 0s, color 0s, font-size 0s, padding-left 0s, padding-right 0s */
.sidebar-container {
  transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1), width 0s;
  width: 245px !important;
  height: 100%;
  float: left;
  z-index: 1001;
  overflow: hidden;
  border-right: 1px solid #f1f1f1;
}
.main-container {
  height: 100%;
  transition: margin-left 0.28s;
  margin-left: 245px;
  position: relative;
}

.drawer-bg {
  background: rgb(10, 8, 8);
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}

.tagsViewBox {
  width: 100%;
  // height: 41px;
  transition: width 0.28s;
  z-index: 1000;
  // background: transparent;
  // box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  // border-top: 1px solid #f4f4f4;
}

.fixed-header {
  width: 100%;
  transition: width 0.28s;
}

.hideSidebar {
  .main-container {
    margin-left: 60px;
  }

  .sidebar-container {
    width: 60px !important;
  }
}
.icon {
  display: inline-block;
  font-size: 34px !important;
  color: #e8ecf1 !important;
  width: 40px;
  height: 40px;
  transform: scale(0.6);
  margin-right: 0;
}
</style>
