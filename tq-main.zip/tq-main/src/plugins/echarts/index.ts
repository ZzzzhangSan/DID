import * as echarts from 'echarts/core'

import { BarChart, LineChart, PieChart, MapChart, PictorialBarChart, ScatterChart, GraphChart } from 'echarts/charts'

import {
  LegendComponent,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  PolarComponent,
  AriaComponent,
  DataZoomComponent,
  ParallelComponent
} from 'echarts/components'

// import { SVGRenderer } from 'echarts/renderers'
import 'echarts-wordcloud'

import '@/plugins/echarts/map/china'
import chinaData from '@/plugins/echarts/map/china.json'

echarts.registerMap('china', chinaData)

echarts.use([
  TitleComponent,
  TooltipComponent,
  GridComponent,
  PolarComponent,
  AriaComponent,
  ParallelComponent,
  LegendComponent,
  BarChart,
  DataZoomComponent,
  LineChart,
  PieChart,
  GraphChart,
  MapChart,
  ScatterChart,
  PictorialBarChart
])

export default echarts
