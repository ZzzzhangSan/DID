import { pcode } from './pcode'
import { setLocalStorage, getLocalStorage } from '@/utils/cookiesUtil'

const PLS_CODE = 'ProvincesCode'
const getLsCode = () => {
  const code = getLocalStorage(PLS_CODE)
  if (!code) {
    setLocalStorage(PLS_CODE, JSON.stringify(pcode))
    return pcode
  }
  return JSON.parse(code)
}

/**
 * 获取省市编码数据
 * @returns
 */
export const getProvincesCode = () => {
  return getLsCode().map(item => {
    return { code: item.code, name: item.name }
  })
}

/**
 * 根据省code 获取城市编码数据
 * @param pcode 省编码
 */
export const getCitysByPCode = (pcode: string) => {
  const citys = getLsCode().find(item => item.code === pcode)
  if (citys) {
    return citys.children
  }
  return []
}
