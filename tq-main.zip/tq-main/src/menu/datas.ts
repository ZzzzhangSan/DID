import { MenuType } from './type'

const realAlarm: MenuType = {
  name: '实时告警',
  id: '10000',
  path: 'realAlarm',
  title: '实时告警',
  icon: 'icon-tq-realAlarm',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/realAlarm/index.vue')
}
const historyAlarm: MenuType = {
  name: '历史告警',
  id: '20000',
  path: 'historyAlarm',
  title: '历史告警',
  icon: 'icon-tq-historyAlarm',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/historyAlarm/index.vue')
}
const safeEvent: MenuType = {
  name: '安全事件',
  id: '30000',
  path: 'safeEvent',
  title: '历史告警',
  icon: 'icon-tq-safeEvent',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/safeEvent/index.vue')
}
const realtimeShow: MenuType = {
  name: '流量实时展示',
  id: '40000',
  path: 'realtimeShow',
  title: '流量实时展示',
  icon: 'icon-tq-realtimeShow',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/realtimeShow/index.vue')
}
// const realtimeHistory: MenuType = {
//   name: '流量实时展示-历史流量',
//   id: '41000',
//   path: 'realtimeHistory',
//   title: '流量实时展示-历史流量',
//   icon: 'icon-icons-',
//   component: () => import(/* webpackChunkName: "homepage" */ '@/views/realtimeShow/history.vue')
// }
const abnormal: MenuType = {
  name: '异常流量关联',
  id: '50000',
  path: 'abnormal',
  title: '异常流量关联',
  icon: 'icon-tq-abnormal',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/abnormal/index.vue')
}
const edgeDevice: MenuType = {
  name: '边界设备连接',
  id: '60000',
  path: 'edgeDevice',
  title: '边界设备连接',
  icon: 'icon-tq-edgeDevice',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/edgeDevice/index.vue')
}
const hostBehavior: MenuType = {
  name: '主机行为异常',
  id: '70000',
  path: 'hostBehavior',
  title: '主机行为异常',
  icon: 'icon-tq-hostBehavior',
  component: () => import(/* webpackChunkName: "homepage" */ '@/views/hostBehavior/index.vue')
}

/**
 * 初始化菜单 配置
 * @returns 所有系统菜单配置
 */
export const initMenus = () => {
  return {
    realAlarm,
    historyAlarm,
    safeEvent,
    realtimeShow,
    // realtimeHistory,
    abnormal,
    edgeDevice,
    hostBehavior
  }
}
