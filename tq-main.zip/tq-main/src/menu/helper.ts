import { RouteConfig } from 'vue-router'
import { MenuType } from './type'
// 构建Meta
const getMetaConfig = (menu: MenuType) => {
  return {
    icon: menu.icon ?? '',
    parent: menu.name,
    parentId: menu.id,
    title: menu.title
  }
}
/**
 * 创建路由router配置项
 * @param menu
 */
export function createRouterConfig(menu: MenuType) {
  const getPath = item => {
    return `/` + item
  }
  const { name, id, component = {}, children } = menu
  let rootPath = menu.path
  const meta = getMetaConfig(menu)
  const child = children?.map(item => {
    return {
      path: getPath(item.path),
      name: item.name,
      meta: getMetaConfig({ icon: item.icon ?? '', name: name, id: id, title: item.name }),
      component: item.component
    }
  }) as RouteConfig[]
  let root: RouteConfig[] = []
  if (rootPath && rootPath !== '') {
    rootPath = getPath(menu.path)
    root.push({ path: rootPath, name, meta, component })
  }
  if (child && child.length) {
    root = root.concat(child)
  }
  return root
}
/**
 * 创建菜单Menu配置项
 * @param menu
 */
export function createMenuConfig(menu: MenuType) {
  const { name, id, path = '', children } = menu
  const child =
    children?.map((item: any) => {
      const meta = getMetaConfig({ icon: item.icon ?? '', name: name, id: id, title: item.name })
      const childArr =
        item.children?.map((child: any) => {
          const meta = getMetaConfig({ icon: child.icon ?? '', name: item.name, id: item.id, title: child.name })
          return {
            id: child.id ?? '',
            name: child.name,
            path: child.path,
            meta
          }
        }) ?? []
      return {
        id: item.id ?? '',
        name: item.name,
        path: item.path,
        children: childArr,
        meta
      }
    }) ?? []
  return {
    name: name,
    meta: getMetaConfig(menu),
    path,
    id,
    children: child
  }
}
