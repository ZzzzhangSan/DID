/**
 * YS菜单接口
 */
export interface MenuType {
  // 路由name
  name: string
  // id
  id?: string
  // 路由path
  path?: string
  // title用于菜单显示
  title?: string
  // 菜单icon
  icon?: string
  // 子节点
  children?: MenuType[]
  // 路由组件
  component?: any
}
