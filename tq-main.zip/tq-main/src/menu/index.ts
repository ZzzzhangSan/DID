import { createMenuConfig, createRouterConfig } from './helper'
import { initMenus } from './datas'
import { MenuType } from './type'
import { RouteConfig } from 'vue-router'
import { SysRoleEnum } from '@/common/enum'

/**
 * 根据权限获取菜单
 * @param {string} user_level 权限等级level
 */
const getRoleMenuData = (user_level: string) => {
  let result: MenuType[] = []
  const { realAlarm, historyAlarm, safeEvent, realtimeShow, abnormal, edgeDevice, hostBehavior } = initMenus()
  result = [realAlarm, historyAlarm, safeEvent, realtimeShow, abnormal, edgeDevice, hostBehavior]
  return result
}

// 不需要设置权限的路由
const sysRouter = [
  {
    path: '/',
    redirect: 'realAlarm'
  },
  {
    path: '/refresh',
    name: 'refresh',
    meta: {
      title: ''
    },
    component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/refresh.vue')
  },
  {
    path: '/realtimeHistory',
    name: '流量实时展示-详情流量',
    meta: {
      title: '流量实时展示-详情流量'
    },
    component: () => import(/* webpackChunkName: "sys" */ '@/views/realtimeShow/history.vue')
  },
  // {
  //   path: '/login',
  //   name: 'login',
  //   meta: {
  //     title: '登录页'
  //   },
  //   component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/login/Login.vue')
  // },
  {
    path: '*',
    name: 'notFound',
    component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/notFound.vue'),
    meta: {
      title: 'Not Found'
    }
  }
]

/**
 * 获取系统菜单
 * @param level 权限登记码
 */
export const useSysMenuData = level => {
  // 需要根据权限返回的菜单
  const result = getRoleMenuData(level)
  let router: RouteConfig[] = []
  // 不需要动态判断权限的路由
  router = router.concat(sysRouter)
  result.forEach(item => {
    router = router.concat(createRouterConfig(item))
  })
  const menu = result.map(item => createMenuConfig(item))
  return {
    router,
    menu
  }
}
