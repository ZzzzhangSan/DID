import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators'
import store from '@/store'
import { http } from '@/common/request'

export interface ISelectData {
  appType: Record<string, any>[]
}

@Module({ dynamic: true, store, name: 'selectData' })
class SelectData extends VuexModule implements ISelectData {
  public appType: Record<string, any>[] = []
  @Mutation
  // 用户组
  private GET_APPTYPETIONS(data) {
    this.appType = data
  }

  @Action
  // APP类别
  public getAppTypeOptions() {
    http.post(`/appAnalysis/queryAppTypes`).then((resp: any) => {
      const options = resp.data.map((item: any) => {
        return {
          name: item.appType,
          value: item.appType
        }
      })
      this.GET_APPTYPETIONS(options)
    })
  }
}

export const selectDataModule = getModule(SelectData)
