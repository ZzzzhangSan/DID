import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators'
import { RouteConfig } from 'vue-router'
import { router } from '@/router'
import store from '@/store'
import { useSysMenuData } from '@/menu'
import { MenuType } from '@/menu/type'
import { SysRoleEnum } from '@/common/enum'
export interface IPermissionState {
  routes: RouteConfig[]
  menus: MenuType[]
}

@Module({ dynamic: true, store, name: 'permission' })
class Permission extends VuexModule implements IPermissionState {
  public routes: RouteConfig[] = []
  public menus: MenuType[] = []

  @Mutation
  private SET_ROUTES(routes: RouteConfig[]) {
    let resultRouter: RouteConfig[] = []
    resultRouter = resultRouter.concat(routes)
    resultRouter.forEach((r: any) => {
      router.addRoute(r.path, r)
    })
  }

  @Mutation
  public SET_MENUS(menus: MenuType[]) {
    this.menus = []
    const resultMenu: MenuType[] = []
    this.menus = resultMenu.concat(menus)
  }

  @Action
  public GenerateRole(role: SysRoleEnum) {
    const { router, menu } = useSysMenuData(role)
    this.SET_ROUTES(router)
    this.SET_MENUS(menu)
  }

  /**
   * 跳转路由 不同权限登录默认路由不同
   * @param role 权限值
   */
  @Action
  public goDefaultRouter(role: SysRoleEnum) {
    const path = '/protocolLayerFlowStatic'
    router.push({
      path
    })
  }
}

export const PermissionModule = getModule(Permission)
