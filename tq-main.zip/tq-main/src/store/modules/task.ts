import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators'
import store from '@/store'
import { cloneDeep } from 'lodash-es'
export interface ITaskState {
  // 采集类型
  type: number
  // 平台
  platform: string
  // 爬虫结果数据
  spiderAbility: {}
}

@Module({ dynamic: true, store, name: 'task' })
class Tasks extends VuexModule implements ITaskState {
  public type = 0
  public platform = ''
  public spiderAbility = {}

  @Mutation
  private SET_TYPE(type: number) {
    this.type = type
  }
  @Mutation
  private SET_PLATFORM(platform: string) {
    this.platform = platform
  }

  @Action
  public setSPType(spType: number) {
    this.SET_TYPE(spType)
  }

  @Action
  public setPlatform(platform: string) {
    this.SET_PLATFORM(platform)
  }
}

export const TaskModule = getModule(Tasks)
