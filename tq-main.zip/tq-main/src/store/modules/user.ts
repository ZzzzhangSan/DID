import { VuexModule, Module, Action, Mutation, getModule } from 'vuex-module-decorators'
import router, { resetRouter } from '@/router'
import { PermissionModule } from './permission'
import { TagsViewModule } from './tags-view'
import { getLocalStorage, setLocalStorage, removeLocalStorage } from '@/utils/cookiesUtil'
import store from '@/store'

export const DEPTID_KEY = '_V1_APP_DEPTID_KEY_'
export const USERNAME_KEY = '_USERNAME_KEY_'
export const ROLENAME_KEY = '_ROLENAME_KEY'
export const CREATE_KEY = '_CREATE_KEY'
export const LOGINIPADDR_KEY = '_LOGINIPADDR_KEY_'

export interface IUserState {
  // 部门ID
  deptId: string
  // 部门名称
  deptName: string
  // 登录时间
  createTime: string
  // 角色ID
  roleId: string
  // 角色名
  roleName: string
  // 用户ID
  userId: string
  // 用户名
  userName: string
}

@Module({ dynamic: true, store, name: 'user' })
class User extends VuexModule implements IUserState {
  // 部门ID
  public deptId = ''
  // 部门名称
  public deptName = ''
  // 登录时间
  public createTime = getLocalStorage(CREATE_KEY) || ''
  // 角色ID
  public roleId = ''
  // 角色名
  public roleName = getLocalStorage(ROLENAME_KEY) || ''
  // 用户ID
  public userId = ''
  // 用户名
  public userName = getLocalStorage(USERNAME_KEY) || ''
  // 登录IP
  public loginIpAddr = getLocalStorage(LOGINIPADDR_KEY) || ''

  @Mutation
  private SET_DEPTID(deptId: string) {
    this.deptId = deptId
  }

  @Mutation
  private SET_DEPTNAME(deptName: string) {
    this.deptName = deptName
  }

  @Mutation
  private SET_ROLEID(roleId: string) {
    this.roleId = roleId
  }

  @Mutation
  private SET_ROLENAME(roleName: string) {
    this.roleName = roleName
  }

  @Mutation
  private SET_USERID(userId: string) {
    this.userId = userId
  }

  @Mutation
  private SET_USERNAME(userName: string) {
    this.userName = userName
  }

  @Mutation
  private SET_LOGINTIME(createTime: string) {
    this.createTime = createTime
  }

  @Mutation
  private SET_LOGINIPADDR(loginIpAddr: string) {
    this.loginIpAddr = loginIpAddr
  }

  @Action
  public ResetToken() {
    router.push('/login').then(() => {
      this.SET_DEPTNAME('')
      removeLocalStorage(DEPTID_KEY)
      removeLocalStorage(USERNAME_KEY)
      removeLocalStorage(ROLENAME_KEY)
      removeLocalStorage(CREATE_KEY)
    })
  }

  /**
   * 设置用户信息
   * @param payload
   */
  @Action
  public async UserInfoAction(payload: any) {
    const { deptId, deptName, roleId, roleName, userId, userName, loginTime, loginIpAddr } = payload
    this.SET_DEPTID(deptId)
    this.SET_DEPTNAME(deptName)
    this.SET_ROLEID(roleId)
    this.SET_ROLENAME(roleName)
    this.SET_USERID(userId)
    this.SET_USERNAME(userName)
    this.SET_LOGINTIME(loginTime)
    this.SET_LOGINIPADDR(loginIpAddr)
    resetRouter()
    // 设置权限
    PermissionModule.GenerateRole(userName)
    // 跳转默认路由
    // PermissionModule.goDefaultRouter(roleName)

    setLocalStorage(DEPTID_KEY, deptName)
    setLocalStorage(USERNAME_KEY, userName)
    setLocalStorage(ROLENAME_KEY, roleName)
    setLocalStorage(CREATE_KEY, loginTime)
    setLocalStorage(LOGINIPADDR_KEY, loginIpAddr)
    TagsViewModule.delAllViews()
  }

  get getUserName() {
    return this.userName
  }

  get getRoleName() {
    return this.roleName
  }

  get getUserLevel() {
    return this.deptId
  }

  get getLoginTime() {
    return this.createTime
  }

  get getLoginIpAddr() {
    return this.loginIpAddr
  }

  @Action
  public async LogOut() {
    if (this.userName === '') {
      throw Error('LogOut: userName is undefined!')
    }
    this.ResetToken()
  }
}

export const UserModule = getModule(User)
