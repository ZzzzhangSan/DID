declare module 'vue-ls' {
  const Storage: any
  export default Storage
}
