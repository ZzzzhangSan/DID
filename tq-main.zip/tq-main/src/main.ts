import Vue from 'vue'
import App from './views/App.vue'
import router from './router'
import store from './store'
import { PermissionModule } from '@/store/modules/permission'
import { ROLENAME_KEY } from '@/store/modules/user'
import { getLocalStorage } from '@/utils/cookiesUtil'
import VueClipboard from 'vue-clipboard2'

import './plugin'
import 'normalize.css'
import 'vue-pandora/lib/vuepandora.css'
import 'element-ui/lib/theme-chalk/index.css'
import '@/styles/index.less'

Vue.use(VueClipboard)

// 解决刷新404问题
const user_level = getLocalStorage(ROLENAME_KEY)
const routes = PermissionModule.routes

if (user_level && user_level !== '' && routes.length === 0) {
  console.log('user-lever', user_level)
  PermissionModule.GenerateRole(user_level)
}
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
