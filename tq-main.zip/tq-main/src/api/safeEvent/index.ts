import { HTTP } from '@/common/loadHttp'
/**
 * 安全事件列表
 * @param config
 */
export const safeEventList = config => {
  return HTTP().post(`/alarm/event`, config)
}

/**
 * 安全事件列表-详情
 * @param config
 */
export const safeEventDetail = config => {
  return HTTP().get(`/alarm/event/details?event_id=${config}`)
}
/**
 * 安全事件列表-编辑
 * @param config
 */
export const safeEventEdit = config => {
  return HTTP().post(`/alarm/event/remark/edit`, config)
}
