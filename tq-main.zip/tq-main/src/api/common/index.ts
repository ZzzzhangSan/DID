import { HTTP } from '@/common/loadHttp'
/**
 * 下拉-局点名称
 * @param config
 */
export const entranceSelect = () => {
  return HTTP().get(`/select/entrance`)
}
/**
 * 下拉-TOP
 * @param config
 */
export const topSelect = () => {
  return HTTP().get(`/select/top`)
}
/**
 * 下拉-数据源
 * @param config
 */
export const originSelect = () => {
  return HTTP().get(`/select/data/origin`)
}
/**
 * 下拉-流量类型
 * @param config
 */
export const typeSelect = () => {
  return HTTP().get(`/select/flow/type`)
}
/**
 * 下拉-协议类型
 * @param config
 */
export const protocolSelect = () => {
  return HTTP().get(`/select/protocol/type`)
}
