import { HTTP } from '@/common/loadHttp'
import { http } from '@/common/requestQi.ts'
/**
 * 实时告警DDOS攻击告警
 * @param config
 */
export const realAlarmDdosList = () => {
  return HTTP().get(`/alarm/current`)
}
/**
 * 边界渗透告警
 * @param config
 */
export const realAlarmCurrentList = () => {
  return HTTP().post(`/alarm/edgeDevice/current`)
}

//AbnormalHost告警
export const realAlarmAbnormalHostList = () => {
  return http.get(`/tq/m3/host_alert`)
}
