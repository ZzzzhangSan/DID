import { HTTP } from '@/common/loadHttp'
/**
 * 历史告警页面
 * @param config
 */
export const historyAlarmList = config => {
  return HTTP().post(`/alarm/history`, config)
}
