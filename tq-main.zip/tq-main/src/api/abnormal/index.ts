import { HTTP } from '@/common/loadHttp'
/**
 * 异常流量关联-上方 局点封堵流量
 * @param config
 */
export const fdTotalList = config => {
  return HTTP().post(`/fdtz/package/total`, config)
}
/**
 * 异常流量关联- 下方 局点封堵流量
 * @param config
 */
export const fdEntranceList = config => {
  return HTTP().post(`/fdtz/package/entrance`, config)
}
/**
 * 异常流量关联- 流量协议成分
 * @param config
 */
export const fdEntranceTypeList = config => {
  return HTTP().post(`/fdtz/package/entrance/type`, config)
}
/**
 * 异常流量关联- 流量TOP详情
 * @param config
 */
export const fdEntranceDetailList = config => {
  return HTTP().post(`/fdtz/package/entrance/details`, config)
}
/**
 * 异常流量关联- 配置详情
 * @param config
 */
export const fdEntrancePzList = config => {
  return HTTP().post(`/fdtz/package/entrance/pz`, config)
}
