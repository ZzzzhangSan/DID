import { HTTP } from '@/common/loadHttp'
/**
 * 流量实时展示 - 原始流量
 * @param config
 */
export const realTimeShowOriginList = config => {
  return HTTP().post(`/bjx/flow/original/entrance`, config)
}
/**
 * 流量实时展示 - 封堵流量
 * @param config
 */
export const realTimeShowFdList = config => {
  return HTTP().post(`/fdtz/package/entrance`, config)
}

/**
 * 流量实时展示 - 流量详情
 * @param config
 */
export const realTimeDetailList = config => {
  return HTTP().post(`/flow/realTime`, config)
}
