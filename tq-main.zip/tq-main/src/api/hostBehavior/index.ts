import { HTTP } from '@/common/loadHttp'
/**
 * 主机行为异常页面
 * @param config
 */
/**
 * 查询列表
 * @param config
 */
export const hostQueryList = config => {
  return HTTP().get(`/tq/m3/host_query`, config)
}
