import { HTTP } from '@/common/loadHttp'
/**
 * 边界设备连接
 * @param config
 */
export const deviceList = config => {
  return HTTP().post(`/device`, config)
}
/**
 * 边界设备连接
 * @param config
 */
export const stateList = () => {
  return HTTP().get(`/select/connect_state/type`)
}
