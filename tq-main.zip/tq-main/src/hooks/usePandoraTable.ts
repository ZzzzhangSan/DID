import { reactive } from '@vue/composition-api'
import { IPandoraTableColumn, PandoraTableOption, ISortOption } from 'vue-pandora/types/VTable'
import { tableOptionProp } from './propsSetting'
import { assign, cloneDeep } from 'lodash-es'
import { toPercent } from '@/utils/assist'
/**
 * Pandora Table 通用hooks
 *
 * columns: IPandoraTableColumn 列数据
 */
export const usePandoraTable = (column: IPandoraTableColumn[], sortOption: ISortOption, tableOption?: Record<string, any>) => {
  const opt = assign({}, tableOptionProp, tableOption ?? {})

  // console.log('opt', opt)
  // algin 居中 统一处理
  column.forEach(item => {
    item.align = 'center'
    if (item.value == 'change') {
      item.align = 'left'
      item.formatter = it => {
        const changeNum = Number(it.change)
        if (changeNum > 0) {
          return `<icon class="el-icon-top UpIcon"></icon>${it.change}`
        } else if (changeNum == 0) {
          return `${it.change}`
        } else if (changeNum < 0) {
          return `<icon class="el-icon-bottom DownIcon"></icon>${it.change}`
        }
      }
    }
    if (item.value === 'proportion') {
      item.formatter = it => {
        return toPercent(it.proportion)
      }
    }
    if (item.value === 'traffic') {
      item.formatter = it => {
        return it.traffic + 'T'
      }
    }
  })

  const newOpt = cloneDeep({
    ...opt,
    column,
    defaultSort: sortOption.defaultSort,
    sortChange: sortOption.sortChange
  })
  const tableOpt: PandoraTableOption = reactive(newOpt)
  return tableOpt
}
