import { ref, unref, onMounted, nextTick, getCurrentInstance } from '@vue/composition-api'
import { IPandoraFormItems, PandoraFormOption } from 'vue-pandora/types/VForm'
import { IPandoraTableColumn, ISortOption } from 'vue-pandora/types/VTable'
import { usePandoraForm } from './usePandoraForm'
import { usePandoraTable } from './usePandoraTable'
import { http } from '@/common/request'
import { Loading } from 'element-ui'
import { keys, assign, isFunction, omit } from 'lodash-es'
type IRequestParam = {
  url: string
  name?: string
}
export interface IUsePandoraConfig {
  // 查询项
  searchParam: Record<string, any>
  // 表单item数据
  formItems: IPandoraFormItems[]
  // table列数据
  tableColumns: IPandoraTableColumn[]
  // 排序配置
  sortOption: ISortOption
  // 请求接口相关配置
  requestParam: IRequestParam
  // 表单参数修改配置项
  formOption?: Record<string, any>
  // 表格参数修改配置项
  tableOption?: Record<string, any>
  // 表单查询格式化回调处理
  searchParamFormatter?: Function
}
/**
 * usePandora通用 hooks
 * @param searchParamRef 查询项
 * @param formItems 表单item数据
 * @param tableColumns table列数据
 * @param sortOption 排序配置
 * @param requestParam  请求接口相关配置
 * @param formOption 表单参数修改
 * @param tableOption 表格参数修改
 * @param searchFormatter 表单查询格式化处理
 */
export const usePandora = (options: IUsePandoraConfig) => {
  const { formItems, tableColumns, sortOption, requestParam, formOption, tableOption, searchParamFormatter } = options

  // 表单表格Ref 映射template ref
  const formInstanceRef: VP.VForm = ref(null)
  const tableInstanceRef: VP.VTable = ref(null)
  const vm: any = getCurrentInstance()?.proxy

  // 处理初始化赋值排序参数方法
  const getDefaultSort = () => {
    const defaultSort = sortOption.defaultSort
    const sortObj = Array.isArray(defaultSort) ? defaultSort[0] : defaultSort
    const prop = sortObj?.prop
    const order = sortObj?.order
    return {
      value: order.substring(0, order.length - 6),
      order: prop
    }
  }
  const { value, order } = getDefaultSort()

  const pageInfo = ref({
    pageNumber: 1, //0
    pageSize: 20, //	页长
    orderValue: value, //	排序方式
    orderKey: order //	排序字段
  })
  /**
   * 处理路由参数
   * @param params 查询条件对象
   * @returns
   */
  const initParam = () => {
    const routerParams = vm.$route.params
    const pKeys = Object.keys(routerParams)
    // 添加路由参数处理
    if (pKeys.length) {
      // 处理界面表单赋值
      const arr: any = pKeys.map(item => {
        return { id: item, value: routerParams[item] }
      })
      // 赋值pandora Form
      if (arr.length) {
        unref(formInstanceRef).setValue(arr)
      }
      let params = initFormParam()
      // 替换路由参数到查询参数
      params = assign(params, routerParams)
      // searchProp默认参数合并
      options.searchParam = assign(options.searchParam, params)
    } else {
      searchFormAction()
    }

    handleCurrentPageChange('1')
  }

  const initFormParam = () => {
    const value = unref(formInstanceRef).getValue()
    // 增加格式化回调处理
    const params = assign({}, isFunction(searchParamFormatter) ? searchParamFormatter(value) : value)

    return params
  }

  // 查询按钮
  function searchFormAction(): void {
    // 增加格式化回调处理
    const params = initFormParam()
    // searchProp默认参数合并
    options.searchParam = assign(options.searchParam, params)
    // 点击查询-页码初始化为1，需求：pageSize不初始化
    // loadAPI()
  }

  // clear重置
  function cleanFormAction(): void {
    unref(formInstanceRef).clearValue()
  }

  // 排序
  sortOption.sortChange = function(sortProp: any) {
    const field = keys(sortProp)[0]
    const orderType = sortProp[field]
    unref(pageInfo).orderKey = field
    unref(pageInfo).orderValue = orderType.substring(0, orderType.length - 6)
    loadAPI()
  }

  // table配置项
  const tableOptRef: any = usePandoraTable(tableColumns, sortOption, tableOption)
  // form 配置项
  const formOptRef = usePandoraForm(
    formItems,
    [
      {
        comOpt: {
          id: 'query',
          value: '查询',
          type: 'default',
          width: 90,
          disabled: false,
          icon: 'iconfont icon-chazhao',
          click: () => {
            searchFormAction()
            handleCurrentPageChange('1')
          }
        }
      },
      {
        comOpt: {
          id: 'reset',
          value: '重置',
          type: 'reset',
          width: 90,
          disabled: false,
          // icon: 'iconfont icon-reset',
          click: () => {
            cleanFormAction()
          }
        }
      }
    ],
    formOption
  )

  function loadAPI() {
    const loadingInstance = Loading.service({
      target: `#${requestParam.name}`,
      spinner: 'el-loading-custormspinner',
      text: '数据加载中...'
    })
    const param = assign(options.searchParam, unref(pageInfo))
    http
      .post(requestParam.url, param)
      .then(resp => {
        const { res_data, totals } = resp
        tableOptRef.data = res_data
        tableOptRef.pageOpt.total = totals || 0
        // loadingInstance.close()
        //clearRouterParam()
        // nextTick(() => {
        //   clearRouterParam()
        // })
      })
      .catch(() => {
        tableOptRef.data = []
        tableOptRef.pageOpt.total = 0
        // loadingInstance.close()
      })
  }

  onMounted(() => {
    nextTick(() => {
      // 查询条件初始化
      cleanFormAction()
      // 页码初始化为1，pageSize初始化20
      tableOptRef.pageOpt.pageSize = 20
      tableOptRef.pageOpt.currentPage = 1
      initParam()
    })
  })

  // 分页相关回调
  function handleCurrentPageChange(val: any) {
    unref(pageInfo).pageNumber = val
    loadAPI()
  }
  // 页面条数回调，当前页数重置为1，页码参数重置为1
  function handleSizePageChange(val: any) {
    unref(pageInfo).pageSize = val
    unref(pageInfo).pageNumber = 1
    tableOptRef.pageOpt.currentPage = 1
    loadAPI()
  }

  return {
    tableOptRef,
    formOptRef,
    formInstanceRef,
    tableInstanceRef,
    searchFormAction,
    cleanFormAction,
    handleCurrentPageChange,
    handleSizePageChange
  }
}
