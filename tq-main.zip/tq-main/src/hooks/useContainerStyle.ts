import { ref, onMounted, computed, watch, nextTick, unref } from '@vue/composition-api'
import elementResizeDetectorMaker from 'element-resize-detector'
/**
 * 通用容器类 样式style 处理
 */
export const useContainerStyle = () => {
  const formBox = ref<HTMLDivElement>()
  const tableHeight = ref('calc(100% - 45px)')
  const modelTableHeight = ref('calc(100% - 80px)')
  const tableBoxHeight = ref('300')
  const formBoxHeight = ref<number>(40)

  const formStyleComputed = computed(() => {
    return { height: formBoxHeight.value }
  })
  const tableStyleComputed = computed(() => {
    return { height: tableBoxHeight.value }
  })
  const formStyleChange = () => {
    nextTick(() => {
      formBoxHeight.value = (unref(formBox) as HTMLDivElement).offsetHeight + 15
      tableBoxHeight.value = `calc(100% - ${formBoxHeight.value}px)`
    })
  }
  watch(formBox, (nl, ol) => {
    formStyleChange()
  })

  onMounted(() => {
    // formStyleChange()
    const erd = elementResizeDetectorMaker()
    erd.listenTo(document.getElementsByClassName('search-form'), function(element) {
      formStyleChange()
    })
  })
  return {
    formBox,
    tableHeight,
    tableBoxHeight,
    modelTableHeight,
    formBoxHeight,
    formStyleComputed,
    tableStyleComputed,
    formStyleChange
  }
}
