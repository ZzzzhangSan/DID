import Vue from 'vue'
import ElementUI from 'element-ui'
import VuePandora from 'vue-pandora'
import BorderBox from '@/components/Common/BorderBox.vue'
import PageContainer from '@/components/Common/PageContainer.vue'
import TabsBaseTable from '@/components/Common/TabsBaseTable.vue'
import FormArrow from '@/components/Common/FormArrow.vue'
import vueScrollwatch from '@/utils/vue-scrollwatch'
import VueCompositionAPI from '@vue/composition-api'

// Vue.filter('appSizeFilter', function(value) {
//   if (value >= 10000) {
//     const newval = value / 10000
//     return newval.toFixed(2) + '万'
//   } else {
//     return value
//   }
// })

Vue.config.productionTip = false
Vue.component('BorderBox', BorderBox)
Vue.component('PageContainer', PageContainer)
Vue.component('TabsBaseTable', TabsBaseTable)
Vue.component('FormArrow', FormArrow)
Vue.use(VuePandora)
Vue.use(VueCompositionAPI)
Vue.use(vueScrollwatch)
Vue.use(ElementUI)
