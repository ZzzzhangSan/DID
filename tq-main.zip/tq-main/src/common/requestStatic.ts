import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios'
import { Message, MessageBox } from 'element-ui'
import store from '@/store'
import { REQUEST_STATUS } from './enum'
import qs from 'qs'
import { camelCase } from 'lodash-es'
import { transformTraffic } from '@/utils/trafficHelper'

axios.defaults.withCredentials = true
const instance: AxiosInstance = axios.create({
  baseURL: process.env.VUE_APP_BASE_API,
  timeout: 120000,
  withCredentials: true // send cookies when cross-domain requests
})
const CancelToken = axios.CancelToken
const source = CancelToken.source()
const sendMessage = (msg: string, type: ElMessageOptions) => {
  ;(Message as any).closeAll()
  Message({
    message: msg,
    customClass: 'customMessage',
    type,
    duration: 2000
  })
}
type ElMessageOptions = 'success' | 'warning' | 'info' | 'error' | undefined
type MethodType = 'post' | 'get' | 'delete' | 'put'

// Request interceptors
// instance.interceptors.request.use(
//   config => {
//     if (getCookies('szCode')) {
//       config.headers['token'] = getCookies('szCode')
//     }
//     return config
//   },
//   error => {
//     Promise.reject(error)
//   }
// )
// Response interceptors
instance.interceptors.response.use(
  (response: AxiosResponse) => {
    const res = response.data
    // error
    if (response.status == REQUEST_STATUS.ERROR) {
      sendMessage(res.message, 'error')
      return Promise.reject(new Error(res.message || 'Error'))
    }
    // 重定向
    else if (res.code === REQUEST_STATUS.REDIRECT) {
      // token失效，重定向
      MessageBox.confirm('您已被登出，请重新登录', '确定登出', {
        confirmButtonText: '重新登录',
        type: 'warning'
      })
        .then(() => {
          store.dispatch('user/RESET_TOKEN')
        })
        .catch((action: any) => {
          // sendMessage(`action: ${action}`, 'error')
          sendMessage(`操作已取消`, 'error')
        })
      return Promise.reject(new Error(res.message || 'Error'))
    } else {
      // sendMessage(res.message, 'success')
      return Promise.resolve(response)
    }
  },
  error => {
    if (error && error.response) {
      switch (error.response.status) {
        case 400:
          error.message = '请求错误'
          break
        case 401:
          error.message = '未授权，请登录'
          break
        case 403:
          error.message = '拒绝访问'
          break
        case 404:
          error.message = `请求地址出错: ${error.response.config.url}`
          break
        case 408:
          error.message = '请求超时'
          break
        case 500:
          error.message = '服务器内部错误'
          break
        case 501:
          error.message = '服务未实现'
          break
        case 502:
          error.message = '网关错误'
          break
        case 503:
          error.message = '服务不可用'
          break
        case 504:
          error.message = '网关超时'
          break
        case 505:
          error.message = 'HTTP版本不受支持'
          break
        default:
          break
      }
    }
    sendMessage(error.message, 'error')
    return Promise.reject(error)
  }
)

// 访问路径统一方法
const changePath: any = type => {
  if (type === 1) {
    return 'day'
  } else if (type === 2) {
    return 'week'
  }
}

/**
 * 根据参数动态导入指定文件
 * @param {Array} param
 */
const syncImportAction: any = (param: any, options: any) => {
  const type = options.params
  const url = options.url
  const interfaceName = camelCase(`get-${type}`)
  const path = `${url}/${interfaceName}`
  let paramNum = ''
  if (param.length == 3) {
    paramNum = param[2]
  }
  const portParamsArr = options.data.split('&')
  let timeType: any = '2'
  let encryptionType: any = '加密'
  let typeParams: any = 1
  portParamsArr.forEach(it => {
    const objArr = it.split('=')
    if (objArr[0] === 'timeType') {
      timeType = objArr.length > 1 ? objArr[1] : '2'
    }
    if (objArr[0] === 'encryptionType') {
      encryptionType = objArr.length > 1 ? decodeURI(objArr[1]) : '加密'
    }
    if (objArr[0] === 'type') {
      typeParams = objArr[1]
    }
  })
  const getModule = type => {
    if (/^\/system\/commonExport/.test(url)) {
      return import('@/staticDatas/system/commonExport')
    }
    // 首页接口
    if (/^\/home\/getStatsDatas/.test(url)) {
      return import('@/staticDatas/day/home/getStatsDatas')
    }
    // 首页接口
    if (/^\/home\/getAppTrafficeTop/.test(url)) {
      return import('@/staticDatas/day/home/getAppTrafficeTop')
    }
    // 首页接口
    if (/^\/home\/getGeoTrafficStats/.test(url)) {
      return import('@/staticDatas/day/home/getGeoTrafficStats')
    }
    // 首页接口
    if (/^\/home\/getAppTypeGbpsTrend/.test(url)) {
      return import('@/staticDatas/day/home/getAppTypeGbpsTrend')
    }
    // 首页接口
    if (/^\/home\/getAppTypeTrafficTrend/.test(url)) {
      return import('@/staticDatas/day/home/getAppTypeTrafficTrend')
    }

    if (type === '1') {
      // 各协议流量统计-各协议层流量统计排名占比图
      if (/^\/protocolLayer\/getProtocolLayerStatsTopRank/.test(url)) {
        return import('@/staticDatas/day/protocol/getProtocolLayerStatsTopRank')
      }
      // 各协议流量统计-各协议层流量查询列表
      if (/^\/protocolLayer\/searchProtocolLayerList/.test(url)) {
        return import('@/staticDatas/day/protocol/searchProtocolLayerList')
      }
      // 各协议流量统计-各协议流量统计排名/占比图
      if (/^\/protocol\/getProtocolStatsTopRank/.test(url)) {
        return import('@/staticDatas/day/protocol/getProtocolStatsTopRank')
      }
      // 各协议流量统计-各协议流量统计趋势图
      if (/^\/protocol\/getProtocolTrafficTrend/.test(url)) {
        return import('@/staticDatas/day/protocol/getProtocolTrafficTrend')
      }
      // 各协议流量统计-各协议流量查询列表
      if (/^\/protocol\/searchProtocolTrafficTrendList/.test(url)) {
        return import('@/staticDatas/day/protocol/searchProtocolTrafficTrendList')
      }

      // 加密和非加密协议流量分析-加密非加密协议占比
      if (encryptionType === '加密') {
        if (/^\/encryption\/getEncryptionStatsTopRank/.test(url)) {
          return import('@/staticDatas/day/encryption/getEncryptionStatsTopRankJiaMi')
        }
      } else {
        if (/^\/encryption\/getEncryptionStatsTopRank/.test(url)) {
          return import('@/staticDatas/day/encryption/getEncryptionStatsTopRankFeiMi')
        }
      }
      // if (/^\/encryption\/getEncryptionStatsTopRank/.test(url)) {
      //   return import('@/staticDatas/day/encryption/getEncryptionStatsTopRank')
      // }
      // 加密和非加密协议流量分析-加密非加密趋势图
      if (/^\/encryption\/getEncryptionTrafficTrend/.test(url)) {
        return import('@/staticDatas/day/encryption/getEncryptionTrafficTrend')
      }
      // 加密和非加密协议流量分析-加密非加密流量类型总体占比
      if (/^\/encryption\/getEncryptionTotalStats/.test(url)) {
        return import('@/staticDatas/day/encryption/getEncryptionTotalStats')
      }
      // 加密和非加密协议流量分析-加密非加密流量查询列表
      if (/^\/encryption\/searchEncryptionList/.test(url)) {
        return import('@/staticDatas/day/encryption/searchEncryptionList')
      }

      // 应用类型统计 - 排名占比图
      if (/^\/appType\/getAppTypeTrafficTopRank/.test(url)) {
        return import('@/staticDatas/day/appType/getAppTypeTrafficTopRank')
      }
      // 应用类型统计 - 应用类型流量趋势图
      if (/^\/appType\/getAppTypeTrafficTrend/.test(url)) {
        return import('@/staticDatas/day/appType/getAppTypeTrafficTrend')
      }
      // 应用类型查询 - 列表接口
      if (/^\/appType\/searchAppTypeList/.test(url)) {
        return import('@/staticDatas/day/appType/searchAppTypeList')
      }
      // 应用子类型统计 - 排名占比图
      if (/^\/appSubtype\/getAppSubtypeTrafficTopRank/.test(url)) {
        return import('@/staticDatas/day/appType/getAppSubtypeTrafficTopRank')
      }
      // 应用子类型统计 - 应用子类型流量趋势图
      if (/^\/appSubtype\/getAppSubtypeTrafficTrend/.test(url)) {
        return import('@/staticDatas/day/appType/getAppSubtypeTrafficTrend')
      }
      // 应用子类型查询 - 列表接口
      if (/^\/appSubtype\/searchAppSubtypeList/.test(url)) {
        return import('@/staticDatas/day/appType/searchAppSubtypeList')
      }
      // 应用统计 - 排名占比图
      if (/^\/app\/getAppTrafficTopRank/.test(url)) {
        return import('@/staticDatas/day/appType/getAppTrafficTopRank')
      }
      // 应用查询 - 列表接口
      if (/^\/app\/searchAppList/.test(url)) {
        return import('@/staticDatas/day/appType/searchAppList')
      }

      // 流入流出流量查询
      if (/^\/geo\/searchGeoInOutFlowList/.test(url)) {
        return import('@/staticDatas/day/geo/searchGeoInOutFlowList')
      }
      // 境外流向境内
      if (/^\/geo\/getCountryInChinaTopRank/.test(url)) {
        return import('@/staticDatas/day/geo/getCountryInChinaTopRank')
      }
      // 境外流向境内各省
      if (/^\/geo\/getCountryInChinaProvinceTopRank/.test(url)) {
        return import('@/staticDatas/day/geo/getCountryInChinaProvinceTopRank')
      }
      // 境内各省流向境外各国
      if (/^\/geo\/getChinaProvinceOutCountryTopRank/.test(url)) {
        return import('@/staticDatas/day/geo/getChinaProvinceOutCountryTopRank')
      }
      // 境内流向境外
      if (/^\/geo\/getChinaOutCountryTopRank/.test(url)) {
        return import('@/staticDatas/day/geo/getChinaOutCountryTopRank')
      }
      // 过境流量查询列表
      if (/^\/geo\/searchTransitTrafficList/.test(url)) {
        return import('@/staticDatas/day/geo/searchTransitTrafficList')
      }
      // 过境流量柱图查询
      if (/^\/geo\/getTransitTrafficStats/.test(url)) {
        return import('@/staticDatas/day/geo/getTransitTrafficStats')
      }
      // 过境流量饼图占比
      if (/^\/geo\/getTransitTrafficTopRank/.test(url)) {
        return import('@/staticDatas/day/geo/getTransitTrafficTopRank')
      }
      // IPV4和IPV6总流量分布
      if (/^\/ipFlow\/getIpFlowTotalTraffic/.test(url)) {
        return import('@/staticDatas/day/ipFlow/getIpFlowTotalTraffic')
      }
      // IPV4和IPV6各国流量分布
      if (/^\/ipFlow\/getIpFlowCountryTraffic/.test(url)) {
        return import('@/staticDatas/day/ipFlow/getIpFlowCountryTraffic')
      }
      // 各国流量统计
      if (/^\/ipFlow\/getIpFlowCountryInnerTraffic/.test(url)) {
        return import('@/staticDatas/day/ipFlow/getIpFlowCountryInnerTraffic')
      }
      // 流量排名变化查询
      if (/^\/ipFlow\/searchIpFlowRankingChangeList/.test(url)) {
        return import('@/staticDatas/day/ipFlow/searchIpFlowRankingChangeList')
      }
      // IP流量查询
      if (/^\/ipFlow\/searchIpFlowList/.test(url)) {
        return import('@/staticDatas/day/ipFlow/searchIpFlowList')
      }
      // 协议层流量TOP10排名
      if (/^\/ipFlow\/getSearchIpFlowTopRank/.test(url)) {
        return import('@/staticDatas/day/ipFlow/getSearchIpFlowTopRank')
      }
      if (typeParams === '1') {
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceManufacturerList/.test(url)) {
          return import('@/staticDatas/day/device/list/searchDeviceManufacturerList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceList/.test(url)) {
          return import('@/staticDatas/day/device/list/searchDeviceList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceTypeList/.test(url)) {
          return import('@/staticDatas/day/device/list/searchDeviceTypeList')
        }
      } else if (typeParams === '2') {
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceManufacturerList/.test(url)) {
          return import('@/staticDatas/day/device/static/searchDeviceManufacturerList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceList/.test(url)) {
          return import('@/staticDatas/day/device/static/searchDeviceList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceTypeList/.test(url)) {
          return import('@/staticDatas/day/device/static/searchDeviceTypeList')
        }
      }
    } else if (type === '2') {
      // 各协议流量统计-各协议层流量统计排名占比图
      if (/^\/protocolLayer\/getProtocolLayerStatsTopRank/.test(url)) {
        return import('@/staticDatas/week/protocol/getProtocolLayerStatsTopRank')
      }
      // 各协议流量统计-各协议层流量查询列表
      if (/^\/protocolLayer\/searchProtocolLayerList/.test(url)) {
        return import('@/staticDatas/week/protocol/searchProtocolLayerList')
      }
      // 各协议流量统计-各协议流量统计排名/占比图
      if (/^\/protocol\/getProtocolStatsTopRank/.test(url)) {
        return import('@/staticDatas/week/protocol/getProtocolStatsTopRank')
      }
      // 各协议流量统计-各协议流量统计趋势图
      if (/^\/protocol\/getProtocolTrafficTrend/.test(url)) {
        return import('@/staticDatas/week/protocol/getProtocolTrafficTrend')
      }
      // 各协议流量统计-各协议流量查询列表
      if (/^\/protocol\/searchProtocolTrafficTrendList/.test(url)) {
        return import('@/staticDatas/week/protocol/searchProtocolTrafficTrendList')
      }

      // 加密和非加密协议流量分析-加密非加密协议占比
      if (encryptionType === '加密') {
        if (/^\/encryption\/getEncryptionStatsTopRank/.test(url)) {
          return import('@/staticDatas/week/encryption/getEncryptionStatsTopRankJiaMi')
        }
      } else {
        if (/^\/encryption\/getEncryptionStatsTopRank/.test(url)) {
          return import('@/staticDatas/week/encryption/getEncryptionStatsTopRankFeiMi')
        }
      }
      // 加密和非加密协议流量分析-加密非加密趋势图
      if (/^\/encryption\/getEncryptionTrafficTrend/.test(url)) {
        return import('@/staticDatas/week/encryption/getEncryptionTrafficTrend')
      }
      // 加密和非加密协议流量分析-加密非加密流量类型总体占比
      if (/^\/encryption\/getEncryptionTotalStats/.test(url)) {
        return import('@/staticDatas/week/encryption/getEncryptionTotalStats')
      }
      // 加密和非加密协议流量分析-加密非加密流量查询列表
      if (/^\/encryption\/searchEncryptionList/.test(url)) {
        return import('@/staticDatas/week/encryption/searchEncryptionList')
      }

      // 应用类型统计 - 排名占比图
      if (/^\/appType\/getAppTypeTrafficTopRank/.test(url)) {
        return import('@/staticDatas/week/appType/getAppTypeTrafficTopRank')
      }
      // 应用类型统计 - 应用类型流量趋势图
      if (/^\/appType\/getAppTypeTrafficTrend/.test(url)) {
        return import('@/staticDatas/week/appType/getAppTypeTrafficTrend')
      }
      // 应用类型查询 - 列表接口
      if (/^\/appType\/searchAppTypeList/.test(url)) {
        return import('@/staticDatas/week/appType/searchAppTypeList')
      }
      // 应用子类型统计 - 排名占比图
      if (/^\/appSubtype\/getAppSubtypeTrafficTopRank/.test(url)) {
        return import('@/staticDatas/week/appType/getAppSubtypeTrafficTopRank')
      }
      // 应用子类型统计 - 应用子类型流量趋势图
      if (/^\/appSubtype\/getAppSubtypeTrafficTrend/.test(url)) {
        return import('@/staticDatas/week/appType/getAppSubtypeTrafficTrend')
      }
      // 应用子类型查询 - 列表接口
      if (/^\/appSubtype\/searchAppSubtypeList/.test(url)) {
        return import('@/staticDatas/week/appType/searchAppSubtypeList')
      }
      // 应用统计 - 排名占比图
      if (/^\/app\/getAppTrafficTopRank/.test(url)) {
        return import('@/staticDatas/week/appType/getAppTrafficTopRank')
      }
      // 应用查询 - 列表接口
      if (/^\/app\/searchAppList/.test(url)) {
        return import('@/staticDatas/week/appType/searchAppList')
      }

      // 流入流出流量查询
      if (/^\/geo\/searchGeoInOutFlowList/.test(url)) {
        return import('@/staticDatas/week/geo/searchGeoInOutFlowList')
      }
      // 境外流向境内
      if (/^\/geo\/getCountryInChinaTopRank/.test(url)) {
        return import('@/staticDatas/week/geo/getCountryInChinaTopRank')
      }
      // 境外流向境内各省
      if (/^\/geo\/getCountryInChinaProvinceTopRank/.test(url)) {
        return import('@/staticDatas/week/geo/getCountryInChinaProvinceTopRank')
      }
      // 境内各省流向境外各国
      if (/^\/geo\/getChinaProvinceOutCountryTopRank/.test(url)) {
        return import('@/staticDatas/week/geo/getChinaProvinceOutCountryTopRank')
      }
      // 境内流向境外
      if (/^\/geo\/getChinaOutCountryTopRank/.test(url)) {
        return import('@/staticDatas/week/geo/getChinaOutCountryTopRank')
      }
      // 过境流量查询列表
      if (/^\/geo\/searchTransitTrafficList/.test(url)) {
        return import('@/staticDatas/week/geo/searchTransitTrafficList')
      }
      // 过境流量柱图查询
      if (/^\/geo\/getTransitTrafficStats/.test(url)) {
        return import('@/staticDatas/week/geo/getTransitTrafficStats')
      }
      // 过境流量饼图占比
      if (/^\/geo\/getTransitTrafficTopRank/.test(url)) {
        return import('@/staticDatas/week/geo/getTransitTrafficTopRank')
      }
      // IPV4和IPV6总流量分布
      if (/^\/ipFlow\/getIpFlowTotalTraffic/.test(url)) {
        return import('@/staticDatas/week/ipFlow/getIpFlowTotalTraffic')
      }
      // IPV4和IPV6各国流量分布
      if (/^\/ipFlow\/getIpFlowCountryTraffic/.test(url)) {
        return import('@/staticDatas/week/ipFlow/getIpFlowCountryTraffic')
      }
      // 各国流量统计
      if (/^\/ipFlow\/getIpFlowCountryInnerTraffic/.test(url)) {
        return import('@/staticDatas/week/ipFlow/getIpFlowCountryInnerTraffic')
      }
      // 流量排名变化查询
      if (/^\/ipFlow\/searchIpFlowRankingChangeList/.test(url)) {
        return import('@/staticDatas/week/ipFlow/searchIpFlowRankingChangeList')
      }
      // IP流量查询
      if (/^\/ipFlow\/searchIpFlowList/.test(url)) {
        return import('@/staticDatas/week/ipFlow/searchIpFlowList')
      }
      // 协议层流量TOP10排名
      if (/^\/ipFlow\/getSearchIpFlowTopRank/.test(url)) {
        return import('@/staticDatas/week/ipFlow/getSearchIpFlowTopRank')
      }
    } else if (type === '3') {
      if (typeParams === '1') {
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceManufacturerList/.test(url)) {
          return import('@/staticDatas/month/device/list/searchDeviceManufacturerList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceList/.test(url)) {
          return import('@/staticDatas/month/device/list/searchDeviceList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceTypeList/.test(url)) {
          return import('@/staticDatas/month/device/list/searchDeviceTypeList')
        }
      } else if (typeParams === '2') {
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceManufacturerList/.test(url)) {
          return import('@/staticDatas/month/device/static/searchDeviceManufacturerList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceList/.test(url)) {
          return import('@/staticDatas/month/device/static/searchDeviceList')
        }
        // 协议层流量TOP10排名
        if (/^\/device\/searchDeviceTypeList/.test(url)) {
          return import('@/staticDatas/month/device/static/searchDeviceTypeList')
        }
      }
    }
  }
  return getModule(timeType)
}

/**
 * 通用request封装
 */
const request = <T>(method: MethodType, url: string, data: any, config = {}): Promise<IResponse<T>> => {
  const options: AxiosRequestConfig = Object.assign({}, config, {
    url,
    method,
    data
  })
  options.cancelToken = source.token
  options.headers = options.headers || {}

  // 截取url 按‘/’ 拆分数组
  const getParamsDatas = url => {
    let arr = url.split('/')
    arr = arr.filter(item => item)
    return arr
  }
  const params = getParamsDatas(url)
  // const bizKey = params.length === 3 ? params[2] : params.length === 2 ? params[1] : params[0]
  const bizKey = camelCase(`get-${options.params}`)
  return new Promise((resolve, reject) => {
    syncImportAction(params, options)
      .then((res: any) => {
        // const data = res[bizKey].data
        const resp = transformTraffic(res, url)
        resolve(resp.data)
      })
      .catch(res => {
        console.log(res)
        // if (!res.config.notNotifyError) {
        //     console.log('请求失败,请查看服务器信息')
        // }
        reject(res)
      })
  })
}

interface IHttpInstance {
  get: <T>(url: string, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  delete: <T>(url: string, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  put: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  post: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  postFile: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  postTwo: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
}

export const httpS: IHttpInstance = {
  get<T>(url: string, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    return request<T>('get', url, null, config)
  },
  delete<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    return request<T>('delete', url, data, config)
  },
  post<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      }
    }
    return request<T>('post', url, qs.stringify(data), config)
  },
  put<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    config.headers = {
      'Content-Type': 'application/json; charset=UTF-8'
    }
    return request<T>('put', url, data, config)
  },
  postTwo<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    }
    return request<T>('post', url, data, config)
  },
  postFile<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'multipart/form-data'
      }
    }
    return request<T>('post', url, data, config)
  }
}
