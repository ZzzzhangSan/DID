import { SysRoleEnum } from './enum'

/**
 * 时间类型
 *
 */
export const getTimeTypeOptions = () => {
  return [
    { value: 2, name: '按周' },
    { value: 1, name: '按天' }
  ]
}
export const getTerminalTypeOptions = () => {
  return [
    { value: 3, name: '按月' },
    { value: 1, name: '按天' }
  ]
}
export const getDtypeOptions = () => {
  return [
    { value: 'country', name: '国家' },
    { value: 'layer', name: '协议层' },
    { value: 'protocol', name: '协议名称' },
    { value: 'app', name: 'App名称' }
  ]
}
export const getIpverTypeOptions = () => {
  return [
    { name: 'IPv4', value: 'ipv4' },
    { name: 'IPv6', value: 'ipv6' }
  ]
}
export const encryptionTypeOptions = () => {
  return [
    { value: '加密', name: '加密' },
    { value: '非加密', name: '非加密' }
  ]
}
export const protocolLayerTypeOptions = () => {
  return [
    { value: '应用层', name: '应用层' },
    { value: '传输层', name: '传输层' },
    { value: '网络层', name: '网络层' },
    { value: '数据链路层', name: '数据链路层' },
    { value: '物理层', name: '物理层' }
  ]
}
export const applicationFlowOptions = () => {
  return [
    { value: '便捷生活', name: '便捷生活' },
    { value: '儿童', name: '儿童' },
    { value: '出行导航', name: '出行导航' },
    { value: '商务', name: '商务' },
    { value: '实用工具', name: '实用工具' },
    { value: '影音娱乐', name: '影音娱乐' },
    { value: '拍照美化', name: '拍照美化' },
    { value: '教育', name: '教育' },
    { value: '新闻阅读', name: '新闻阅读' },
    { value: '旅游住宿', name: '旅游住宿' },
    { value: '汽车', name: '汽车' },
    { value: '社交通讯', name: '社交通讯' },
    { value: '美食', name: '美食' },
    { value: '购物比价', name: '购物比价' },
    { value: '运动健康', name: '运动健康' },
    { value: '金融健康', name: '金融健康' }
  ]
}
export const flowTypeOption = () => {
  return [
    { value: '入境', name: '入境' },
    { value: '出境', name: '出境' }
  ]
}
