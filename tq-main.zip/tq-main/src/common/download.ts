import { Loading, Message } from 'element-ui'
import { http } from '@/common/request'
// import { commonExport } from '@/api/system/index'

/**
 * 处理二进制数据
 * @param resp
 */
const createBlobHandler = (resp, fileName, type) => {
  const blob = new Blob([resp.data])
  const link: any = document.createElement('a')
  // link.download = resp.headers['content-disposition'].split(';')[1].split('=')[1]
  link.download = `${fileName}.${type}`
  link.href = window.URL.createObjectURL(blob)
  link.target = '_blank'
  document.body.appendChild(link)
  link.click()
  URL.revokeObjectURL(link.href) // 释放URL 对象
  setTimeout(() => {
    Message({
      type: 'success',
      message: '下载成功'
    })
  }, 1000)
}

/**
 * 导出表格数据
 * @param tids
 */
export const downloadTableData = (downParam, fileName, type) => {
  const loadingInstance = Loading.service({
    spinner: 'el-loading-custormspinner',
    text: '正在导出模板....'
  })

  // commonExport(downParam)
  //   .then((res: any) => {
  //     if (type == 'excel') {
  //       type = 'xlsx'
  //     }
  //     createBlobHandler(res, fileName, type)
  //     loadingInstance.close()
  //   })
  //   .catch(() => {
  //     loadingInstance.close()
  //   })
}
