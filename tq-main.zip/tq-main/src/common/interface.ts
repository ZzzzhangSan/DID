export interface SpiderRespType {
  data_type: any[]
  filter: any[]
  platform: any[]
  scenario: any[]
}
