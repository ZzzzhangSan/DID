import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios'
import { Message, MessageBox } from 'element-ui'
import router from '@/router'
import store from '@/store'
import { REQUEST_STATUS } from './enum'
import qs from 'qs'
import { UserModule } from '@/store/modules/user'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { transformTraffic } from '@/utils/trafficHelper'
import { getToken } from '@/utils/cookies'

const instance: AxiosInstance = axios.create({
  baseURL: process.env.VUE_APP_BASE_API,
  timeout: 120000
})
const CancelToken = axios.CancelToken
const source = CancelToken.source()
const sendMessage = (msg: string, type: ElMessageOptions) => {
  ;(Message as any).closeAll()
  Message({
    message: msg,
    customClass: 'customMessage',
    type,
    duration: 2000
  })
}
type ElMessageOptions = 'success' | 'warning' | 'info' | 'error' | undefined
type MethodType = 'post' | 'get' | 'delete' | 'put' | 'patch'

// Request interceptors
instance.interceptors.request.use(
  config => {
    NProgress.start()
    if (getToken()) {
      // console.log(getToken(), getToken()['tokenName'], getToken().tokenValue)
      config.headers['satoken'] = getToken()
    }
    return config
  },
  error => {
    Promise.reject(error)
  }
)

// Response interceptors
instance.interceptors.response.use(
  (response: AxiosResponse) => {
    NProgress.done()
    //console.log(response)
    const res = response.data
    // error
    if (res instanceof Blob) {
      return Promise.resolve(response)
    }
    if (response.status == REQUEST_STATUS.ERROR) {
      sendMessage(res.message, 'error')
      return Promise.reject(new Error(res.message || 'Error'))
    }
    // 重定向
    else if (response.status === REQUEST_STATUS.REDIRECT) {
      // token失效，重定向
      MessageBox.confirm('会话超时，请重新登录', '确定退出', {
        confirmButtonText: '重新登录',
        type: 'warning'
      })
        .then(() => {
          UserModule.ResetToken()
          location.reload()
        })
        .catch((action: any) => {
          sendMessage(`操作已取消`, 'error')
        })
      return Promise.reject(new Error(res.message || 'Error'))
    } else {
      // sendMessage(res.message, 'success')
      const url = response?.config?.url || ''
      const resp = transformTraffic(res, url)
      return Promise.resolve(resp)

      // if (process.env.NODE_ENV === 'production') {
      //   const resp = transformTraffic(res, url)
      //   return Promise.resolve(resp)
      // } else {
      //   return Promise.resolve(res)
      // }
    }
  },
  error => {
    NProgress.done()
    if (error && error.response) {
      switch (error.response.status) {
        case 400:
          error.message = '请求参数错误'
          break
        case 401:
          error.message = '请求的操作未授权'
          break
        case 403:
          error.message = '请求的操作非法'
          break
        case 404:
          error.message = `请求的操作或资源不存在: ${error.response.config.url}`
          break
        case 415:
          error.message = '上传的文件类型不被支持'
          break
        case 500:
          error.message = '服务器内部错误'
          break
        case 501:
          error.message = '服务未实现'
          break
        case 502:
          error.message = '网关错误'
          break
        case 503:
          error.message = '服务不可用'
          break
        case 504:
          error.message = '网关超时'
          break
        case 505:
          error.message = 'HTTP版本不受支持'
          break
        default:
          break
      }
    }
    const errorMessage = error.response.data?.msg || error.message
    sendMessage(errorMessage, 'error')
    return Promise.reject(error)
  }
)
/**
 * 通用request封装
 */
const request = <T>(method: MethodType, url: string, data: any, config = {}): Promise<IResponse<T>> => {
  const options: AxiosRequestConfig = Object.assign({}, config, {
    url,
    method,
    data
  })
  options.cancelToken = source.token
  options.headers = options.headers || {}
  // 截取url 按‘/’ 拆分数组
  const getParamsDatas = url => {
    let arr = url.split('/')
    arr = arr.filter(item => item)
    return arr
  }
  const params = getParamsDatas(url)
  return new Promise((resolve, reject) => {
    instance
      .request<IResponse<T>>(options)
      .then((resp: any) => {
        const resultData = resp
        if (resultData['type'] === 'application/vnd.ms-excel') {
          return resolve(resp)
        }
        if (resultData instanceof Blob) {
          return resolve(resp)
        }
        resolve(resp)
      })
      .catch(res => {
        if (axios.isCancel(res)) {
          console.log('error', '请求中断')
        }
        reject(res)
      })
  })
}

interface IHttpInstance {
  get: <T>(url: string, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  delete: <T>(url: string, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  put: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  post: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  postJson: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  patch: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  postFile: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
  putFile: <T>(url: string, data?: any, config?: AxiosRequestConfig) => Promise<IResponse<T>>
}

export const http: IHttpInstance = {
  get<T>(url: string, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    return request<T>('get', url, null, config)
  },
  delete<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    return request<T>('delete', url, data, config)
  },
  post<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    }
    return request<T>('post', url, data, config)
  },
  postJson<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
      }
    }
    return request<T>('post', url, qs.stringify(data), config)
  },
  put<T>(url: string, data, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    config.headers = {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    return request<T>('put', url, qs.stringify(data), config)
  },
  patch<T>(url: string, data, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    config.headers = {
      'Content-Type': 'application/json; charset=UTF-8'
    }
    return request<T>('patch', url, data, config)
  },
  postFile<T>(url: string, data: object = {}, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    if (!config.headers) {
      config.headers = {
        'Content-Type': 'multipart/form-data'
      }
    }
    return request<T>('post', url, data, config)
  },
  putFile<T>(url: string, data, config: AxiosRequestConfig = {}): Promise<IResponse<T>> {
    config.headers = {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    return request<T>('put', url, data, config)
  }
}
