import { http } from '@/common/request'
const handlerData = (resp: any) => {
  const options = resp.data.map((item: any) => {
    return {
      name: item.dicName,
      value: item.dicValue
    }
  })
  return options
}

export async function getLabelOptions() {
  return http.post(`/appAnalysis/queryAppTypes`).then((resp: any) => {
    return handlerData(resp)
  })
}
