export const enum REQUEST_STATUS {
  // 成功
  SUCCESS = 200,
  SUCCESSEDIT = 202,
  SUCCESSCREAT = 201,
  SUCCESSDELETE = 204,
  // 服务器内部错误
  ERROR = 500,
  // 重定向
  REDIRECT = 50008
}

/**
 * 系统权限枚举
 * superAdmin 超级管理员
 * admin 系统管理员
 * user 系统用户
 * checker 审核员
 * Test 测试码
 */
export enum SysRoleEnum {
  SuperAdmin = 0,
  Admin = 3,
  User = 10,
  Checker = 50,
  Test = 99
}

/**
 * 日期查询类型枚举
 */
export enum SearchDateTypeEnum {
  DAY = 1,
  WEEK = 2,
  MONTH = 3
}
