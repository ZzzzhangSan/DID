import { http } from '@/common/request'
import { httpS } from '@/common/requestStatic'

export const HTTP = () => {
  return process.env.VUE_APP_IS_STATIC === '1' ? httpS : http
}
