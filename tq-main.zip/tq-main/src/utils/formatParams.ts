import { isArray } from './is'
import dayjs from 'dayjs'
import { SearchDateTypeEnum } from '@/common/enum'

export const formateQueryParams = vals => {
  let timerangeStrArr = ''
  let param: any = {}
  if (vals.timeType === SearchDateTypeEnum.WEEK) {
    timerangeStrArr = vals.timerangeWeekStr
  } else if (vals.timeType === SearchDateTypeEnum.DAY) {
    timerangeStrArr = vals.timerangeDayStr
  } else if (vals.timeType === SearchDateTypeEnum.MONTH) {
    timerangeStrArr = vals.timerangeMonthStr
  }
  if (/1|2/.test(vals.timeType)) {
    param = {
      startTimeStr: isArray(timerangeStrArr) && timerangeStrArr.length > 0 ? timerangeStrArr[0] : timerangeStrArr,
      endTimeStr: isArray(timerangeStrArr) && timerangeStrArr.length > 1 ? timerangeStrArr[1] : timerangeStrArr
    }
    param = Object.assign({}, vals, param)
    // 协议层处理
    if (param.protocolLayerType !== undefined && isArray(param.protocolLayerType)) {
      param.protocolLayerType = param.protocolLayerType.join(',')
    } else {
      param.protocolLayerType = ''
    }
    delete param.timerangeDayStr
    delete param.timerangeWeekStr
  } else {
    param = {
      startTimeStr: timerangeStrArr
    }
    param = Object.assign({}, vals, param)
    delete param.timerangeDayStr
    delete param.timerangeMonthStr
  }
  return param
}

// 获取前一天
export const preDate = () => {
  return dayjs()
    .add(-1, 'day')
    .format('YYYYMMDD')
}
// 获取本月
export const monthDate = () => {
  return dayjs().format('YYYYMM')
}
// 获取本周

/**
 * 获取周日期 默认option
 * @returns
 */
export const defaultDateWeekOption = () => {
  return {
    format: 'YYYYMMDD',
    valueFormat: 'YYYYMMDD',
    pickOptions: {
      firstDayOfWeek: 1
    }
  }
}
