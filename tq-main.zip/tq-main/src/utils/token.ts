import CryptoJS from 'crypto-js'
import Utf8 from 'crypto-js/enc-utf8.js'
import dayjs from 'dayjs'
/**
 * 授权token
 * @param secToken
 * @returns
 */
export function generalAuthToken(secToken: string) {
  const timeStamp = parseInt(dayjs().valueOf() / 1000 / 81, 10)
  const newSecStr = secToken + ' OK ' + timeStamp
  let secHash = CryptoJS.SHA1(newSecStr)
  secHash = secHash.toString(CryptoJS.enc.Hex)
  const authToken = CryptoJS.enc.Base64.stringify(Utf8.parse(secHash))
  return authToken
}

/**
 * csrfToken生成
 * @param secToken
 * @returns
 */
export function generalCsrfToken(secToken: string) {
  const timeStamp = parseInt(dayjs().valueOf() / 1000 / 32, 10)
  const newSecStr = secToken + ' OK ' + timeStamp
  let secHash = CryptoJS.SHA1(newSecStr)
  secHash = secHash.toString(CryptoJS.enc.Hex)
  const authToken = CryptoJS.enc.Base64.stringify(Utf8.parse(secHash))
  return authToken
}

/**
 * 密码转换处理
 * @param password
 * @param username
 * @param timeStamp
 */
export function generalPWD(username: string, password: string, timeStamp: number) {
  const sha1Str = CryptoJS.SHA256(password + username).toString(CryptoJS.enc.Hex)
  // console.log('sha256 一次:' + sha1Str)
  const sha2Str = sha1Str + (timeStamp + '')
  // console.log('sha256+timeStamp:' + sha2Str)
  const sha2 = CryptoJS.SHA256(sha2Str).toString(CryptoJS.enc.Hex)
  // console.log('result:' + sha2)
  return sha2
}
