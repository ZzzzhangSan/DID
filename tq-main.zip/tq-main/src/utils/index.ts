// Check if an element has a class
export const hasClass = (ele: HTMLElement, className: string) => {
  return !!ele.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'))
}

// Add class to element
export const addClass = (ele: HTMLElement, className: string) => {
  if (!hasClass(ele, className)) ele.className += ' ' + className
}

// Remove class from element
export const removeClass = (ele: HTMLElement, className: string) => {
  if (hasClass(ele, className)) {
    const reg = new RegExp('(\\s|^)' + className + '(\\s|$)')
    ele.className = ele.className.replace(reg, ' ')
  }
}

// Toggle class for the selected element
export const toggleClass = (ele: HTMLElement, className: string) => {
  if (!ele || !className) {
    return
  }
  let classString = ele.className
  const nameIndex = classString.indexOf(className)
  if (nameIndex === -1) {
    classString += '' + className
  } else {
    classString = classString.substr(0, nameIndex) + classString.substr(nameIndex + className.length)
  }
  ele.className = classString
}

/**
 * formatter 排序格式化字段
 * @param order
 */
export const formaterOrderKey = (order: string) => {
  if (order === 'descending') {
    return 'desc'
  } else if (order === 'ascending') {
    return 'asc'
  }
  return ''
}
/**
 * 时间戳转换日期
 * @param date
 * @returns
 */
export const formatTime = time => {
  const date = new Date(time)
  const y = date.getFullYear()
  let m: any = date.getMonth() + 1
  m = m < 10 ? '0' + m : m
  let d: any = date.getDate()
  d = d < 10 ? '0' + d : d
  return y + '年' + m + '月' + d + '日'
}

// 将hex颜色转成rgb
export const hexToRgba = (hex, opacity) => {
  const RGBA =
    'rgba(' + parseInt('0x' + hex.slice(1, 3)) + ',' + parseInt('0x' + hex.slice(3, 5)) + ',' + parseInt('0x' + hex.slice(5, 7)) + ',' + opacity + ')'
  return RGBA
}
