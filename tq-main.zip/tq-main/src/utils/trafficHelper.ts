import { isObject, isArray } from './is'
import dayjs from 'dayjs'
const fitlerModel = /^\/login|^\/statistics\/board|^\/home\/getAppTypeTrafficTrend|^\/home\/getGeoTrafficStats|^\/home\/getAppTrafficeTop|^\/home\/getStatsDatas/

/**
 * 流量单位转换
 * 默认返回的byte 转成T
 */
export const trafficUnitChange = byte => {
  let traffic
  if (byte) {
    traffic = (byte / (1024 * 1024 * 1024 * 1024)).toFixed(2)
  } else {
    traffic = byte
  }
  return traffic
}

/**
 * 统一处理流量大小问题
 * @param response
 */
export const transformTraffic = (response: any, path: string) => {
  if (fitlerModel.test(path)) return response
  let resp
  try {
    resp = JSON.parse(JSON.stringify(response))
  } catch (e) {
    throw new Error('transformTraffic JSON.parse error')
  }
  if (resp.data) {
    resp.data = formatTraffic(resp.data)
    // console.log(resp.data)
  }
  return resp
}

/**
 * 转换GBPS
 * （某时间段流量平均速率 =（该时间段该维度的总流量*8）/（该时间段秒数*10^9），算出来的流量平均速率是 Gbps，公式中总流量的单位是Byte。）
 * @param traffic 流量
 * @param startTime 开始时间
 * @param endTime 结束时间
 */
export const transformGbps = (traffic: any, startTime: any, endTime) => {
  const start = dayjs(startTime)
  const end = dayjs(endTime).add(1, 'day')
  const timelong = end.diff(start, 'second')
  console.log(timelong)
  const gps = ((Number(traffic) * 8) / (timelong * Math.pow(10, 9))).toFixed(2)
  console.log(gps)
  return gps
}

/**
 *
 * 格式化流量
 * @returns
 */
export const formatTraffic = (data: any) => {
  const handlerArray = rows => {
    return rows.map(row => {
      if (isObject(row)) {
        const obj: any = Object.create(null)
        Object.keys(row).forEach(j => {
          let value: any = row[j]
          if (/traffic/.test(j) && /^\d+$/.test(value) && String(value) !== '') {
            value = trafficUnitChange(value)
          }
          // if (/proportion/.test(j) && String(value) !== '') {
          //   value = Number(value * 100).toFixed(2) + '%'
          // }
          obj[j] = value
        })
        return obj
      } else {
        return row
      }
    })
  }
  if (isObject(data)) {
    const result = {}
    for (const key in data) {
      const v = data[key]
      if (isArray(v)) {
        result[key] = handlerArray(data[key])
      } else {
        result[key] = v
      }
    }
    return result
  } else if (isArray(data)) {
    return handlerArray(data)
  }
}
