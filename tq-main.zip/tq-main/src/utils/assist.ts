/*
 * @Author: fuping
 * @Date: 2020-04-14 22:22:39
 * @LastEditors: fuping
 * @LastEditTime: 2020-08-14 10:09:43
 * @Description:
 */
import dayjs from 'dayjs'
import { getCookies } from '@/utils/cookiesUtil'
/**
 * @introduction  把数组中key值相同的那一项提取出来，组成一个对象
 * @param {Array} 传入的数组 [{a:"1",b:"2"},{a:"2",b:"3"}]
 * @param {String} key属性名 a
 * @return {返回类型说明}
 * @exception [违例类型] [违例类型说明]
 */
export const dataFormmater = (array: any, key: string) => {
  const result = {}
  for (let i = 0; i < array.length; i++) {
    result[array[i][key]] = array[i]
  }
  return result
}

/**
 * [获取URL中的参数名及参数值的集合]
 * 示例URL:http://htmlJsTest/getrequest.html?uid=admin&rid=1&fid=2&name=小明
 * @param  {[string]} urlStr [当该参数不为空的时候，则解析该url中的参数集合]
 * @return {[string]}       [参数集合]
 */
export const getQueryVariable = (urlStr: any) => {
  let url = ''
  if (typeof urlStr == 'undefined') {
    url = decodeURI(location.search) //获取url中"?"符后的字符串
  } else {
    url = '?' + urlStr.split('?')[1]
  }
  const theRequest = new Object()
  if (url.indexOf('?') != -1) {
    const str = url.substr(1)
    const strs = str.split('&')
    for (let i = 0; i < strs.length; i++) {
      theRequest[strs[i].split('=')[0]] = decodeURI(strs[i].split('=')[1])
    }
  }
  return theRequest
}

// 格式化参数
export const getParmas = (data: any) => {
  let parmas: any = ''
  for (const key in data) {
    parmas += `${key}=${data[key]}&`
  }
  return parmas.slice(0, -1)
}

export const isFunction = (obj: any) => {
  return typeof obj === 'function'
}

export const isArray = (obj: any) => {
  return Array.isArray(obj)
}

export const computedHeight = (dataLength, tr = 32, headHeight = 40) => {
  return `${(dataLength + 1) * tr + headHeight}px`
}

// 关键字标红——两个参数为必填项
export const changeKeywordColor = (keyword, dom) => {
  dom.innerHTML = dom.innerHTML.replace(new RegExp(keyword, 'gi'), `<em style="color: red">${keyword}</em>`)
}

// 关键字标红——表格处理
export const textFormatter = (value: any) => {
  if (getCookies('keyword') && getCookies('keyword') != undefined) {
    const keyword = getCookies('keyword')
    if (isArray(value)) value = value.toString()
    if (new RegExp(keyword).test(value)) {
      try {
        const newValue = value.replace(new RegExp(keyword, 'gi'), `<em style="color: red">${keyword}</em>`)
        value = newValue
      } catch (err) {
        console.log(value, '报错了，格式需要处理')
        return value
      }
    }
  }
  return value
}

// 数字转为百分比
export const toPercent = (value: any) => {
  const number = Number(value * 100).toFixed(2) + '%'
  return number
}
