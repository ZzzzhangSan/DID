import { isObject, isArray, isNumber, isString, isNullAndUnDef } from './is'
import dayjs from 'dayjs'
import { cloneDeep } from 'lodash-es'
const D_FORMART = 'YYYY-MM-DD HH:mm:ss'
// Parse the time to string
export const parseTime = (time: number | string, cFormat = D_FORMART) => {
  if (isString(time)) {
    time = Number(time)
  }
  return dayjs.unix(time).format(cFormat)
}
// 字符串转时间戳
export const parse2Timestamp = (time: string | number) => {
  // console.log(time, dayjs(time, D_FORMART).unix())
  return dayjs(time, D_FORMART).unix()
}

// Format and filter json data using filterKeys array
export const formatJson = (filterKeys: any, jsonData: any) => {
  return jsonData.map(v =>
    filterKeys.map(j => {
      if (j === 'timestamp') {
        return parseTime(v[j])
      } else {
        return v[j]
      }
    })
  )
}

//要过滤的路由请求
const fitlerModel = /^\/login|^\/statistics\/board|^\/task\/create/
/**
 * 统一转换http response中 时间戳问题
 * @param response
 */
export const transformRespTimStamp = (response: any) => {
  if (fitlerModel.test(response.config.url)) return response
  const resp = cloneDeep(response)
  if (resp.data && resp.data?.res_data?.length && isArray(resp.data?.res_data)) {
    resp.data.res_data = formatTimeStamp(resp.data.res_data)
  }
  return resp
}

// 格式会数据时间戳类型 到 字符串日期
/**
 * 把数据中的时间戳 格式化字符串
 * @param data {Object|Array}
 * @param format
 * @returns
 */
export const formatTimeStamp = (data: any) => {
  //判断是不是时间戳
  const isTimeStamp = v => {
    return !isNullAndUnDef(v) && isNumber(v) && String(v).length >= 10
  }

  const handlerArray = rows => {
    return rows.map(row => {
      if (isObject(row)) {
        const obj: any = Object.create(null)
        Object.keys(row).forEach(j => {
          let value = row[j]
          if (/timestamp|_timestamp$/.test(j) && isTimeStamp(value) && value !== '') {
            value = parseTime(value)
          }
          obj[j] = value
        })
        return obj
      } else if (isTimeStamp(row)) {
        return parseTime(row)
      } else {
        return row
      }
    })
  }
  if (isObject(data)) {
    const result = {}
    for (const key in data) {
      const v = data[key]
      if (isArray(v)) {
        result[key] = handlerArray(data[key])
      } else if (isTimeStamp(v) && /timestamp|_timestamp$/.test(key)) {
        result[key] = parseTime(v)
      } else {
        result[key] = v
      }
    }
    return result
  } else if (isArray(data)) {
    return handlerArray(data)
  }
}
