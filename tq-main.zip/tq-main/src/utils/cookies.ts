import Cookies from 'js-cookie'
import { getCookies, setCookies, removeCookies, setSession, getLocalStorage, setLocalStorage, removeLocalStorage } from '@/utils/cookiesUtil'

//App
const sidebarStatusKey = 'sys_sidebar_status'
export const getSidebarStatus = () => Cookies.get(sidebarStatusKey)
export const setSidebarStatus = (sidebarStatus: string) => Cookies.set(sidebarStatusKey, sidebarStatus)

// const languageKey = 'language'
// export const getLanguage = () => Cookies.get(languageKey)
// export const setLanguage = (language: string) => Cookies.set(languageKey, language)

// const sizeKey = 'size'
// export const getSize = () => Cookies.get(sizeKey)
// export const setSize = (size: string) => Cookies.set(sizeKey, size)

// token
const tokenKey = 'sys_token'
export const setToken = (token: string) => Cookies.set(tokenKey, token)
export const getToken = () => Cookies.get(tokenKey)
export const removeToken = () => Cookies.remove(tokenKey)

// // User
// const userInfo = 'sys_UserInfo'
// export const setUserInfo = (value: any) => Cookies.set(userInfo, value)
// export const getUserInfo = () => JSON.parse(Cookies.get(userInfo))
// export const removeUserInfo = () => Cookies.remove(userInfo)

// // menu
// const menuData = 'MenuData'
// export const setMenu = (value: any) => setLocalStorage({ MenuData: value })
// export const getMenu = () => getLocalStorage(menuData)
// export const removeMenu = () => removeLocalStorage(menuData)

// // header-menu
// const firstMenuData = 'firstMenuData'
// export const setFirstMenu = (value: any) => setLocalStorage({ firstMenuData: value })
// export const getFirstMenu = () => getLocalStorage(firstMenuData)
// export const removeFirstMenu = () => removeLocalStorage(firstMenuData)

// // nav
// const navData = 'tjNavData'
// export const setNav = (value: any) => setLocalStorage({ tjNavData: value })
// export const getNav = () => getLocalStorage(navData)
// export const removeNav = () => removeLocalStorage(navData)
