import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
import { RouteConfig } from 'vue-router'
import { UserModule } from '@/store/modules/user'
import { useSysMenuData } from '@/menu'
import { getLocalStorage } from '@/utils/cookiesUtil'
import { PermissionModule } from '@/store/modules/permission'
export const constantRoutes: RouteConfig[] = [
  {
    path: '/',
    redirect: 'realAlarm'
  },
  {
    path: '/refresh',
    name: 'refresh',
    meta: {
      title: ''
    },
    component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/refresh.vue')
  },
  // {
  //   path: '/login',
  //   name: 'login',
  //   meta: {
  //     title: '登录页'
  //   },
  //   component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/login/Login.vue')
  // },
  {
    path: '*',
    name: 'notFound',
    component: () => import(/* webpackChunkName: "sys" */ '@/views/sys/notFound.vue'),
    meta: {
      title: 'Not Found'
    }
  }
]

// if (process.env.NODE_ENV === 'development') {
//   constantRoutes.push({
//     name: 'example',
//     path: '/example',
//     meta: {
//       title: 'example'
//     },
//     component: () => import(/* webpackChunkName: "sys" */ '@/views/__example/index.vue')
//   })
// }

// 刷新 判断token 默认加载离线数据
//if (token_key !== null && user_level !== null) {
// const { router } = useSysMenuData(Number(user_level))
// console.log(token_key, user_level)
// // 设置权限
// PermissionModule.GenerateRole(Number(user_level))
// // 跳转默认路由
// PermissionModule.goDefaultRouter(Number(user_level))
//}

// const originalPush: any = VueRouter.prototype.push
// ;(VueRouter.prototype as any).push = function push(location, onResolve, onReject) {
//   if (onResolve || onReject) return originalPush.call(this, location, onResolve, onReject)
//   return originalPush.call(this, location).catch(err => err)
// }

function createRouter() {
  return new VueRouter({
    // mode: 'history',  // Disabled due to Github Pages doesn't support this, enable this if you need.
    scrollBehavior: (to, from, savedPosition) => {
      if (savedPosition) {
        return savedPosition
      } else {
        return { x: 0, y: 0 }
      }
    },
    base: process.env.BASE_URL,
    routes: constantRoutes
  })
}
export const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  ;(router as any).matcher = (newRouter as any).matcher // reset router
}

// 路由守卫
router.beforeEach((to, from, next) => {
  if (to.path === '/login') {
    next()
  } else {
    next()
  }
})

export default router
