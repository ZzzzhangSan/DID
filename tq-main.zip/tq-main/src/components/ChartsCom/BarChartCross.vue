<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, onMounted, watch, toRefs } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { cloneDeep } from 'lodash-es'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
import { hexToRgba } from '@/utils'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_BarCharts',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { data, option } = toRefs(props)
    const colors = option.value.colors
    const splitLine = chartConfig.getSplitLine(option.value.splitLine)
    const axisLine = chartConfig.getAxisLine(option.value.axisLine)
    const axisLabel = chartConfig.getAxisLabel(option.value.axisLabel)
    const orient = option.value.orient
    const barWidth = option.value.barWidth || 16

    const createOptions = datas => {
      const yData: any = []
      const xData: any = []

      const data = cloneDeep(datas)

      data.forEach((item: any, index: number) => {
        yData.push(item.name)
        xData.push(Number(item.value))
      })

      const maxArr: any = []
      const max = Math.max(...xData)
      xData.forEach(() => {
        maxArr.push(max)
      })

      const xType = orient === 'horizontal' ? 'value' : 'category'
      const yType = orient === 'horizontal' ? 'category' : 'value'
      const richStyleA = {
        color: '#fff',
        backgroundColor: '#EE4343',
        width: 28,
        height: 18,
        align: 'center',
        verticalAlign: 'middle',
        borderRadius: 2,
        padding: [3, 0, 0, 0]
      }
      const yAxisLabel = {
        interval: 0,
        //overflow: 'truncate',
        //width: 130,
        rich: {
          a1: richStyleA,
          a2: richStyleA,
          a3: richStyleA,
          b: {
            color: '#fff',
            backgroundColor: '#C2C2C2',
            width: 28,
            height: 18,
            align: 'center',
            verticalAlign: 'middle',
            borderRadius: 2,
            padding: [3, 0, 0, 0]
          },
          c: {
            color: '#000',
            backgroundColor: 'transparent',
            width: 90,
            height: 18,
            align: 'right',
            verticalAlign: 'middle',
            borderRadius: 2,
            lineHeight: 18
          }
        },
        formatter: function(params) {
          let index = cloneDeep(data)
            .map(item => item.name)
            .indexOf(params)
          index = index + 1
          const str = params.length > 6 || params.length == 6 ? params.slice(0, 6) + '...' : params
          if (index - 1 < 3) {
            return ['{a' + index + '|' + index + '}'].join('\n') + ['{c|' + str + '}']
          } else {
            return ['{b|' + index + '}'].join('\n') + ['{c|' + str + '}']
          }
        }
      }

      const option = {
        title: {
          text: data.length <= 0 ? '无数据' : '',
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgba(0,0,0, .4)'
          }
        },
        backgroundColor: 'transparent',
        tooltip: {
          trigger: 'axis',
          textStyle: {
            color: '#000'
          },
          axisPointer: {
            type: 'shadow',
            shadowStyle: {
              color: 'rgba(117, 115, 115, 0.03)'
            }
          },
          extraCssText: `#fff`,
          formatter: function(params) {
            return `${params[0].name}<br/>${params[0].value}T`
          }
        },
        grid: {
          left: 10,
          bottom: 10,
          top: 20,
          right: 10,
          containLabel: true
        },
        xAxis: [
          {
            type: xType,
            axisLabel: axisLabel.xAxis,
            axisLine: axisLine.xAxis,
            axisTick: { show: false },
            splitLine: splitLine.xAxis,
            data: xData
          }
        ],
        yAxis: [
          {
            type: yType,
            axisTick: { show: false },
            triggerEvent: false,
            axisLine: axisLine.yAxis,
            axisLabel: Object.assign({}, yAxisLabel, axisLabel.yAxis),
            data: cloneDeep(yData).reverse()
          },
          {
            type: 'category',
            inverse: true,
            axisTick: 'none',
            axisLine: 'none',
            show: true,
            axisLabel: {
              backgroundColor: '#F0EEFE',
              lineHeight: 18,
              width: 40,
              padding: [0, 3, 0, 3],
              interval: 0,
              textStyle: {
                color: '#6654F9',
                fontSize: '12'
              },
              // formatter: '{value}GB'
              formatter: function(params, index) {
                const proportion = datas[index].obj.proportion
                return proportion ? `${Number(proportion * 100).toFixed(2) + '%'}` : `${params}T`
              }
            },
            data: xData
          }
        ],
        series: [
          {
            type: 'bar',
            data: cloneDeep(xData).reverse(),
            barWidth: barWidth,
            zlevel: 1,
            itemStyle: {
              color: {
                type: 'linear',
                x: 0,
                y: orient === 'horizontal' ? 0 : 1,
                x2: orient === 'horizontal' ? 1 : 0,
                y2: 0,
                colorStops: [
                  {
                    offset: 0,
                    color: hexToRgba(colors, 0.3) // 0% 处的颜色
                  },
                  {
                    offset: 1,
                    color: hexToRgba(colors, 1) // 100% 处的颜色
                  }
                ],
                global: false // 缺省为 false
              }
            }
          },
          {
            name: '背景',
            type: 'bar',
            barWidth: barWidth,
            barGap: '-100%',
            data: maxArr,
            itemStyle: {
              color: '#F9F9FB'
            },
            emphasis: {
              itemStyle: {
                color: '#F9F9FB'
              }
            }
          }
        ]
      } as EChartsOption
      return option
    }
    watch(data, function(newval, oldval) {
      //if (newval && newval.length) {
      setOptions(createOptions(newval))
      //}
    })
    onMounted(() => {
      setOptions(createOptions(data.value))
    })
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.container {
  position: relative;
}
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
