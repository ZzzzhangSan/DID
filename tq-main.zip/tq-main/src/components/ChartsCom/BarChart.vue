<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, onMounted, watch, toRefs } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
import { hexToRgba } from '@/utils'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_BarCharts',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { data, option } = toRefs(props)
    const colors = option.value.colors
    const splitLine = chartConfig.getSplitLine(option.value.splitLine)
    const axisLine = chartConfig.getAxisLine(option.value.axisLine)
    const axisLabel = chartConfig.getAxisLabel(option.value.axisLabel)
    const stack = option.value.stack
    const lengend = option.value.lengend || {}
    const barWidth = option.value.barWidth || 28
    const linear = option.value.linear || false
    const unit = option.value.unit ? option.value.unit : ''

    axisLabel.xAxis.rotate = 30
    const createOptions = data => {
      const xData: any = []
      const series: any = []
      const legendData: any = []
      data.forEach((item: any, index: number) => {
        if (legendData.indexOf(item.category) < 0) {
          legendData.push(item.category)
        }
        if (xData.indexOf(item.name) < 0) {
          xData.push(item.name)
        }
      })

      for (let i = 0; i < legendData.length; i++) {
        const yValue: any = []
        data.forEach(it => {
          if (it.category === legendData[i]) {
            yValue.push({ name: it.name, value: it.value })
          }
        })
        const itemStyle = {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: hexToRgba(colors[i % colors.length], 1) // 0% 处的颜色
              },
              {
                offset: 0.5,
                color: hexToRgba(colors[i % colors.length], 0.4) // 0% 处的颜色
              },
              {
                offset: 1,
                color: hexToRgba(colors[i % colors.length], 0.01) // 100% 处的颜色
              }
            ],
            global: false // 缺省为 false
          }
        }
        series.push({
          name: legendData[i],
          type: 'bar',
          stack: stack ? '堆积' : '',
          barWidth: barWidth,
          itemStyle: linear ? itemStyle : {},
          label: {
            show: false,
            position: 'insideRight'
          },
          data: yValue
        })
      }

      const defaultLengend = Object.assign(
        {
          show: true,
          type: 'scroll',
          icon: 'rect',
          itemWidth: 15,
          itemHeight: 3,
          itemGap: 8,
          padding: 4,
          data: legendData,
          textStyle: {
            fontSize: 12,
            color: '#fff'
          },
          // 图例翻页三角颜色
          pageIconColor: '#08BAFF'
        },
        lengend
      )

      const option = {
        title: {
          text: data.length <= 0 ? '无数据' : '',
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgba(0,0,0, .4)'
          }
        },
        backgroundColor: 'transparent',
        legend: defaultLengend,
        tooltip: {
          textStyle: {
            color: '#000'
          },
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
            shadowStyle: {
              color: 'rgba(117, 115, 115, 0.03)'
            }
          },
          extraCssText: `#fff`,
          formatter: function(params) {
            if (params.length > 1) {
              return `
              ${params[0].name}</br>
              ${params[0].seriesName}:${params[0].value}${unit}<br/>
              ${params[1].seriesName}:${params[1].value}${unit}
              `
            } else {
              return `${params[0].name}<br/>${params[0].value}${unit}`
            }
          }
        },
        color: colors,
        grid: {
          left: 10,
          bottom: 10,
          top: lengend.show ? 40 : 20,
          right: 10,
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: xData,
            axisTick: { show: false },
            axisLabel: axisLabel.xAxis,
            splitLine: splitLine.xAxis,
            axisLine: axisLine.xAxis
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '',
            axisTick: { show: false },
            axisLabel: axisLabel.yAxis,
            splitLine: splitLine.yAxis,
            axisLine: axisLine.yAxis
          }
        ],
        series: series
      } as EChartsOption
      return option
    }
    watch(data, function(newval, oldval) {
      //if (newval && newval.length) {
      setOptions(createOptions(newval))
      //}
    })
    onMounted(() => {
      setOptions(createOptions(data.value))
    })
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.container {
  position: relative;
}
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
