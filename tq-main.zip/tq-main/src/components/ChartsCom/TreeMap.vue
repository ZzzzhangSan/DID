<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, onMounted, watch, toRefs } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { defaultsDeep } from 'lodash'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
import { hexToRgba } from '@/utils'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_TreeMap',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { data } = toRefs(props)
    watch(data, (newval, oldval) => {
      if (newval) {
        setOptions(createOptions(newval))
      }
    })

    function createOptions(data: any) {
      for (const n in data) {
        data[n]['name'] = data[n]['name'] + ' ' + data[n]['value']
      }
      const opt = {
        tooltip: {
          trigger: 'item',
          formatter: '{b}'
        },
        color: ['#546BC1', '#1934CB', '#008056', '#992CE4', '#5404C2', '#32008C', '#003C37', '#00ABB4'],
        series: [
          {
            type: 'treemap',
            width: '100%',
            height: '100%',
            top: '0',
            roam: false, //是否开启拖拽漫游（移动和缩放）
            nodeClick: false, //点击节点后的行为,false无反应
            breadcrumb: {
              show: false
            },
            label: {
              //描述了每个矩形中，文本标签的样式。
              normal: {
                show: true,
                position: ['10%', '40%']
              }
            },
            itemStyle: {
              normal: {
                show: true,
                textStyle: {
                  color: '#fff',
                  fontSize: 16
                }
              },
              emphasis: {
                label: {
                  show: true
                }
              }
            },
            data: data
          }
        ]
      } as EChartsOption
      const option = props.option != null ? defaultsDeep(props.option, opt) : opt
      return option
    }
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.container {
  position: relative;
}
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
