<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, onMounted, watch, toRefs } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { cloneDeep } from 'lodash-es'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_BarCharts',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { data, option } = toRefs(props)
    const colors = option.value.colors
    const splitLine = chartConfig.getSplitLine(option.value.splitLine)
    const axisLine = chartConfig.getAxisLine(option.value.axisLine)
    const axisLabel = chartConfig.getAxisLabel(option.value.axisLabel)
    const stack = option.value.stack
    const smooth = option.value.smooth ? true : false
    const title = option.value.title || ''
    const lengend = option.value.lengend || {}

    const createOptions = data => {
      const xData: any = []
      const series: any = []
      const legendData: any = []
      const types: any = []
      data.forEach((item: any, index: number) => {
        if (legendData.indexOf(item.category) < 0) {
          legendData.push(item.category)
          types.push(item.type)
        }
        if (xData.indexOf(item.name) < 0) {
          xData.push(item.name)
        }
      })

      for (let i = 0; i < legendData.length; i++) {
        const yValue: any = []
        data.forEach(it => {
          if (it.category === legendData[i]) {
            yValue.push({ name: it.name, value: it.value })
          }
        })
        if (types[i] === 'bar') {
          series.push({
            name: legendData[i],
            type: 'bar',
            stack: stack ? '堆积' : '',
            barWidth: '16',
            label: {
              show: false,
              position: 'insideRight'
            },
            data: yValue
          })
        } else if (types[i] === 'line') {
          series.push({
            name: legendData[i],
            type: 'line',
            smooth: smooth,
            label: {
              show: false,
              position: 'insideRight'
            },
            data: yValue
          })
        }
      }
      const defaultLengend = Object.assign(
        {
          show: true,
          type: 'scroll',
          icon: 'rect',
          itemWidth: 15,
          itemHeight: 3,
          itemGap: 8,
          data: legendData,
          textStyle: {
            fontSize: 12,
            color: '#fff'
          },
          // 图例翻页三角颜色
          pageIconColor: '#08BAFF'
        },
        lengend
      )

      const option = {
        title: {
          text: data.length <= 0 ? '无数据' : title,
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgba(0,0,0, .4)'
          }
        },
        backgroundColor: 'transparent',
        legend: defaultLengend,
        tooltip: {
          trigger: 'axis',
          textStyle: {
            color: '#ffffff'
          },
          extraCssText: `background: linear-gradient(180deg, rgba(38, 64, 99, 0.9) 0%, rgba(15, 67, 84, 0.91) 100%);border: 1px solid rgba(53, 197, 255, 0.8);`
        },
        color: colors,
        grid: {
          left: 10,
          bottom: 10,
          top: lengend.show ? 40 : 20,
          right: 10,
          containLabel: true
        },
        xAxis: [
          {
            type: 'category',
            data: xData,
            axisTick: { show: false },
            axisLabel: axisLabel.xAxis,
            splitLine: splitLine.xAxis,
            axisLine: axisLine.xAxis
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '',
            axisTick: { show: false },
            axisLabel: axisLabel.yAxis,
            splitLine: splitLine.yAxis,
            axisLine: axisLine.xAxis
          }
        ],
        series: series
      } as EChartsOption
      return option
    }
    watch(data, function(newval, oldval) {
      //if (newval && newval.length) {
      setOptions(createOptions(newval))
      //}
    })
    onMounted(() => {
      setOptions(createOptions(data.value))
    })
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.container {
  position: relative;
}
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
