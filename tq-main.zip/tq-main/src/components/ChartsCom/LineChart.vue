<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>

<script lang="ts">
import { defineComponent, ref, Ref, watch, toRefs, onMounted } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { cloneDeep, defaultsDeep } from 'lodash'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
import { hexToRgba } from '@/utils'
export default defineComponent({
  name: 'common_lineChart',
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  setup(props, { emit }) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>, '', {
      clickHandler(args) {
        emit('click', args)
      }
    })
    const { data, option } = toRefs(props)
    const colors = option.value.colors
    const splitLine = chartConfig.getSplitLine(option.value.splitLine)
    const axisLine = chartConfig.getAxisLine(option.value.axisLine)
    const axisLabel = chartConfig.getAxisLabel(option.value.axisLabel)
    const yText = option.value.yText || ''
    const smooth = option.value.smooth ? true : false
    const titleText = option.value.title || ''
    const lengend: any = option.value.lengend ? true : false
    const unit = option.value.unit ? option.value.unit : ''
    const dataZoomShow = option.value.dataZoom || false

    function createOptions(datas: any) {
      const legendData: any = []
      const series: any[] = []
      const xAxisData: any = []
      let title: any = {}

      if (datas.length <= 0) {
        title = {
          text: '无数据',
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgba(0,0,0, .4)'
          }
        }
      } else {
        title = {
          text: titleText,
          left: 20,
          top: 0,
          textStyle: {
            color: '#08BAFF',
            fontWeight: 'normal',
            fontSize: '14px'
          }
        }
      }

      datas.forEach(it => {
        if (legendData.indexOf(it.category) < 0) {
          legendData.push(it.category)
        }
        if (xAxisData.indexOf(it.name) < 0) {
          xAxisData.push(it.name)
        }
      })

      legendData.forEach((it, index) => {
        const seriesData: any = []
        datas.forEach(d => {
          if (it === d.category) {
            seriesData.push(d.value)
          }
        })

        series.push({
          name: it,
          type: 'line',
          smooth: smooth,
          // areaStyle: {
          //   color: {
          //     type: 'linear',
          //     x: 0,
          //     y: 0,
          //     x2: 0,
          //     y2: 1,
          //     colorStops: [
          //       {
          //         offset: 0,
          //         color: hexToRgba(colors[index % colors.length], 0.2) // 0% 处的颜色
          //       },
          //       {
          //         offset: 0.8,
          //         color: hexToRgba(colors[index % colors.length], 0.05) // 0% 处的颜色
          //       }
          //     ],
          //     global: false // 缺省为 false
          //   }
          // },
          //symbol: 'emptyCircle',
          // 节点显示及大小
          // showSymbol: legendData.length > 1 ? false : true,
          showSymbol: false,
          symbolSize: 5,
          zlevel: 3,
          lineStyle: {
            color: colors[index % colors.length]
          },
          data: seriesData
        })
      })

      const defaultLengend = Object.assign(
        {
          show: lengend,
          type: 'scroll',
          icon: 'rect',
          itemWidth: 15,
          itemHeight: 3,
          itemGap: 8,
          top: 0,
          padding: [0, 0, 30, 0],
          data: legendData,
          textStyle: {
            fontSize: 12
          },
          // 图例翻页三角颜色
          pageIconColor: '#08BAFF'
        },
        lengend
      )

      const dataZoom = [
        {
          type: 'inside',
          start: 0,
          end: 10
        },
        {
          start: 0,
          end: 10,
          height: 14
        }
      ]

      const option = {
        title: title,
        color: colors,
        legend: defaultLengend,
        tooltip: {
          trigger: 'axis',
          textStyle: {
            color: '#000'
          },
          confine: true,
          // formatter: function(params, t) {
          //   //console.log(params, t)
          //   let str: any = ''
          //   let name: any = ''
          //   let i: any = 1
          //   const len = params.length
          //   //console.log(len)
          //   params.forEach(it => {
          //     console.log(it)
          //     name = it.name
          //     let itStr: any = ''
          //     const styleStr = `width:5px;height:5px;display:inline-block;border-radius:50%;margin-right:5px;background:${it.color};`
          //     const styleTitle = 'width:100px;display:inline-block;'
          //     const styleValue = 'font-weight:bold;display:inline-block;width:60px;'
          //     if (len > 8) {
          //       if (i % 2 === 0) {
          //         itStr = `<span style=${styleTitle}><i style=${styleStr}></i>${it.seriesName}:</span><span style=${styleValue}>${it.value}${unit}</span><br>`
          //       } else {
          //         itStr = `<span style=${styleTitle}><i style=${styleStr}></i>${it.seriesName}:</span><span style=${styleValue}>${it.value}${unit}</span>&nbsp;&nbsp;&nbsp;&nbsp;`
          //       }
          //     } else {
          //       itStr = `<span style=${styleTitle}><i style=${styleStr}></i>${it.seriesName}:</span><span style=${styleValue}>${it.value}${unit}</span><br>`
          //     }

          //     str += itStr
          //     i++
          //   })
          //   str = `${name}<br>${str}`
          //   return str
          // },
          extraCssText: `background:#fff;border:none;`
        },
        grid: {
          left: 20,
          bottom: dataZoomShow ? 70 : 10,
          top: lengend.show ? 60 : 40,
          right: 20,
          containLabel: true
        },
        dataZoom: dataZoomShow ? dataZoom : [],
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            axisLabel: axisLabel.xAxis,
            axisTick: { show: false },
            axisLine: axisLine.xAxis,
            splitLine: splitLine.xAxis,
            data: xAxisData
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: yText,
            nameTextStyle: {
              color: 'rgba(0,0,0,.7)',
              align: 'right'
            },
            axisLabel: axisLabel.yAxis,
            splitLine: splitLine.yAxis,
            axisLine: axisLine.yAxis,
            axisTick: { show: false }
          }
        ],
        series: series
      } as EChartsOption
      return option
    }

    watch(data, (newval, oldval) => {
      if (newval) {
        setOptions(createOptions(newval))
      }
    })
    onMounted(() => {
      setOptions(createOptions(data.value))
    })
    return {
      chartRef
    }
  }
})
</script>
<style lang="less" scoped></style>

<style lang="less" scoped></style>
