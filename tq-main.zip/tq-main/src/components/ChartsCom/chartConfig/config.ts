const getSplitLine = option => {
  let color = 'rgba(236, 238, 246, 1)'
  let xAxisShow = false
  let yAxisShow = true
  if (option) {
    color = option.color ? option.color : color
    xAxisShow = option.xAxis
    yAxisShow = option.yAxis
  }
  const lineStyle = {
    type: 'dashed',
    color: color
  }
  return {
    xAxis: {
      show: xAxisShow,
      lineStyle: lineStyle
    },
    yAxis: {
      show: yAxisShow,
      lineStyle: lineStyle
    }
  }
}
const getAxisLine = option => {
  let color = '#D8D8D8'
  let xAxisShow = true
  let yAxisShow = true
  if (option) {
    color = option.color ? option.color : color
    xAxisShow = option.xAxis
    yAxisShow = option.yAxis
  }
  const lineStyle = {
    type: 'solid',
    color: color
  }
  return {
    xAxis: {
      show: xAxisShow,
      symbol: ['none', 'none'],
      symbolSize: [6, 10],
      lineStyle: lineStyle
    },
    yAxis: {
      show: yAxisShow,
      symbol: ['none', 'none'],
      symbolSize: [6, 10],
      lineStyle: lineStyle
    }
  }
}
const getAxisLabel = option => {
  let color = 'rgba(0,0,0,.7)'
  let xAxisShow = true
  let yAxisShow = true
  let rotate = 0
  if (option) {
    color = option.color ? option.color : color
    xAxisShow = option.xAxis !== undefined ? option.xAxis : true
    yAxisShow = option.yAxis !== undefined ? option.xAxis : true
    rotate = option.rotate ? option.rotate : 0
  }
  const textStyle = {
    color: color
  }
  return {
    xAxis: {
      show: xAxisShow,
      textStyle: textStyle,
      rotate: rotate
    },
    yAxis: {
      show: yAxisShow,
      textStyle: textStyle
    }
  }
}
export const chartConfig = {
  getSplitLine,
  getAxisLine,
  getAxisLabel
}
