const cdAreaCode = {
  锦江区: 510104,
  青羊区: 510105,
  金牛区: 510106,
  武侯区: 510107,
  成华区: 510108,
  龙泉驿区: 510112,
  青白江区: 510113,
  新都区: 510114,
  温江区: 510115,
  双流区: 510116,
  郫都区: 510117,
  金堂县: 510121,
  大邑县: 510129,
  蒲江县: 510131,
  新津区: 510132,
  都江堰市: 510181,
  彭州市: 510182,
  邛崃市: 510183,
  崇州市: 510184,
  简阳市: 510185
}
const cdAreaNameToPy = {
  锦江区: 'jinjiang',
  青羊区: 'qingyang',
  金牛区: 'jinniu',
  武侯区: 'wuhou',
  成华区: 'chenghua',
  龙泉驿区: 'longquanyi',
  青白江区: 'qingbaijiang',
  新都区: 'xindu',
  温江区: 'wenjiang',
  双流区: 'shuangliu',
  郫都区: 'pidu',
  金堂县: 'jintang',
  大邑县: 'dayi',
  蒲江县: 'pujiang',
  新津县: 'xinjin',
  都江堰市: 'dujiangyan',
  彭州市: 'pengzhou',
  邛崃市: 'qionglai',
  崇州市: 'chongzhou',
  简阳市: 'jianyang'
}

export const areaCodeMap = {
  cdAreaCode,
  cdAreaNameToPy
}
