<template>
  <div ref="chartRef" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, onMounted, watch, toRefs } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { defaultsDeep } from 'lodash'
import { PropType } from 'vue'
import { chartConfig } from './chartConfig/config'
import { hexToRgba } from '@/utils'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_GraphCharts',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { data } = toRefs(props)
    const categories = [
      {
        name: '非重点人',
        itemStyle: {
          color: '#08BAFF'
        }
      },
      {
        name: '目标人',
        itemStyle: {
          color: '#04C592'
        }
      },
      {
        name: '重点人',
        itemStyle: {
          color: '#0344E2'
        }
      }
    ]
    watch(data, (newval, oldval) => {
      if (newval) {
        setOptions(createOptions(newval))
      }
    })

    function createOptions(data: any) {
      data[0].nodes.forEach((node: any) => {
        if (node.category === 0) {
          node.symbolSize = 40
          node.itemStyle = {
            color: '#08BAFF'
          }
        } else if (node.category === 1) {
          node.symbolSize = 40
          node.itemStyle = {
            color: '#04C592'
          }
        } else if (node.category === 2) {
          node.symbolSize = 40
          node.itemStyle = {
            color: '#0344E2'
          }
        }
      })
      const opt = {
        tooltip: {
          formatter: '{b}'
        },
        legend: [
          {
            data: categories.map(x => x.name),
            textStyle: {
              color: '#fff'
            }
          }
        ],
        series: [
          {
            type: 'graph',
            layout: 'force',
            symbolSize: 60,
            roam: true,
            categories: categories,
            force: {
              repulsion: 200,
              gravity: 0.02,
              edgeLength: 50,
              layoutAnimation: true
            },
            label: {
              normal: {
                show: true,
                textStyle: {
                  fontSize: 12,
                  color: '#fff'
                }
              }
            },
            edgeSymbol: ['', 'arrow'],
            lineStyle: {
              normal: {
                color: '#1C85FF',
                width: 1
              }
            },
            data: data[0].nodes,
            links: data[0].links
          }
        ]
      } as EChartsOption
      const option = props.option != null ? defaultsDeep(props.option, opt) : opt
      return option
    }
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.container {
  position: relative;
}
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
