<template>
  <div ref="chartRef" class="charts-box" style="width:100%;height:100%"></div>
</template>
<script lang="ts">
import { defineComponent, ref, Ref, toRefs, watch, onMounted } from '@vue/composition-api'
import { useECharts } from '@/hooks/useECharts'
import { EChartsOption } from 'echarts'
import { cloneDeep, defaultsDeep } from 'lodash'
import { PropType } from 'vue'
import { toPercent } from '@/utils/assist'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<any[]>,
      default: null
    },
    option: {
      type: Object as any,
      default: null
    }
  },
  name: 'common_PieCharts',
  setup(props) {
    const chartRef = ref<HTMLDivElement | null>(null)
    const { setOptions } = useECharts(chartRef as Ref<HTMLDivElement>)
    const { option, data } = toRefs(props)
    const colors = option.value.colors || ['#59B5CD', '#4BBDFF', '#1073FD', '#F2D230', '#F39A00', '#F35900', '#C1F43A', '#6CDA29', '#3F89F1']
    const lengend = option.value.lengend || {}
    const toolUnit = option.value.toolUnit ? option.value.toolUnit : 'T'

    watch(data, (newval, oldval) => {
      if (newval) {
        setOptions(createOptions(newval))
      }
    })

    function createOptions(datas: any) {
      const data = cloneDeep(datas)
      const _datas = data.map((item, index) => {
        const { name, value, obj } = item
        return {
          value,
          name,
          obj: obj,
          itemStyle: {
            color: colors[index]
          }
        }
      })
      const legendData = data.map(item => {
        return { name: item.name, icon: 'circle' }
      })

      const opt = {
        tooltip: {
          trigger: 'item',
          textStyle: {
            color: '#000'
          },
          axisPointer: {
            type: 'none'
          },
          extraCssText: `background:#fff;border:none;`,
          formatter: function(params) {
            return `${params.data.name} <br/>
            流量：${params.data.value}${toolUnit} <br/>
            占比：${params.data.obj ? Number(params.data.obj.proportion * 100).toFixed(2) + '%' : ''}`
          }
        },
        color: colors,
        legend: {
          show: true,
          icon: 'circle',
          align: 'left',
          orient: 'horizontal',
          // right: '0',
          top: '2%',
          itemWidth: 10,
          itemHeight: 10,
          padding: [0, 0, 20, 0],
          textStyle: {
            color: '#000000'
          },
          data: legendData
        },
        grid: {
          left: 10,
          bottom: 10,
          top: lengend.show ? 40 : 20,
          right: 10,
          containLabel: true
        },

        series: [
          {
            name: '',
            type: 'pie',
            radius: ['35%', '55%'],
            // itemStyle: {
            //   borderRadius: 8
            // },
            // roseType: 'area',
            // radius: ['35%', '55%'],
            silent: false,
            z: 0,
            zlevel: 0,
            label: {
              show: true,
              textStyle: {
                fontSize: 14,
                color: '#3D3D3D'
              },
              position: 'outside',
              formatter: params => {
                // console.log(params)
                const data: any = params.data
                const name: any = params.name
                const proportion = data.obj.proportion
                return `{title|${name}} {value|${Number(proportion * 100).toFixed(2)}%}`
              },
              rich: {
                value: {
                  fontSize: 14,
                  fontWeight: 'bolder',
                  // color: 'inherit'
                  color: '#3D3D3D'
                },
                title: {
                  fontSize: 12,
                  fontWeight: 'bolder',
                  // color: 'inherit'
                  color: '#3D3D3D'
                }
              },
              emphasis: {
                show: true
              }
            },
            labelLine: {
              normal: {
                show: true,
                length: 10,
                length2: 20
              },
              emphasis: {
                show: true
              }
            },
            data: _datas
          }
        ]
      } as EChartsOption
      // const option = props.option != null ? defaultsDeep(props.option, opt) : opt
      let title = {}
      if (_datas.length == 0) {
        title = {
          text: '无数据',
          left: 'center',
          top: 'center',
          textStyle: {
            color: 'rgba(0,0,0,.4)'
          }
        }
      }
      opt.title = title
      return opt
    }
    onMounted(() => {
      setOptions(createOptions(data.value))
    })
    return { chartRef }
  }
})
</script>
<style lang="less" scoped>
.charts-box {
  width: 100%;
  height: 100%;
}
</style>
