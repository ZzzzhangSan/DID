<template>
  <div class="uploadExcel">
    <input ref="excelUploadInput" class="excel-upload-input" type="file" accept=".xlsx, .xls" @change="handleClick" />
    <!-- <el-input v-model="fileName"></el-input> -->
    <el-button type="primary" @click="handleUpload">导 入</el-button>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, unref } from '@vue/composition-api'
import XLSX from 'xlsx'
import { Message } from 'element-ui'
/**
 * excel上传组件
 */
export default defineComponent({
  name: 'UploadExcelComp',
  props: {
    beforeUpload: Function, // eslint-disable-line
    onSuccess: Function // eslint-disable-line
  },
  setup(props) {
    const excelUploadInput: any = ref(null)
    const loading = ref(false)
    const onSuccess = props.onSuccess
    const beforeUpload = props.beforeUpload
    const fileName = ref('')
    const excelData = reactive({
      header: {},
      results: {}
    })

    function generateData(rawFile) {
      onSuccess && onSuccess(rawFile)
    }
    function handleDrop(e) {
      e.stopPropagation()
      e.preventDefault()
      if (unref(loading)) return
      const files = e.dataTransfer.files
      if (files.length !== 1) {
        Message.error('Only support uploading one file!')
        return
      }
      const rawFile = files[0] // only use files[0]

      if (!isExcel(rawFile)) {
        Message.error('Only supports upload .xlsx, .xls, .csv suffix files')
        return false
      }
      upload(rawFile)
      e.stopPropagation()
      e.preventDefault()
    }
    function handleDragover(e) {
      e.stopPropagation()
      e.preventDefault()
      e.dataTransfer.dropEffect = 'copy'
    }
    function handleUpload() {
      unref(excelUploadInput).click()
    }
    function handleClick(e) {
      const files = e.target.files
      const rawFile = files[0] // only use files[0]
      if (!rawFile) return
      upload(rawFile)
    }
    function upload(rawFile) {
      unref(excelUploadInput).value = null // fix can't select the same excel
      fileName.value = rawFile.name
      if (!beforeUpload) {
        generateData(rawFile)
        return
      }
      const before = beforeUpload(rawFile)
      if (before) {
        generateData(rawFile)
      }
    }

    function isExcel(file) {
      return /\.(xlsx|xls|csv)$/.test(file.name)
    }

    return {
      fileName,
      loading,
      excelUploadInput,
      handleDrop,
      handleClick,
      handleUpload,
      handleDragover
    }
  }
})
</script>

<style scoped lang="less">
.uploadExcel {
  display: flex;
  align-items: center;
  .el-button {
    margin-left: 10px;
  }
}

.excel-upload-input {
  display: none;
  z-index: -9999;
}
.drop {
  border: 2px dashed #bbb;
  width: 100%;
  height: 40px;
  line-height: 40px;
  margin: 0 auto;
  font-size: 16px;
  border-radius: 5px;
  text-align: center;
  color: #bbb;
  position: relative;
  padding: 0 10px;
}
.importBtn {
  color: #3c8beb;
  font-size: 16px;
  cursor: pointer;
}
</style>
