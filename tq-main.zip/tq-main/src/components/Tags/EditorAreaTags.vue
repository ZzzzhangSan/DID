<template>
  <div class="EditorAreaTags" @paste="handlerAreaPasteEvent" @dblclick="handlerDbClick">
    <div class="tags-container" v-show="!isEditorState">
      <el-tag :key="tag" type="info" v-for="tag in dynamicTags" closable :disable-transitions="false" @close="handleClose(tag)">
        {{ tag }}
      </el-tag>
      <el-input
        class="input-new-tag"
        v-if="inputVisible"
        v-model="inputValue"
        ref="saveTagInput"
        size="small"
        @keyup.enter.native="handleInputConfirm"
        @blur="handleInputConfirm"
      ></el-input>
      <el-button class="button-new-tag" v-else size="small" @click="showInput">+ 新建标签</el-button>
    </div>
    <div class="editors-container" v-show="isEditorState">
      <el-input type="textarea" autosize v-model="areaTags"></el-input>
      <el-button class="button-new-tag" size="small" @click="handlerEditorOk">+ 确定</el-button>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, PropType, toRefs, computed, watch, unref, nextTick } from '@vue/composition-api'
import { isString } from '@/utils/is'
import { Message } from 'element-ui'
/**
 * 可编辑Tags组件
 * 支持手动编辑,复制粘贴
 */
export default defineComponent({
  name: 'EditorAreaTags',
  props: {
    options: {
      type: Array as PropType<any>,
      default() {
        return []
      }
    }
  },
  setup(props) {
    const { options } = toRefs(props)
    const dynamicTags: any = ref([])
    const areaTags: any = ref('')
    const tagsSetComputed = computed(() => {
      return new Set(dynamicTags.value)
    })

    watch(options, (newval, oldval) => {
      if (newval && newval.length) {
        dynamicTags.value = newval
        areaTags.value = newval.join(',')
      }
    })

    // 是否编辑状态
    const isEditorState = ref(false)

    const inputVisible = ref(false)
    const inputValue = ref('')
    const saveTagInput: any = ref(null)
    const areaRef = ref(null)
    const splitSymbol = ','

    const handleClose = tag => {
      dynamicTags.value.splice(dynamicTags.value.indexOf(tag), 1)
    }

    const showInput = () => {
      inputVisible.value = true
      nextTick(() => {
        saveTagInput.value.$refs.input.focus()
      })
    }

    const handleInputConfirm = () => {
      const ivalue = unref(inputValue)
      if (ivalue && !unref(tagsSetComputed).has(ivalue)) {
        dynamicTags.value.push(ivalue)
      }
      inputVisible.value = false
      inputValue.value = ''
    }

    const validateTags = val => {
      const sourceTargs = val
        .replace(/\s*/g, '')
        .split(splitSymbol)
        .filter(item => item != '')
      const notArr = new Set()
      const targetTags: any = []
      sourceTargs.forEach(element => {
        if (!unref(tagsSetComputed).has(element)) {
          unref(tagsSetComputed).add(element)
          targetTags.push(element)
        } else {
          notArr.add(element)
        }
      })
      if (notArr.size > 0) {
        Message.warning(`存在重复数据${[...notArr]}`)
      }
      return targetTags
    }

    const setTags = val => {
      const targetTags: any = validateTags(val)
      if (targetTags && targetTags.length) {
        dynamicTags.value = dynamicTags.value.concat([...targetTags])
      }
    }
    // 动态获取剪切板内容
    const getClipboardContents = async () => {
      try {
        // 获取解析 粘贴的文本
        const text = await navigator.clipboard.readText()
        // const clipboardData: any = event.clipboardData || window.clipboardData
        if (isString(text) && text.indexOf(',') > 0) {
          setTags(text)
        } else {
          const noti = {
            title: '提示',
            message: '请粘贴正确格式的内容,以逗号分隔的文本串!例如张三,李四,王五'
          }
          Message.warning(noti)
        }
      } catch (error) {
        console.log(error)
      }
    }

    const handlerAreaPasteEvent = (e: any) => {
      e.stopPropagation()
      e.preventDefault()
      getClipboardContents()
    }

    // 区域双击
    const handlerDbClick = (e: any) => {
      e.stopPropagation()
      e.preventDefault()
      areaTags.value = dynamicTags.value.join(',')
      isEditorState.value = true
    }
    // 编辑确认
    const handlerEditorOk = (e: any) => {
      isEditorState.value = false

      const sourceTargs = areaTags.value
        .replace(/\s*/g, '')
        .split(splitSymbol)
        .filter(item => item != '')
      dynamicTags.value = [...sourceTargs]
    }

    onMounted(() => {})

    return {
      areaRef,
      areaTags,
      inputVisible,
      inputValue,
      dynamicTags,
      saveTagInput,
      handleClose,
      showInput,
      isEditorState,
      handlerDbClick,
      handlerEditorOk,
      handleInputConfirm,
      handlerAreaPasteEvent
    }
  }
})
</script>

<style lang="less" scoped>
.EditorAreaTags {
  width: 100%;
  height: 300px;
  padding: 5px;
  .el-tag + .el-tag {
    margin-left: 10px;
    margin-bottom: 5px;
  }
  .button-new-tag {
    margin-left: 10px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
  }
}
</style>
