<template>
  <div id="DetailTab" :class="DetailTab.detailTab">
    <div
      v-for="(item, index) in list"
      :key="item.value"
      :class="[
        DetailTab.detailTabItem,
        index == curIndex ? DetailTab.itemCurrent : '',
        option.verTabStyle == '1' && index == curIndex ? DetailTab.itemSkewClass : '',
        option.verTabStyle == '1' && index !== curIndex ? DetailTab.itemSkewClassTwo : ''
      ]"
      @click="clickHandler(item, index)"
    >
      <span>
        {{ item.name }}
        <!-- <em>{{ item.value }}</em> -->
      </span>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
@Component
export default class Tab extends Vue {
  @Prop() private option

  private list: any = []
  private curIndex: any = -1
  private value: any = ''
  toggleClick() {
    this.$emit('toggle-click')
  }
  loadData(data: any) {
    if (data && data.length) {
      this.list = []
      data.forEach((it: any) => {
        this.list.push({ name: it.name, value: it.value })
      })
    }
  }
  clickHandler(item: any, index: any) {
    this.curIndex = index
    this.value = item.value
    this.$emit('clickHandler', item)
  }
  getValue() {
    return this.value
  }
  mounted() {
    this.value = this.option.value || ''
    this.option.data.forEach((it: any, index: any) => {
      if (it.value === this.value) {
        this.curIndex = index
      }
    })
    this.loadData(this.option.data)
  }
  @Watch('option')
  optionChange(newVal: any) {
    this.value = newVal.value || ''
    newVal.data.forEach((it, index) => {
      if (it.value === this.value) {
        this.curIndex = index
      }
    })
    this.loadData(newVal.data)
  }
  @Watch('option.data')
  optionDataChange(arr: any) {
    if (arr && arr.length) {
      arr.forEach((it: any, index: any) => {
        if (it.value === this.value) {
          this.curIndex = index
        }
      })
      this.loadData(arr)
    }
  }
}
</script>
<style module="DetailTab">
.detailTab {
  position: relative;
  font-size: 14px;
  /* height: 30px; */
}
.detailTabItem {
  display: inline-block;
  background: #fff;
  height: 24px;
  line-height: 24px;
  position: relative;
  margin: 0 5px 5px 0;
  padding: 0 20px;
  color: #3c8beb;
  cursor: pointer;
  flex-grow: 1;
  border: 1px solid #3c8beb;
}
.detailTabItem em {
  color: #3c8beb;
  font-style: normal;
}
.detailTabItem i {
  font-style: normal;
}
.itemCurrent {
  background: rgba(60, 139, 235, 1);
  color: #ffffff;
  opacity: 0.8;
}
.itemCurrent em {
  color: #ffffff;
}
.detailTabItem span {
  display: inline-block;
  transform: skew(25deg);
}
.itemSkewClass {
  transform: skew(-25deg);
}
.itemSkewClass:first-child {
  margin-left: 8px;
}
.itemSkewClass:first-child::before {
  content: '';
  width: 100%;
  height: 24px;
  position: absolute;
  z-index: -1;
  top: -1px;
  left: -9%;
  transform: skew(25deg);
  background: #3c8beb;
  color: #ffffff;
}
.itemSkewClass:last-child {
  margin-right: 8px;
}
.itemSkewClass:last-child::after {
  content: '';
  width: 100%;
  height: 24px;
  position: absolute;
  z-index: -1;
  top: -1px;
  right: -9%;
  transform: skew(25deg);
  background: #3c8beb;
  color: #ffffff;
}
.itemSkewClassTwo {
  transform: skew(-25deg);
  box-shadow: none;
}
.itemSkewClassTwo:first-child {
  margin-left: 8px;
  border-left: none;
}
.itemSkewClassTwo:first-child::before {
  content: '';
  width: 100%;
  height: 24px;
  position: absolute;
  z-index: -1;
  top: -1px;
  left: -9%;
  transform: skew(25deg);
  /* // background: #fff; */
  border: 1px solid #3c8beb;
  border-right: none;
}
.itemSkewClassTwo:last-child {
  margin-right: 8px;
}
.itemSkewClassTwo:last-child::after {
  content: '';
  width: 100%;
  height: 24px;
  position: absolute;
  z-index: -1;
  top: -1px;
  right: -9%;
  transform: skew(25deg);
  background: #fff;
  border: 1px solid #3c8beb;
  border-left: none;
}
</style>
