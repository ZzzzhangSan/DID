<template>
  <div class="DetailTitle">
    <div class="title" v-if="title">
      <span class="titleIcon" />
      {{ title }}
    </div>
    <div class="container">
      <slot />
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, computed } from '@vue/composition-api'
export default defineComponent({
  name: 'DetailTitle',
  components: {},
  props: {
    title: String
  },
  setup() {
    onMounted(() => {})
    return {}
  }
})
</script>
<style lang="less" scope>
.DetailTitle {
  width: 100%;
  height: 100%;
  padding: 7px 15px;
  font-weight: bold;
  color: #011e3c;
}
.title {
  font-size: 16px;
  height: 45px;
  line-height: 45px;
  border-bottom: 1px dashed #011e3c;
}
.titleIcon {
  display: inline-block;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: #151515;
  float: left;
  margin-right: 5px;
  margin-top: 18px;
}
.container {
  height: calc(100% - 60px);
}
</style>
