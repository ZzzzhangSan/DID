<!--
 * @description border通用组件
 * @author fuping
 * @since 2020/03/19
 * @Props  {type: string} 图标：  default/small/detail详情/line折线图/bar柱图/pie饼图/scatter散点图/relation关系图/heat热力图/map地图/table表格/info列表
 -->
<template>
  <div class="borderContainer" :style="bgStyle()">
    <div v-if="type" :class="['title', type === 'detail' ? 'detail' : '']" :style="titleStyle()">
      <div class="wrap">
        <span v-if="type" :class="['icon', imgStyle()]"></span>
        <span>{{ title }}</span>
        <template>
          <span v-if="type === 'default'" class="line"></span>
          <span v-if="type === 'default'" class="iconRight"></span>
        </template>
      </div>
    </div>
    <div :class="title != '' ? 'content' : 'noTitle'">
      <slot></slot>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator'
@Component({})
export default class BorderCon extends Vue {
  @Prop() private title!: string
  @Prop() private type!: string
  @Prop() private bgColor!: string
  @Prop() private titleColor!: string
  private border: any
  /**
   * 计算属性定义
   */
  imgStyle() {
    const name = `i${this.type}`
    return this.border[name]
  }
  /**
   * 背景色
   */
  bgStyle() {
    return {
      background: this.bgColor
    }
  }
  titleStyle() {
    return {
      color: this.titleColor
    }
  }
  mounted() {}
}
</script>

<style lang="less">
.borderContainer {
  position: relative;
  width: 100%;
  height: 100%;
  background: #fff;
  box-shadow: 0px 0px 10px 1px rgba(167, 167, 167, 0.3);
  padding: 20px;
  box-sizing: border-box;
  border-radius: 5px;

  .title {
    // font-family: Trend;
    color: #333333;
    padding-bottom: 7px;
    margin-bottom: 3px;
    text-align: left;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
  }
  .detail {
    border-bottom: 2px solid #ffa200;
  }
  .detail:after {
    content: '';
    position: absolute;
    bottom: -14px;
    left: -1px;
    width: 15px;
    height: 15px;
    /* background: url('~@/assets/images/online/detailTitle.png') no-repeat center; */
  }
  .icon {
    display: inline-block;
    width: 15px;
    height: 14px;
    margin-right: 5px;
  }
  .wrap {
    display: flex;
    align-items: center;
    width: 100%;
  }
  .line {
    flex: auto;
    height: 1px;
    margin-left: 10px;
    margin-right: 3px;
    /* background: url('~@/assets/images/border/line.png') repeat center; */
  }
  .iconRight {
    width: 40px;
    height: 5px;
    /* background: url('~@/assets/images/border/icon2.png') no-repeat center; */
  }
  .idefault {
    /* background: url('~@/assets/images/border/icon1.png') no-repeat center; */
  }
  .ichart {
    /* background: url('~@/assets/images/Home/borderTitle.png') no-repeat center; */
  }
  /* .iline {
  background: url('~@/assets/images/border/title_line.png') no-repeat center;
}
.ibar {
  background: url('~@/assets/images/border/title_bar.png') no-repeat center;
}
.iheat {
  background: url('~@/assets/images/border/title_heat.png') no-repeat center;
}
.iinfo {
  background: url('~@/assets/images/border/title_info.png') no-repeat center;
}
.iinfo2 {
  background: url('~@/assets/images/border/title_info2.png') no-repeat center;
}
.imap {
  background: url('~@/assets/images/border/title_map.png') no-repeat center;
}
.ipie {
  background: url('~@/assets/images/border/title_pie.png') no-repeat center;
}
.irelation {
  background: url('~@/assets/images/border/title_relation.png') no-repeat center;
}
.iscatter {
  background: url('~@/assets/images/border/title_scatter.png') no-repeat center;
}
.itable {
  background: url('~@/assets/images/border/title_table.png') no-repeat center;
} */
  .content {
    height: 100%;
  }
  .noTitle {
    height: calc(100% - 30px);
  }
}
</style>
