<template>
  <div class="totalBox">
    <div class="totalBox__item" v-for="(item, index) in totalNumRef" v-bind:key="index">
      <div class="totalBox__item-image">
        <el-image :src="item.image" style="width: 100%;height: 100%;"></el-image>
      </div>
      <div class="totalBox__item-content">
        <div class="totalBox__item-number"><Numbers :number="item.value" size="28"></Numbers></div>
        <div class="totalBox__item-text">{{ item.name }}</div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, PropType, watch, toRefs } from '@vue/composition-api'
import Numbers from '@/components/Common/number/index.vue'
/**
 * 顶部信息统计 常用与汇总界面 上面统计信息
 * 布局如下----
 * ----------------------------------------
 * --图标1 -- 数字1   | --图标2 -- 数字2  | ....
 * ---------- 名称1  | ---------- 名称2  | ...
 * ----------------------------------------
 */
export default defineComponent({
  name: 'TopInfoStats',
  props: {
    data: {
      type: Object as PropType<Indexable>,
      default() {
        return {}
      }
    },
    // 键值 中英文映射
    /**
      { 
        officialAccount: '公众号',
        miniProgram: '小程序',
        app: 'APP',
        website: '网站备案信息',
        api: 'API',
        iot: '智慧城市物联网',
        activeNum: '活跃数据运营者'
        }
     */
    totalRef: {
      type: Object as PropType<Indexable>,
      default() {
        return {}
      }
    },
    // 图标路径
    imagePath: {
      type: String,
      default() {
        return ''
      }
    }
  },
  components: {
    Numbers
  },
  setup(props) {
    const { data } = toRefs(props)
    const totalRef = props.totalRef
    const imagePath = props.imagePath
    const totalNumRef = ref([])
    const getImageSrc = (key: string) => {
      return require(`@/assets/images${imagePath}/${key}.png`)
    }

    watch(data, (newval, oldval) => {
      build(newval)
    })
    function build(d: object) {
      const arr: any = []
      for (const key in totalRef) {
        arr.push({ name: totalRef[key], value: d[key], image: getImageSrc(key) })
      }
      totalNumRef.value = arr
    }
    return {
      totalNumRef
    }
  }
})
</script>

<style lang="less" scoped>
.totalBox {
  display: flex;
  flex-flow: row wrap;
  justify-content: space-between;
  min-width: 1000px;
}
.totalBox__item {
  position: relative;
  flex: 0 0 calc(20% - 28px);
  flex: 1;
  padding: 20px 10px;
  margin-right: 4px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.totalBox__item:after {
  content: '';
  position: absolute;
  top: 50%;
  right: -1px;
  width: 2px;
  height: 70%;
  background: url('~@/assets/images/border/line3.png') no-repeat center;
  background-size: cover;
  transform: translateY(-50%);
}
.totalBox__item:last-child:after {
  background: transparent;
}
.totalBox__item-image {
  width: 68px;
  height: 60px;
}
.totalBox__item-content {
  max-width: 55%;
  height: 100%;
  margin-left: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.totalBox__item-number {
  font-size: 28px;
  color: #383874;
  font-family: Trend;
}
.totalBox__item-text {
  font-size: 14px;
  color: #515a6e;
}
</style>
