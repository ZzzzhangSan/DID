export interface ITabTables {
  getTableColumns: object
  getTableSortOption: object
  getTableHttp: object
}

export interface IBaseTables {
  columns: Object[]
  data: Object[]
}
