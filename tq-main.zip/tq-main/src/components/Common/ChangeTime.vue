<template>
  <div class="ChangeTime">
    <div class="tabBox">
      <div
        :class="['tabItem', currentItem === item.value ? 'active' : '']"
        v-for="item in itemOpts"
        :key="item.value"
        @click="handleChangeTabs(item)"
      >
        {{ item.name }}
      </div>
    </div>
    <el-date-picker
      v-show="currentItem == 'day'"
      v-model="defaultTime"
      type="daterange"
      range-separator="至"
      :picker-options="pickerDay"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      value-format="yyyy-MM-dd HH:mm:ss"
      :default-time="defaultTime"
      :append-to-body="false"
      @change="handleChangeDate"
    ></el-date-picker>
    <el-date-picker
      v-show="currentItem == 'month'"
      v-model="defaultTime"
      type="month"
      placeholder="选择月"
      @change="handleChangeDate"
    ></el-date-picker>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import dayjs from 'dayjs'
export default defineComponent({
  name: 'ChangeTime',
  components: {},
  setup(props, { emit }) {
    const currentItem: any = ref('day')
    const returnValue: any = ref({})
    const itemOpts: any = [
      { name: '按天', value: 'day' },
      { name: '按月', value: 'month' }
    ]
    const defaultTime: any = ref([
      dayjs()
        .add(-7, 'day')
        .format('YYYY-MM-DD HH:mm:00'),
      dayjs().format('YYYY-MM-DD HH:mm:00')
    ])

    const returnParams: any = ref({
      timeType: 'day',
      startTime: defaultTime.value[0],
      endTime: defaultTime.value[1]
    })

    //const defaultTime: any = ref('')

    const pickerDay: any = {
      shortcuts: [
        {
          text: '最近一天',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', [start, end])
          }
        },
        {
          text: '最近三天',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 3)
            picker.$emit('pick', [start, end])
          }
        },
        {
          text: '最近一个月',
          onClick(picker) {
            const end = new Date()
            const start = new Date()
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
            picker.$emit('pick', [start, end])
          }
        }
      ]
    }

    function handleChangeTabs(item) {
      currentItem.value = item.value
    }
    function handleChangeDate(val) {
      let time: any = ''
      console.log(val)
      if (currentItem.value === 'month') {
        const d = dayjs(val).format('YYYYMM')
        time = {
          startTime: d,
          endTime: d
        }
      } else {
        const s = dayjs(val[0]).format('YYYYMMDD')
        const e = dayjs(val[1]).format('YYYYMMDD')
        time = {
          startTime: s,
          endTime: e
        }
      }
      const param = {
        timeType: currentItem.value,
        startTime: time.startTime,
        endTime: time.endTime
      }
      emit('handleChangeTime', param)
    }
    onMounted(() => {})

    const getValue = () => {
      return returnParams.value
    }
    return {
      currentItem,
      itemOpts,
      getValue,
      defaultTime,
      pickerDay,
      handleChangeTabs,
      handleChangeDate
    }
  }
})
</script>
<style lang="less" scoped>
.ChangeTime {
  display: flex;
  .tabBox {
    height: 32px;
    background: #ffffff;
    margin-bottom: 0;
    display: flex;
    font-size: 14px;
    width: 150px;
    margin-right: 20px;
    border: 1px solid #6654f9;
    border-radius: 4px;
    .tabItem {
      flex: 1;
      align-items: center;
      justify-content: center;
      color: #6654f9;
      cursor: pointer;
      text-align: center;
      line-height: 30px;
    }
    .active {
      color: #fff;
      background: #6654f9;
      // position: absolute;
    }
  }
}
</style>
<style>
.ChangeTime .iconfont {
  font-size: 20px;
}
.ChangeTime .el-date-editor .el-range__icon {
  line-height: 30px;
  margin-top: -5px;
}
.ChangeTime .el-date-editor .el-range-separator {
  margin-top: -5px;
}
.ChangeTime .el-date-editor .el-range-input {
  color: rgb(96 98 102 / 65%);
}
</style>
