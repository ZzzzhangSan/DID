<template>
  <div class="list-box">
    <BaseTable ref="tableInstanceRef" :option="tableOpt" height="100%" @rowClick="rowClickHandler" />
  </div>
</template>

<script lang="ts">
import { computed, defineComponent, PropType, watch, toRefs, reactive } from '@vue/composition-api'
import BaseTable from './BaseTable.vue'
import { IBaseTables } from './types'
export default defineComponent({
  components: {
    BaseTable
  },
  props: {
    data: {
      type: Array as PropType<Recordable[]>,
      default() {
        return []
      }
    },
    columns: {
      type: Array as PropType<Recordable[]>,
      default() {
        return []
      }
    },
    height: String
  },
  name: 'common_homeTable',
  setup(props, { emit }) {
    const { data, columns } = toRefs(props)
    const tableOpt: IBaseTables = reactive({ columns, data: [] })
    watch(data, (newval, oldval) => {
      if (newval && newval.length) {
        initTable(newval)
      }
    })

    const rowClickHandler = (row: any) => {
      emit('rowClick', row)
    }

    function initTable(d) {
      tableOpt.data = d
    }
    return {
      tableOpt,
      rowClickHandler
    }
  }
})
</script>

<style scoped>
.list-box {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>
