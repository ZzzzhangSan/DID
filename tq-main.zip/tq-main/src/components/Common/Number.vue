<template>
  <div class="numberCom" :style="colorStyle">
    {{ changeNum }}
    <span class="unit">
      <slot>{{ unit }}</slot>
    </span>
  </div>
</template>

<script>
export default {
  data() {
    return {
      numAte: {
        scale: 0, // 动画进度
        name: {}, // 动画实例对象
        oldNum: 0,
        diff: this.renderData
      },
      changeNum: []
    }
  },
  props: {
    time: {
      type: Number,
      default: 2
    },
    renderData: null,
    color: String,
    size: String,
    unit: String
  },
  computed: {
    colorStyle() {
      return {
        color: this.color,
        fontSize: this.size + 'px'
      }
    }
  },
  mounted() {
    this.numberAnimates()
  },
  watch: {
    renderData(newVal, oldVal) {
      this.numberAnimates()
    }
  },
  methods: {
    numberAnimates() {
      this.changeNum = Number(this.renderData).toFixed('2')
    }
  }
}
</script>

<style lang="less" scoped>
.numberCom {
  letter-spacing: 2px;
  font-size: 22px;
  font-weight: bold;
  color: #3d3d3d;
  height: 50px;
  line-height: 50px;
  display: flex;
  align-items: flex-end;
  .unit {
    font-size: 10px;
    font-weight: 500;
    margin-left: 5px;
    line-height: 44px;
  }
}
</style>
