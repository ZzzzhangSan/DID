<template>
  <VTable :option="tableOption" :height="height" ref="tableInstance"></VTable>
</template>
<script lang="ts">
import { defineComponent, PropType, watch, ref, toRefs } from '@vue/composition-api'
import { IBaseTables } from './types'
/**
 * 动态基础table 不带请求 不带分页 直接传数据
 */
export default defineComponent({
  name: 'Common_BaseTable',
  props: {
    option: {
      type: Object as PropType<IBaseTables>,
      default() {
        return {}
      }
    },
    height: String
  },
  setup(props, { emit }) {
    const { columns, data } = toRefs(props.option)
    const rowClickHandler = (row: any) => {
      emit('rowClick', row)
    }
    const tableOption: any = ref({
      stripe: true,
      selection: false,
      selectionPos: 'top',
      defaultSort: [],
      sortChange: undefined,
      // sigle 独立排序， multi 多项排序
      sortMode: 'single',
      column: columns,
      data: [],
      // 是否分页
      pagination: false,
      rowClick: rowClickHandler
    })
    watch(data, (newval, oldval) => {
      tableOption.value.data = newval
    })

    return {
      tableOption
    }
  }
})
</script>
