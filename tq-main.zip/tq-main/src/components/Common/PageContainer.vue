<template>
  <div :id="containerId" class="page-container">
    <div class="search-form" ref="formBox" :style="formStyleComputed">
      <el-collapse-transition>
        <BorderBox v-show="formVisible">
          <slot name="form" :formVisible="formVisible" class="transition-box"></slot>
        </BorderBox>
      </el-collapse-transition>
    </div>
    <div class="search-list" :style="tableStyleComputed">
      <span class="btnArrow" @click="setFormHeight">
        {{ isFormOpen ? '收起' : '展开' }}
        <i :class="[isFormOpen ? 'el-icon-d-arrow-up' : 'el-icon-d-arrow-down']"></i>
      </span>
      <BorderBox>
        <slot name="table" :tableHeight="tableHeight"></slot>
      </BorderBox>
    </div>
    <el-dialog title="详情" width="80%" :visible.sync="dialogVisible" :id="DetailRef" top="2%">
      <slot name="detail"></slot>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        <el-button type="reset" @click="dialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref } from '@vue/composition-api'
export default defineComponent({
  props: {
    // 容器id
    containerId: String
  },
  setup(props) {
    const DetailRef = ref(`${props.containerId}-Detail`)
    const dialogVisible = ref(false)
    const isFormOpen = ref(false)
    const formVisible = ref(false)

    const setFormHeight = () => {
      isFormOpen.value = !isFormOpen.value
      formVisible.value = isFormOpen.value ? true : false
    }
    return {
      isFormOpen,
      DetailRef,
      dialogVisible,
      formVisible,
      setFormHeight
    }
  }
})
</script>
<style lang="less" scoped>
.page-container {
  width: 100%;
  height: 100%;
  min-width: 900px;
}

.search-form {
  position: relative;
  margin-bottom: 15px;
  overflow: hidden;
}
.search-list {
  position: relative;
}
</style>
