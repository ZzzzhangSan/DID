<template>
  <span class="btnArrow" @click="setFormHeight">
    {{ isFormOpen ? '收起' : '展开' }}
    <i :class="[isFormOpen ? 'el-icon-d-arrow-up' : 'el-icon-d-arrow-down']"></i>
  </span>
</template>
<script lang="ts">
import { defineComponent, ref } from '@vue/composition-api'
export default defineComponent({
  setup(props, { emit }) {
    const isFormOpen = ref(false)
    const setFormHeight = () => {
      isFormOpen.value = !isFormOpen.value
      emit('isShow', { name: 'formVisible', value: isFormOpen.value ? true : false })
    }
    return {
      isFormOpen,
      setFormHeight
    }
  }
})
</script>
<style lang="less" scoped></style>
