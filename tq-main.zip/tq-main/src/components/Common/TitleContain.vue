<template>
  <div class="TitleContain">
    <div class="title" v-if="title">
      <!-- <span class="titleIcon" /> -->
      {{ title }}
    </div>
    <div class="container">
      <slot />
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, computed } from '@vue/composition-api'
export default defineComponent({
  name: 'TitleContain',
  components: {},
  props: {
    title: String
  },
  setup() {
    onMounted(() => {})
    return {}
  }
})
</script>
<style lang="less" scope>
.TitleContain {
  width: 100%;
  height: 100%;
  padding: 7px 15px;
  background: #fff;
  border-radius: 5px;
  box-shadow: 0px 0px 10px 1px rgba(167, 167, 167, 0.3);
  position: relative;
  .title {
    font-size: 16px;
    height: 40px;
    line-height: 40px;
    color: #3d3d3d;
    display: flex;
    align-items: center;
    font-weight: bold;
  }
  .titleIcon {
    display: inline-block;
    width: 6px;
    height: 14px;
    background: #6654f9;
    border-radius: 33px;
    margin-right: 8px;
    margin-top: 2px;
  }
  .container {
    height: calc(100% - 40px);
  }
}
</style>
