<template>
  <dv-scroll-board :config="config" :style="{ width: '100%', height: height + 'px' }" />
</template>

<script lang="ts">
import { defineComponent, PropType, reactive, ref, toRefs, watch } from '@vue/composition-api'
export default defineComponent({
  props: {
    data: {
      type: Array as PropType<Recordable[]>,
      default() {
        return []
      }
    },
    height: {
      type: String as PropType<string>,
      default: '100%'
    }
  },
  setup(props) {
    const { data } = toRefs(props)
    const header = ['企业名称', '发现时间']
    let config = reactive({
      header,
      data: []
    })

    watch(data, (newval, oldval) => {
      if (newval && newval.length) {
        init(newval)
      }
    })

    function init(d) {
      // 列键值
      const columnsKey = Object.keys(d[0])
      const okeys = {}
      columnsKey.forEach(item => {
        okeys[item] = ''
      })
      const sourceArr: any = d.map((item: any) => {
        const p: any = []
        for (const key in okeys) {
          p.push(item[key])
        }
        return p
      })
      config = {
        data: sourceArr,
        header: header
      }
      console.log(config)
    }

    return {
      config
    }
  }
})
</script>

<style lang="less" scoped>
.warp {
  width: 100%;
  margin: 0 auto;
  overflow: hidden;
  & ul {
    list-style: none;
    padding: 0;
    margin: 0 auto;
    & li,
    a {
      display: block;
      height: 30px;
      line-height: 30px;
      display: flex;
      justify-content: space-between;
      font-size: 14px;
    }
  }
}
</style>
