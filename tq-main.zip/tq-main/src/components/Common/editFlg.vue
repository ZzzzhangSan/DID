<template>
  <div class="editFlgBox">
    <div class="first">
      <div
        v-for="item in editFirstOpt"
        :key="item.id"
        :class="['editItem', currentFirst === item.id ? 'currentItem' : '']"
        @click="handlerFirstClick(item)"
      >
        <span>{{ item.name ? item.name : item.label }}</span>
        <i class="el-icon-arrow-right"></i>
      </div>
    </div>
    <div class="second">
      <el-checkbox-group v-model="currentSecond" @change="handlerCheckChange">
        <el-checkbox v-for="item in editSecondOpt" :key="item.id" :label="item.id">{{ item.name ? item.name : item.label }}</el-checkbox>
      </el-checkbox-group>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref, watch } from '@vue/composition-api'
import { Loading, MessageBox, Message } from 'element-ui'

export default defineComponent({
  name: 'editFlg',
  components: {},
  props: ['option'],
  setup(props, { emit }) {
    // 父级标签
    const editFirstOpt: any = ref([])
    // 二级标签
    const editSecondOpt: any = ref([])
    // 修改标签 弹窗 三级标签选中项目
    const currentSecond = ref([])
    // 目前选中的一级标签
    const currentFirst: any = ref(null)

    // 获取的标签类型，包含的参数为illegal，normal，默认值为illegal
    const type: any = ref(props.option.type)
    watch(
      () => props.option,
      (newval, oldval) => {
        currentFirst.value = newval.currentFirst
        currentSecond.value = newval.currentSecond
        type.value = newval.type
      },
      { deep: true, immediate: true }
    )
    watch(
      () => props.option.type,
      (newval, oldval) => {
        editSecondOpt.value = []
        currentSecond.value = []
      },
      { deep: true, immediate: true }
    )

    function handlerCheckChange() {
      emit('editFlgHandlerChange', {
        currentFirst: currentFirst.value,
        currentSecond: currentSecond.value
      })
    }
    onMounted(() => {})

    return {
      editFirstOpt,
      editSecondOpt,
      currentSecond,
      currentFirst,
      handlerCheckChange
    }
  }
})
</script>

<style lang="less" scope>
.editFlgBox {
  line-height: 32px;
  display: flex;
  padding: 0 30px;

  .editItem {
    cursor: pointer;
  }
  .first,
  .second {
    width: 120px;
  }
  .currentItem {
    color: #3c8beb;
  }
}
</style>
