<template>
  <div :class="miniHeader.main">
    <div :class="miniHeader.title" v-if="title != ''">
      <span :class="miniHeader.icon"></span>
      {{ title }}
    </div>
    <div :class="[title != '' ? miniHeader.content : miniHeader.noTitle]">
      <slot></slot>
      <img v-if="showLine === ''" :src="require('../../assets/images/border/line2.png')" :class="miniHeader.line" />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from '@vue/composition-api'
export default defineComponent({
  name: 'common_miniHeader',
  props: {
    // 容器id
    title: String,
    showLine: String
  },
  setup(props) {
    return {}
  }
})
</script>

<style module="miniHeader">
.main {
  position: relative;
  width: 100%;
  height: 100%;
  background: #fff;
  box-sizing: border-box;
  box-shadow: none;
  font-size: 15px;
}
.title {
  /* font-family: Trend; */
  color: #333333;
  padding-bottom: 7px;
  margin-bottom: 5px;
  text-align: left;
  display: flex;
  align-items: center;
  position: relative;
}
.icon {
  display: inline-block;
  width: 15px;
  height: 14px;
  margin-right: 5px;
  background: url('~@/assets/images/border/icon3.png') no-repeat center;
}

.content {
  position: relative;
  height: calc(100% - 24px);
}
.noTitle {
  position: relative;
  height: 100%;
}
.line1:after {
  content: '';
  position: absolute;
  top: 0px;
  right: -1px;
  width: 2px;
  height: 100%;
  background: url('~@/assets/images/border/line1.png') no-repeat center;
  background-size: cover;
}
.line {
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
}
</style>
