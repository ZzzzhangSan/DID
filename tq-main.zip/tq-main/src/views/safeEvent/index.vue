<template>
  <div class="safeEventContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="eventForm">
          <el-form-item label="局点">
            <el-select v-model="eventForm.entrance" multiple collapse-tags>
              <el-option v-for="item in potOpt" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="配置详情">
            <el-input v-model="eventForm.pz"></el-input>
          </el-form-item>
          <el-form-item label="时间">
            <el-date-picker
              v-model="eventForm.time"
              type="datetimerange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              align="right"
            ></el-date-picker>
          </el-form-item>
        </el-form>

        <div class="btns">
          <el-button type="primary" @click="loadAPI">查询</el-button>
          <el-button class="buttonReset" @click="resetForm">重置</el-button>
        </div>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <el-table :data="tableData" stripe style="width: 100%" height="calc(100% - 40px)" @cell-click="handlerCellClick">
          <el-table-column prop="number" label="序号" width="50"></el-table-column>
          <el-table-column prop="eventId" label="安全事件"></el-table-column>
          <el-table-column prop="entrance" label="局点"></el-table-column>
          <el-table-column prop="summary" label="事件总述" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div class="jumpText">
                {{ scope.row.summary }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="desc" label="事件详情">
            <template slot-scope="scope">
              <div class="jumpText">
                详情>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="startTime" label="开始时间"></el-table-column>
          <el-table-column prop="endTime" label="结束时间"></el-table-column>
          <el-table-column prop="remark" label="备注">
            <template slot-scope="scope">
              <div class="jumpText">
                {{ scope.row.remark }}
              </div>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          background
          layout="total, prev, pager, sizes,next"
          prev-text="上一页"
          next-text="下一页"
          :total="pageOption.total"
          :current-page="pageOption.page"
          :page-size="pageOption.size"
          @size-change="handleSizeChange"
          @current-change="handlerCurrentChange"
        ></el-pagination>
      </BorderBox>
    </div>
    <el-dialog title="备注信息" :visible.sync="dialogRemarkVisible" width="30%" class="remarkDialog">
      <div>
        <el-input type="textarea" :rows="4" placeholder="请输入内容" v-model="remark" :disabled="isEditDisable" ref="remarkRef"></el-input>
        <div class="linkText">
          <el-link icon="el-icon-edit" :underline="false" class="edit" @click="setEditStatus">编辑</el-link>
          <el-link icon="el-icon-delete" :underline="false" class="clear" @click="clearRemark">清空</el-link>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="remarkSubmit">保存</el-button>
        <el-button class="buttonCancel" @click="dialogRemarkVisible = false">返回</el-button>
      </span>
    </el-dialog>
    <el-dialog title="详情" :visible.sync="dialogDetailVisible" width="50%" class="detailDialog">
      <div>
        <el-collapse v-model="activeName" accordion>
          <el-collapse-item :title="item.entrance" :name="item.entrance" v-for="(item, index) in detailList" :key="index">
            <div class="infoBox">
              <div class="detailItem">
                <div class="title">PZ类型：</div>
                <div class="content">{{ item.pzType }}</div>
              </div>
              <div class="detailItem">
                <div class="title">对应配置：</div>
                <div class="content">{{ item.pzInfo }}</div>
              </div>
              <div class="detailItem">
                <div class="title">源IP：</div>
                <div class="content">
                  {{ item.srcDesc }}
                </div>
              </div>
              <div class="detailItem">
                <div class="title">目的IP：</div>
                <div class="content">
                  {{ item.dstDesc }}
                </div>
              </div>
            </div>
          </el-collapse-item>
        </el-collapse>
      </div>
    </el-dialog>
    <el-dialog title="事件总述" :visible.sync="dialogSummaryVisible" width="30%" class="summaryDialog">
      <div class="infoBox">
        <div class="detailItem" v-for="(item, index) in summaryArray" :key="index">
          <div class="title">{{ item.split(':')[0] }}：</div>
          <div class="content">{{ item.split(':')[1] }}</div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="goAbnormal">查看事件对应数据</el-button>
        <el-button class="buttonCancel" @click="dialogSummaryVisible = false">返回</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import { entranceSelect } from '@/api/common'
import { safeEventList, safeEventDetail, safeEventEdit } from '@/api/safeEvent'
import { Loading, MessageBox, Message } from 'element-ui'
import router from '@/router/index'
export default defineComponent({
  name: 'safeEvent',
  components: { BorderBox },
  setup() {
    // 表单form
    const eventForm: any = ref({
      entrance: [], // 局点
      pz: '',
      time: '' // 时间段
    })
    // 局点下拉
    const potOpt: any = ref([])
    const topBoxRef: any = ref(null)
    const remarkRef: any = ref(null)
    //备注
    const remark: any = ref(null)
    const currentInfo: any = ref({})
    // 备注是否可编辑，默认不可编辑， 点击编辑后可以编辑
    const isEditDisable: any = ref(true)
    const activeName: any = ref('')
    const summaryArray: any = ref([])
    // 表格数据
    const tableData: any = ref([{ type: 'aaa', desc: '44', pot: 'dfd', time: '2023-09-28' }])
    // 分页参数
    const pageOption: any = ref({
      total: 0, // 总页数
      page: 1, // 当前页
      size: 10
    })
    // 备注弹框
    const dialogRemarkVisible: any = ref(false)
    const dialogDetailVisible: any = ref(false)
    const dialogSummaryVisible: any = ref(false)
    const detailList: any = ref([])
    // 翻页事件
    function handlerCurrentChange(val) {
      pageOption.value.page = val
      loadAPI()
    }
    function handleSizeChange(val) {
      pageOption.value.size = val
      loadAPI()
    }
    // 单元格点击事件
    function handlerCellClick(row, column) {
      // console.log(row, column)
      currentInfo.value = row
      summaryArray.value = row.summary.split(',')
      if (column.label === '备注') {
        remark.value = row.remark
        dialogRemarkVisible.value = true
      } else if (column.label === '事件详情') {
        dialogDetailVisible.value = true
        getSafeEventDetail()
      } else if (column.label === '事件总述') {
        dialogSummaryVisible.value = true
      }
    }
    // 备注弹窗编辑事件
    function setEditStatus() {
      isEditDisable.value = false
    }
    function clearRemark() {
      remark.value = ''
    }
    // 重置
    function resetForm() {
      eventForm.value = {
        entrance: '',
        info: '',
        time: ''
      }
    }
    // 查询
    function loadAPI() {
      const params = {
        page: pageOption.value.page,
        size: pageOption.value.size,
        entrance: eventForm.value.entrance,
        pz: eventForm.value.pz,
        startTime: eventForm.value.time ? eventForm.value.time[0] : '',
        endTime: eventForm.value.time ? eventForm.value.time[1] : ''
      }
      //console.log(params)
      safeEventList(params).then((resp: any) => {
        pageOption.value.total = resp.total
        tableData.value = resp.items
      })
    }
    //详情
    function getSafeEventDetail() {
      safeEventDetail(currentInfo.value.eventId).then((resp: any) => {
        detailList.value = resp
        activeName.value = resp.length > 0 ? resp[0].entrance : ''
      })
    }
    // 局点下拉
    function getEntranceSelect() {
      entranceSelect().then(resp => {
        potOpt.value = resp
      })
    }

    // 备注提交
    function remarkSubmit() {
      const params = {
        eventId: currentInfo.value.eventId,
        pzType: remark.value
      }
      safeEventEdit(params).then((resp: any) => {
        if (resp.code === 200) {
          Message({
            type: 'success',
            message: '添加备注成功!'
          })
          dialogRemarkVisible.value = false
        }
      })
    }
    // 跳转异常流量关联
    function goAbnormal() {
      router.push({ name: '异常流量关联', params: currentInfo.value })
    }
    onMounted(() => {
      getEntranceSelect()
      loadAPI()
    })
    return {
      eventForm,
      topBoxRef,
      tableData,
      pageOption,
      dialogRemarkVisible,
      dialogDetailVisible,
      dialogSummaryVisible,
      remark,
      isEditDisable,
      setEditStatus,
      remarkRef,
      clearRemark,
      activeName,
      potOpt,
      detailList,
      summaryArray,
      handlerCurrentChange,
      handleSizeChange,
      handlerCellClick,
      resetForm,
      loadAPI,
      remarkSubmit,
      goAbnormal
    }
  }
})
</script>
<style lang="less">
.safeEventContainer {
  width: 100%;
  height: 100%;
  .topBox {
    width: 100%;
    margin-bottom: 10px;
    .btns {
      text-align: right;
      margin-top: 16px;
    }
    .el-form {
      display: flex;
      justify-content: space-between;
    }
    .el-form--inline .el-form-item:last-child {
      margin-right: 0;
    }
  }
  .bottomBox {
    width: 100%;
    height: calc(100% - 146px);
    .el-table {
      height: calc(100% - 40px);
      .jumpText {
        color: #2093ff;
        text-decoration: underline;
        cursor: pointer;
      }
    }
  }
  .remarkDialog {
    .linkText {
      line-height: 40px;
      .edit {
        padding-right: 10px;
        color: #1082eb;
      }
      .clear {
        color: #f00;
      }
    }
  }
  .detailDialog {
    .infoBox {
      padding: 0 20px;
      .detailItem {
        display: flex;
        line-height: 36px;
        .title {
          width: 90px;
          font-weight: bold;
          flex-shrink: 0;
        }
        .content {
          flex-grow: 1;
        }
      }
    }
  }
  .summaryDialog {
    .infoBox {
      padding: 0 20px;
      .detailItem {
        display: flex;
        line-height: 36px;
        .title {
          width: 90px;
          font-weight: bold;
          flex-shrink: 0;
        }
        .content {
          flex-grow: 1;
        }
      }
    }
  }
  .el-collapse-item__header {
    padding-left: 10px;
    background-color: transparent;
  }
  .el-collapse-item__wrap {
    background-color: transparent;
  }
  .el-collapse-item__header.is-active {
    background-color: #d2def6;
  }
  .el-collapse {
    border: 1px solid #d3d4dd;
    border-radius: 4px;
  }
}
</style>
