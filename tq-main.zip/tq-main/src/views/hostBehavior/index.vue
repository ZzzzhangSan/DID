<template>
  <div class="hostBehaviorContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" ref="abnormalHostForm" :model="abnormalHostForm">
          <el-form-item prop="entrance" label="局点:">
            <el-input v-model="abnormalHostForm.entrance" placeholder="请输入关键字"
              style="width: 200px;margin-right: 20px;"></el-input>
          </el-form-item>
          <el-form-item prop="ip" label="主机IP:">
            <el-input v-model="abnormalHostForm.ip" placeholder="请输入关键字"
              style="width: 200px;margin-right: 20px;"></el-input>
          </el-form-item>
          <el-form-item label="检测时间" prop="metric_time">
            <el-date-picker v-model="abnormalHostForm.metric_time" type="datetime" format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss" placement="bottom-start" class="input-time" placeholder="请选择时间">
            </el-date-picker>
          </el-form-item>
          <div style="display: inline-block;float: right;  ">
            <el-button type="primary" @click="searchForm">查询</el-button>
            <el-button type="info" @click="resetForm">重置</el-button>
          </div>
        </el-form>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <el-table :data="tableData" style="width: 100%" ref="hostTable"
          :header-cell-style="{ background: '#DAE8FC', color: '#101010', padding: '0px' }"
          :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }" :header-row-style="{ height: '38px' }"
          class="filetbale">
          <el-table-column label="序号" min-width="2%" align="center" prop="number">
            <template slot-scope="scope">
              {{ scope.$index + (pageOption.page - 1) * pageOption.size + 1 }}
            </template>
          </el-table-column>
          <el-table-column prop="id" label="主机id" min-width="3%" align="center" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="entrance" label="局点" min-width="6%" align="center" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="ip" label="主机IP" min-width="4%" align="center" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="cpu_avg_rate" label="CPU占用率" min-width="5%" align="center" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.cpu_avg_rate.match(/\d+/)[0] > 12 }">{{
                scope.row.cpu_avg_rate }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="memory_rate" label="内存占用率" min-width="5%" align="center" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.memory_rate.match(/\d+/)[0] > 12 }">{{
                scope.row.memory_rate }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="disk_iops_total" label="IOPS" min-width="3%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.disk_iops_total.match(/\d+/)[0] > 12 }">{{
                scope.row.disk_iops_total }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="disk_read_total" label="磁盘读取字节数" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.disk_read_total.match(/\d+/)[0] > 12 }">{{
                scope.row.disk_read_total }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="disk_write_total" label="磁盘写入字节数" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.disk_write_total.match(/\d+/)[0] > 12 }">{{
                scope.row.disk_write_total }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="net_receive_flow" label="网络接收字节数" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.net_receive_flow.match(/\d+/)[0] > 12 }">{{
                scope.row.net_receive_flow }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="net_transfer_flow" label="网络转发字节数" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.net_transfer_flow.match(/\d+/)[0] > 12 }">{{
                scope.row.net_transfer_flow }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="connect_ip_nums" label="通信IP数量" min-width="5%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.connect_ip_nums > 12 }">{{ scope.row.connect_ip_nums }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="abnormal_ip_nums" label="异常通信IP数量" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.abnormal_ip_nums > 12 }">{{ scope.row.abnormal_ip_nums }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="external_ip_nums" label="外网通信IP数量" min-width="6%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.external_ip_nums > 12 }">{{ scope.row.external_ip_nums }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="dpdk_drive_flow" label="dpdk驱动捕获流量" min-width="7%" align="center"
            :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div :class="{ 'red-cell': scope.row.dpdk_drive_flow.match(/\d+/)[0] > 12 }">{{ scope.row.dpdk_drive_flow }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="insert_time" label="检测时间" min-width="5%" align="center" style="">
          </el-table-column>
          <el-table-column prop="operate" label="操作" min-width="4%" align="center" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <el-button type="text" size="small" style="color: #3286FF;"
                @click="detailsShow(scope.row.entrance, scope.row.ip, scope.row.insert_time)">详情</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination background layout="total, prev, pager, sizes,next" prev-text="上一页" next-text="下一页"
          :total="pageOption.total" :current-page="pageOption.page" :page-size="pageOption.size"
          @size-change="handleSizeChange" @current-change="handlerCurrentChange"></el-pagination>
      </BorderBox>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import LineChart from '@/components/ChartsCom/LineChart.vue'
import { hostQueryList } from '@/api/hostBehavior'
export default defineComponent({
  name: 'hostBehavior',
  components: { BorderBox, LineChart },
  setup() {
    // 表单form
    const abnormalHostForm: any = ref({
      entrance: '', // 局点
      ip: '',//主机IP
      metric_time: '' // 时间
    })
    // 表格数据
    const tableData: any = ref([])
    // 分页参数
    const pageOption: any = ref({
      total: 10, // 总数
      page: 1, // 当前页
      size: 10
    })
    // 翻页事件
    function handlerCurrentChange(val) {
      // console.log(val)
      pageOption.value.page = val
      searchForm()
    }
    function handleSizeChange(val) {
      pageOption.value.size = val
      searchForm()
    }
    //查询客户端
    function searchForm() {
      // 列表初始
      const params = {
        entrance: abnormalHostForm.value.entrance,
        ip: abnormalHostForm.value.ip,
        metric_time: abnormalHostForm.value.metric_time,
        page: pageOption.value.page,
        size: pageOption.value.size,
      }
      hostQueryList(params).then((resp: any) => {
        pageOption.value.total = resp.content.total
        tableData.value = resp.content.data
      })
    }
    //清空
    function resetForm() {
      abnormalHostForm.value = {
        entrance: '',
        ip: '',
        metric_time: ''
      }
    }
    onMounted(() => {
      searchForm()
    })

    return {
      abnormalHostForm,
      resetForm,
      searchForm,
      handleSizeChange,
      handlerCurrentChange,
      tableData,
      pageOption
    }
  }
})
</script>
<style lang="less">
.hostBehaviorContainer {
  width: 100%;
  height: 100%;

  .topBox {
    margin-bottom: 10px;
    height: 90px;
  }

  .bottomBox {
    height: calc(100% - 90px);
  }
}

.main {
  padding: 20px;
}

.search {
  width: 97%;

  margin: 0 auto;


}

.shadow-div {

  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;

}

.hosttable {
  padding: 20px 10px 20px 10px;
}

.block {
  padding-bottom: 20px;
  /* padding-top: 20px; */
}

/* 表格边距 */
.el-table th.el-table__cell>.cell {
  padding-left: 0px;
  padding-right: 0px;
}

.el-table .cell {
  padding: 0px;
}

.el-button--info {
  color: black;
  background-color: white;
  border-color: #BBBBBB;
}

.el-table td.el-table__cell div {
  font-size: 12px !important;
  ;
}

/* 单元格根据值变色 */

.red-cell {
  background-color: #f8cecc;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.cellstyle {
  background-color: red
}
</style>
