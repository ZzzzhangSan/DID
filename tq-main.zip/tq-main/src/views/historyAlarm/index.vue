<template>
  <div class="historyAlarmContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="historyForm">
          <el-form-item label="告警类型">
            <el-select v-model="historyForm.type">
              <el-option v-for="(item, index) in typeOpt" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="局点">
            <el-select v-model="historyForm.entrance">
              <el-option v-for="(item, index) in potOpt" :key="index" :label="item" :value="item"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="时间">
            <el-date-picker v-model="historyForm.time" type="datetimerange" range-separator="-" start-placeholder="开始日期"
              end-placeholder="结束日期" value-format="yyyy-MM-dd HH:mm:ss" align="right"></el-date-picker>
          </el-form-item>
        </el-form>
        <div class="btns">
          <el-button type="primary" @click="loadAPI">查询</el-button>
          <el-button class="buttonReset" @click="resetForm">重置</el-button>
        </div>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <el-table :data="tableData" stripe style="width: 100%" height="calc(100% - 40px)" @cell-click="handlerCellClick">
          <el-table-column prop="number" label="序号" width="50"></el-table-column>
          <el-table-column prop="typeName" label="告警类型" width="130"></el-table-column>
          <el-table-column prop="description" label="告警描述" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div class="jumpText">
                {{ scope.row.description }}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="entrance" label="局点" width="150"></el-table-column>
          <el-table-column prop="time" label="时间" width="330"></el-table-column>
        </el-table>
        <el-pagination background layout="total, prev, pager, sizes,next" prev-text="上一页" next-text="下一页"
          :total="pageOption.total" :current-page="pageOption.page" :page-size="pageOption.size"
          @size-change="handleSizeChange" @current-change="handlerCurrentChange"></el-pagination>
      </BorderBox>
    </div>
    <el-dialog title="告警描述" :visible.sync="dialogVisible" width="30%">
      <div>{{ description }}</div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        <el-button class="buttonCancel" @click="dialogVisible = false">返回</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import { historyAlarmList } from '@/api/historyAlarm'
import { entranceSelect } from '@/api/common'

export default defineComponent({
  name: 'historyAlarm',
  components: { BorderBox },
  setup() {
    // 表单form
    const historyForm: any = ref({
      type: '', // 告警类型
      entrance: '', // 局点
      time: '' // 时间
    })
    const potOpt: any = ref([])
    const typeOpt: any = ref(['DDOS攻击告警'])
    const topBoxRef: any = ref(null)
    // 表格数据
    const tableData: any = ref([])
    // 分页参数
    const pageOption: any = ref({
      total: 10, // 总数
      page: 1, // 当前页
      size: 10
    })
    // 告警描述信息
    const description: any = ref('')
    // 告警描述弹框
    const dialogVisible: any = ref(false)
    // 翻页事件
    function handlerCurrentChange(val) {
      // console.log(val)
      pageOption.value.page = val
      loadAPI()
    }
    function handleSizeChange(val) {
      pageOption.value.size = val
      loadAPI()
    }
    // 单元格点击事件
    function handlerCellClick(row, column) {
      console.log(row, column)
      if (column.label === '告警描述') {
        dialogVisible.value = true
        description.value = row.description
      }
    }

    // 重置
    function resetForm() {
      historyForm.value = {
        type: '',
        origin: '',
        time: ''
      }
    }
    // 查询
    function loadAPI() {
      const params = {
        page: pageOption.value.page,
        size: pageOption.value.size,
        entrance: historyForm.value.entrance,
        type: historyForm.value.type,
        startTime: historyForm.value.time ? historyForm.value.time[0] : '',
        endTime: historyForm.value.time ? historyForm.value.time[1] : ''
      }
      //console.log(params)
      historyAlarmList(params).then((resp: any) => {
        pageOption.value.total = resp.total
        tableData.value = resp.items
      })
    }

    // 局点下拉
    function getEntranceSelect() {
      entranceSelect().then((resp: any) => {
        potOpt.value = resp
      })
    }
    onMounted(() => {
      getEntranceSelect()
      loadAPI()
    })
    return {
      historyForm,
      topBoxRef,
      tableData,
      pageOption,
      dialogVisible,
      description,
      potOpt,
      typeOpt,
      handlerCurrentChange,
      handleSizeChange,
      handlerCellClick,
      resetForm,
      loadAPI
    }
  }
})
</script>
<style lang="less">
.historyAlarmContainer {
  width: 100%;
  height: 100%;

  .topBox {
    margin-bottom: 10px;

    .btns {
      text-align: right;
      margin-top: 16px;
    }

    .el-form {
      display: flex;
      justify-content: space-between;
    }

    .el-form--inline .el-form-item:last-child {
      margin-right: 0;
    }
  }

  .bottomBox {
    height: calc(100% - 146px);

    .el-table {
      height: calc(100% - 40px);

      .jumpText {
        color: #2093ff;
        text-decoration: underline;
        cursor: pointer;
      }
    }
  }
}
</style>
