<template>
  <div class="abnormalContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="abnormalForm">
          <el-form-item label="时间">
            <el-date-picker
              v-model="abnormalForm.time"
              type="datetimerange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              align="right"
            ></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="loadFdTotalList()">查询</el-button>
            <el-button class="buttonReset" @click="resetForm">重置</el-button>
          </el-form-item>
        </el-form>
      </BorderBox>
    </div>
    <div class="middleBox">
      <TitleContain title="局点封堵流量">
        <LineChart :data="lineOriginData" :option="lineOriginOpt"></LineChart>
      </TitleContain>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <div class="juPot">
          局点：
          <el-select v-model="orginPot" placeholder="请选择" multiple collapse-tags>
            <el-option v-for="item in potOpt" :key="item" :label="item" :value="item"></el-option>
          </el-select>
          &nbsp;&nbsp;
          <el-button type="primary" @click="loadFdEntranceList">查询</el-button>
        </div>
        <div class="topChart">
          <div class="leftChart">
            <div class="ctitle">局点封堵流量</div>
            <div class="chartBox">
              <LineChart :data="linePluggingData" :option="linePluggingOpt" @click="topLeftclickHandler"></LineChart>
            </div>
          </div>
          <div class="splitLine"></div>
          <div class="rightChart">
            <div class="ctitle">流量协议成分</div>
            <div class="chartBox">
              <LineChart :data="lineTypeData" :option="lineTypeOpt" @click="topRightclickHandler"></LineChart>
            </div>
          </div>
        </div>
        <div class="bottomChart">
          <div class="leftChart">
            <div class="ctitle">流量TOP详情</div>
            <div class="topSelect">
              TOP:
              <el-select v-model="topValue" multiple collapse-tags style="margin-left: 20px;" placeholder="请选择" @change="handleTopChange">
                <el-option v-for="item in topOpt" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </div>
            <div class="chartBox">
              <LineChart :data="linePzData" :option="linePzOpt" @click="bottomLeftclickHandler"></LineChart>
            </div>
          </div>
          <div class="splitLine"></div>
          <div class="rightChart">
            <div class="ctitle">配置详情</div>
            <div class="chartBox">
              <el-table :data="tableData" stripe style="width: 100%">
                <el-table-column prop="time" label="时间"></el-table-column>
                <el-table-column prop="pz" label="配置"></el-table-column>
                <el-table-column prop="value" label="值"></el-table-column>
              </el-table>
            </div>
          </div>
        </div>
      </BorderBox>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import LineChart from '@/components/ChartsCom/LineChart.vue'
import TitleContain from '@/components/Common/TitleContain.vue'
import { fdTotalList, fdEntranceList, fdEntranceTypeList, fdEntranceDetailList, fdEntrancePzList } from '@/api/abnormal'
import { entranceSelect, topSelect } from '@/api/common'
import { Loading, MessageBox, Message } from 'element-ui'
export default defineComponent({
  name: 'abnormal',
  components: { BorderBox, LineChart, TitleContain },
  setup(props, context) {
    const root: any = context.root
    const route: any = root._route
    const routerQuery: any = route.params
    // 表单form
    const abnormalForm: any = ref({
      time: ''
    })
    const currentClickVal: any = ref({
      entrance: '',
      type: '',
      topNum: ''
    })
    const topBoxRef: any = ref(null)
    // 局点
    const orginPot: any = ref([])
    const potOpt: any = ref([])
    const topValue: any = ref([])
    const topOpt: any = ref([])
    //配置详情数据
    const tableData: any = ref([])
    // 原始流量折线图数据
    const lineOriginData = ref([
      // { name: '0:00', value: 11, category: 'A' },
      // { name: '1:00', value: 82, category: 'A' },
      // { name: '2:00', value: 105, category: 'A' },
      // { name: '3:00', value: 26, category: 'A' },
      // { name: '4:00', value: 11, category: 'A' },
      // { name: '5:00', value: 26, category: 'A' },
      // { name: '6:00', value: 44, category: 'A' },
      // { name: '7:00', value: 15, category: 'A' },
      // { name: '0:00', value: 33, category: 'B' },
      // { name: '1:00', value: 99, category: 'B' },
      // { name: '2:00', value: 45, category: 'B' },
      // { name: '3:00', value: 26, category: 'B' },
      // { name: '4:00', value: 49, category: 'B' },
      // { name: '5:00', value: 26, category: 'B' },
      // { name: '6:00', value: 44, category: 'B' },
      // { name: '7:00', value: 15, category: 'B' },
      // { name: '0:00', value: 53, category: 'C' },
      // { name: '1:00', value: 19, category: 'C' },
      // { name: '2:00', value: 35, category: 'C' },
      // { name: '3:00', value: 16, category: 'C' },
      // { name: '4:00', value: 79, category: 'C' },
      // { name: '5:00', value: 16, category: 'C' },
      // { name: '6:00', value: 24, category: 'C' },
      // { name: '7:00', value: 15, category: 'C' }
    ])
    const lineOriginOpt: any = ref({
      smooth: true,
      colors: ['#00B2FF', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      },
      dataZoom: true
    })
    // 封堵流量折线图数据
    const linePluggingData = ref([])
    const linePluggingOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      },
      dataZoom: true,
      lengend: true
    })
    const lineTypeData: any = ref([])
    const lineTypeOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      },
      dataZoom: true,
      lengend: true
    })
    const linePzData: any = ref([])
    const linePzOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      },
      dataZoom: true
    })

    // 加载最上方封堵流量折线图
    function loadFdTotalList() {
      // console.log(abnormalForm.value.time)
      if (abnormalForm.value.time === '') {
        Message({
          type: 'warning',
          message: '请选择时间段!'
        })
      } else {
        const params = {
          startTime: abnormalForm.value.time ? abnormalForm.value.time[0] : '',
          endTime: abnormalForm.value.time ? abnormalForm.value.time[1] : ''
        }
        //console.log(params)
        fdTotalList(params).then((resp: any) => {
          lineOriginData.value = resp
        })
      }
    }

    // 加载下方 局点封堵流量
    function loadFdEntranceList() {
      const params = {
        startTime: abnormalForm.value.time ? abnormalForm.value.time[0] : '',
        endTime: abnormalForm.value.time ? abnormalForm.value.time[1] : '',
        entrance: orginPot.value
      }
      //console.log(params)
      fdEntranceList(params).then((resp: any) => {
        linePluggingData.value = resp
      })
    }
    // 加载下方流量协议成分
    function loadFdEntranceTypeList(val) {
      const params = {
        startTime: abnormalForm.value.time ? abnormalForm.value.time[0] : '',
        endTime: abnormalForm.value.time ? abnormalForm.value.time[1] : '',
        entrance: val
        // type: val //非必须， 不需要
      }
      fdEntranceTypeList(params).then((resp: any) => {
        lineTypeData.value = resp
      })
    }
    // 加载下方流量Top详情
    function loadFdEntranceDetailList() {
      const params = {
        startTime: abnormalForm.value.time ? abnormalForm.value.time[0] : '',
        endTime: abnormalForm.value.time ? abnormalForm.value.time[1] : '',
        entrance: currentClickVal.value.entrance,
        type: currentClickVal.value.type,
        topNum: topValue.value //非必须， 不需要
      }
      fdEntranceDetailList(params).then((resp: any) => {
        linePzData.value = resp
      })
    }
    // 加载下方配置详情
    function loadFdEntrancePzList(val) {
      const params = {
        startTime: abnormalForm.value.time ? abnormalForm.value.time[0] : '',
        endTime: abnormalForm.value.time ? abnormalForm.value.time[1] : '',
        entrance: currentClickVal.value.entrance,
        type: currentClickVal.value.type,
        topNum: val //非必须， 不需要
      }
      fdEntrancePzList(params).then((resp: any) => {
        tableData.value = resp
      })
    }
    function getEntranceSelect() {
      entranceSelect().then(resp => {
        potOpt.value = resp
      })
    }
    function getTopSelect() {
      topSelect().then(resp => {
        topOpt.value = resp
      })
    }
    //左侧上方图表点击事件
    function topLeftclickHandler(val) {
      // console.log(val)
      currentClickVal.value.entrance = val.seriesName
      loadFdEntranceTypeList(val.seriesName)
    }
    //右侧上方图表点击事件
    function topRightclickHandler(val) {
      currentClickVal.value.type = val.seriesName
      loadFdEntranceDetailList()
    }
    //左侧下方图表点击事件
    function bottomLeftclickHandler(val) {
      //console.log(val)
      loadFdEntrancePzList(val.seriesName)
    }
    function handleTopChange(val) {
      loadFdEntranceDetailList()
    }
    function resetForm() {
      abnormalForm.value.time = ''
    }

    onMounted(() => {
      if (routerQuery.eventId) {
        abnormalForm.value.time = [routerQuery.startTime, routerQuery.endTime]
        orginPot.value = routerQuery.entrance.split(',')
        loadFdTotalList()
        loadFdEntranceList()
      }
      getEntranceSelect()
      getTopSelect()
    })
    return {
      abnormalForm,
      topBoxRef,
      lineOriginData,
      lineOriginOpt,
      linePluggingData,
      linePluggingOpt,
      lineTypeData,
      lineTypeOpt,
      linePzData,
      linePzOpt,
      orginPot,
      potOpt,
      topValue,
      topOpt,
      tableData,
      topLeftclickHandler,
      topRightclickHandler,
      bottomLeftclickHandler,
      loadFdTotalList,
      loadFdEntranceList,
      handleTopChange,
      resetForm
    }
  }
})
</script>
<style lang="less">
.abnormalContainer {
  width: 100%;
  height: 100%;
  .topBox {
    margin-bottom: 10px;
    .el-form {
      display: flex;
      justify-content: space-between;
    }
    .el-form--inline .el-form-item:last-child {
      margin-right: 0;
    }
  }
  .middleBox {
    height: 400px;
    margin-bottom: 10px;
  }
  .bottomBox {
    height: 900px;
    .topChart,
    .bottomChart {
      width: 100%;
      height: 400px;
      display: flex;
      margin-top: 20px;
      align-items: center;

      .leftChart {
        width: 50%;
        height: 100%;
        position: relative;
      }
      .rightChart {
        width: 50%;
        height: 100%;
        .chartBox {
          padding: 10px 10px 10px 20px;
        }
      }
      .splitLine {
        width: 1px;
        height: 340px;
        margin-left: 20px;
        background: #cecece;
      }
      .chartBox {
        width: 100%;
        height: calc(100% - 36px);
      }
      .topSelect {
        position: absolute;
        right: 20px;
        top: 8px;
        .el-select .el-input .el-input__inner {
          background: #f0f5ff;
          border: none;
          height: 32px;
          line-height: 32px;
          width: 150px;
        }
        .el-input__icon {
          line-height: 32px;
        }
      }
    }
    .ctitle {
      padding-left: 16px;
      padding-top: 16px;
    }
  }
}
</style>
