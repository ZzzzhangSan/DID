<template>
  <div class="realAlarmContainer">
    <div class="topBox">
      <TitleContain title="DDOS攻击告警">
        <ddosComp></ddosComp>
      </TitleContain>
    </div>
    <div class="middleBox">
      <TitleContain title="边界渗透告警">
        <infliComp></infliComp>
      </TitleContain>
    </div>
    <div class="botBox">
      <TitleContain title="主机异常行为告警">
        <abnormalHostComp></abnormalHostComp>
      </TitleContain>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent } from '@vue/composition-api'
import TitleContain from '@/components/Common/TitleContain.vue'
import ddosComp from './ddos.vue'
import infliComp from './infiltration.vue'
import abnormalHostComp from './abnormalHost.vue'
export default defineComponent({
  name: 'realAlarm',
  components: { TitleContain, ddosComp, infliComp, abnormalHostComp },
  setup() { }
})
</script>
<style lang="less">
.realAlarmContainer {
  width: 100%;
  height: 100%;

  .topBox,
  .middleBox,
  .botBox {
    width: 100%;
    height: 50%;
    margin-bottom: 20px;
  }

  .TitleContain {
    .container {
      overflow: auto;
    }
  }
}
</style>
