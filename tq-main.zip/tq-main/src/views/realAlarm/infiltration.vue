<template>
    <div class="infiltrationContainer" ref="infil">
      <ul class="infillist" v-if="infilData.length > 0">
        <li v-for="(item, index) in infilData" :key="index">
          <span class="content" :title="item.description">
            {{ item.description }}
          </span>
          <span class="time">{{ item.time }}</span>
        </li>
      </ul>
      <div class="noData" v-else>暂无边界渗透告警数据</div>
    </div>
  </template>
  <script lang="ts">
  import { defineComponent, onMounted, ref } from '@vue/composition-api'
  import TitleContain from '@/components/Common/TitleContain.vue'
  import { realAlarmCurrentList } from '@/api/realAlarm'
  import { Loading, MessageBox, Message } from 'element-ui'
  export default defineComponent({
    name: 'realAlarm',
    components: { TitleContain },
    setup() {
      const infil: any = ref(null)
      // 边界渗透数据
      const infilData: any = ref({})
      // 过境流量占比
      function getRealAlarmInfilList() {
        const loadingInstance = Loading.service({
          target: infil.value,
          spinner: 'el-loading-custormspinner',
          text: '数据加载中...',
          background: 'rgba(255,255,255,.6)'
        })
        realAlarmCurrentList()
          .then((res: any) => {
            infilData.value = res
            loadingInstance.close()
          })
          .catch(() => {
            loadingInstance.close()
          })
      }
      onMounted(() => {
        getRealAlarmInfilList()
      })
      return {
        infil,
        infilData
      }
    }
  })
  </script>
  <style lang="less">
  .infiltrationContainer {
    width: 100%;
    height: 100%;
    .noData {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .infillist {
      width: 100%;
      height: 100%;
      overflow: auto;
      li {
        display: flex;
        justify-content: space-between;
        background: #f3f6ff;
        height: 36px;
        line-height: 36px;
        align-items: center;
        padding: 0 10px;
        margin-bottom: 10px;
        .content {
          color: #333;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
        }
        .time {
          color: #999;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }
    }
  }
  </style>
  