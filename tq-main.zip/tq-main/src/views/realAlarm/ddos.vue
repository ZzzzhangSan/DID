<template>
  <div class="ddosContainer">
    <ul class="Doslist">
      <li v-for="(item, index) in DDosData" :key="index">
        <span class="content" :title="item.description">
          {{ item.description }}
        </span>
        <span class="time">{{ item.time }}</span>
      </li>
    </ul>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import TitleContain from '@/components/Common/TitleContain.vue'
import { realAlarmDdosList } from '@/api/realAlarm'
export default defineComponent({
  name: 'realAlarm',
  components: { TitleContain },
  setup() {
    // ddos数据
    const DDosData: any = ref({})
    // 过境流量占比
    function getRealAlarmDdosList() {
      realAlarmDdosList()
        .then((res: any) => {
          DDosData.value = res
        })
        .catch(() => {})
    }
    onMounted(() => {
      getRealAlarmDdosList()
    })
    return {
      DDosData
    }
  }
})
</script>
<style lang="less">
.ddosContainer {
  width: 100%;
  height: 100%;
  .Doslist {
    width: 100%;
    height: 100%;
    overflow: auto;
    li {
      display: flex;
      justify-content: space-between;
      background: #f3f6ff;
      height: 36px;
      line-height: 36px;
      align-items: center;
      padding: 0 10px;
      margin-bottom: 10px;
      .content {
        color: #333;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
      }
      .time {
        color: #999;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
  }
}
</style>
