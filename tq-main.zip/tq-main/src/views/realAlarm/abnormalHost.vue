<template>
  <div class="abnormalhostContainer">
    <ul class="abhostlist">
      <li v-for="(item, index) in AbnormalHostData" :key="index">
        <span class="content" :title="item.description">{{ item.type }}:{{ item.msg }}</span>
        <span class="time">{{ item.time }}</span>
      </li>
    </ul>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import TitleContain from '@/components/Common/TitleContain.vue'
import { realAlarmAbnormalHostList } from '@/api/realAlarm'
export default defineComponent({
  name: 'realAlarm',
  components: { TitleContain },
  setup() {
    // ddos数据
    const AbnormalHostData: any = ref({})
    // 过境流量占比
    function getrealAlarmAbnormalHostList() {
      realAlarmAbnormalHostList()
        .then((res: any) => {
          AbnormalHostData.value = res.content.alerts
        })
        .catch(() => { })
    }
    onMounted(() => {
      getrealAlarmAbnormalHostList()
    })
    return {
      AbnormalHostData
    }
  }
})
</script>
<style lang="less">
.abnormalhostContainer {
  width: 100%;
  height: 100%;

  .abhostlist {
    width: 100%;
    height: 100%;
    overflow: auto;

    li {
      display: flex;
      justify-content: space-between;
      background: #f3f6ff;
      height: 36px;
      line-height: 36px;
      align-items: center;
      padding: 0 10px;
      margin-bottom: 10px;

      .content {
        color: #333;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;

        .warningtype {
          color: red;
        }
      }

      .time {
        color: #999;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
  }
}
</style>
