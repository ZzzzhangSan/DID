<template>
  <el-empty :description="desc">
    <el-button type="primary" @click="btnClck">返回</el-button>
  </el-empty>
</template>

<script lang="ts">
import { defineComponent, getCurrentInstance } from '@vue/composition-api'
export default defineComponent({
  setup() {
    const instance = getCurrentInstance()?.proxy as any
    const btnClck = () => {
      instance.$router.back()
    }
    return {
      desc: '暂时访问不了当前模块',
      btnClck
    }
  }
})
</script>

<style lang="less" scoped></style>
