<template>
  <div class="loginWrap">
    <div class="loginBox">
      <!-- <div class="leftBox">
        <img :src="require('@/assets/images/login/leftbg.png')" alt="" />
      </div> -->
      <div class="rightBox">
        <div class="formInput">
          <div class="title">
            <span>{{ VUE_APP_TITLE }}</span>
          </div>
          <ol>
            <li>
              <input
                class="userBox"
                placeholder="请输入用户名"
                v-model="loginForm.userName"
                type="text"
                name="user"
                @keyup.enter="loginKeyup"
                @focus="handlerFocus(0)"
                @blur="handlerBlur($event)"
              />
            </li>
            <li>
              <input
                class="pwdBox"
                placeholder="请输入密码"
                v-model="loginForm.userPassword"
                type="password"
                name="pwd"
                @keyup.enter="loginKeyup"
                @focus="handlerFocus(1)"
                @blur="handlerBlur($event)"
              />
            </li>
            <li class="btn">
              <button @click="login">登录</button>
            </li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Vue, Ref } from 'vue-property-decorator'
import { Action } from 'vuex-class'
import { UserModule } from '@/store/modules/user'
import { http } from '@/common/request'
import { trim } from 'lodash-es'
import { SysRoleEnum } from '@/common/enum'
import dayjs from 'dayjs'
import { Message, Notification } from 'element-ui'
import { setToken } from '@/utils/cookies'
import router from '@/router/index'

@Component({})
export default class Login extends Vue {
  @Prop() private isLogin!: any
  private VUE_APP_TITLE = process.env.VUE_APP_NAME
  private randomCode = Math.floor(Math.random() * 1000000)
  private checkLoginVal = 0
  private randomCode1 = 0
  private checkCookie = true
  private isAnimate1 = false
  private isAnimate2 = false
  private loginForm = {
    userName: '',
    userPassword: ''
  }
  private vCodeUrl = ''
  @Action('user/SET_TOKEN') SET_TOKEN!: Function
  mounted() {
    if (process.env.NODE_ENV === 'development') {
      this.loginForm = {
        userName: process.env.VUE_APP_LOGIN_USERNAME || 'superadmin',
        userPassword: process.env.VUE_APP_LOGIN_PWD || 'chanct_ysp'
      }
    }
  }
  // 回车Enter按键回调方法
  loginKeyup(e: any) {
    const inputName = e.target.name
    if (inputName !== '') {
      this.login()
      return false
    }
  }
  handlerFocus(index: number) {
    switch (index) {
      case 0:
        this.isAnimate1 = true
        break
      case 1:
        this.isAnimate2 = true
        break
      default:
        break
    }
  }
  // 失去焦点事件回调方法
  handlerBlur(e: any) {
    const val = e.target.value
    const inputName = e.target.name
    switch (inputName) {
      case 'user':
        val.length > 0 ? (this.isAnimate1 = true) : (this.isAnimate1 = false)
        break
      case 'pwd':
        val.length > 0 ? (this.isAnimate2 = true) : (this.isAnimate2 = false)
        break
      default:
        break
    }
  }
  // 检查登录信息文本框是否存在空值
  checkLoginForm(username: string, password: string) {
    if (username === '') {
      this.$message('用户名不能为空')
      return false
    }
    if (password === '') {
      this.$message('密码不能为空')
      return false
    }
    if (username !== 'admin') {
      this.$message('请输入正确的用户名和密码')
      return false
    }
    if (password !== 'chanct') {
      this.$message('请输入正确的用户名和密码')
      return false
    }
    return true
  }
  // 登录操作
  login() {
    const username = this.loginForm.userName
    const password = this.loginForm.userPassword
    if (this.checkLoginForm(username, password)) {
      UserModule.UserInfoAction(username).then(re => {
        setToken('username')
        this.loginSuccess(username)
      })
    }
  }

  // 登录成功
  loginSuccess(userName) {
    Notification({
      title: '登陆成功',
      message: `欢迎${userName}登录系统`,
      type: 'success',
      duration: 500
    })
    router.push({ path: 'realAlarm' })
  }
}
</script>
<style lang="less" scope>
.loginWrap {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0px;
  left: 0px;
  z-index: 1001;
  background: url('~@/assets/images/login/bg.jpg') no-repeat;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;

  .loginBox {
    width: 600px;
    height: 480px;
    display: flex;
    justify-content: space-between;
    background: #fff;
    background-size: cover;
    box-shadow: 0px 4px 10px 1px rgba(0, 0, 0, 0.3);
    border-radius: 8px;
    position: absolute;
    right: 170px;
    .rightBox {
      width: 100%;
      display: flex;
      margin-top: 10%;
      justify-content: center;
      .title {
        font-size: 28px;
        text-align: center;
        margin-bottom: 60px;
        color: #4d4d4d;
        position: relative;
      }
      .formInput {
        width: 80%;
        .userBox {
          background: url('~@/assets/images/login/user.png') no-repeat 5px 15px;
        }
        .pwdBox {
          background: url('~@/assets/images/login/password.png') no-repeat 5px 15px;
        }
        ol {
          width: 100%;
          margin: 0;
          padding: 0;
        }

        li {
          width: 100%;
          position: relative;
          margin-top: 10px;
          p {
            font-size: 14px;
            color: #9a9a9a;
          }
        }
        @media (min-height: 700px) and (max-height: 1400px) {
          li {
            margin-bottom: 30px;
          }
        }
        @media (max-height: 700px) {
          li {
            margin-bottom: 15px;
          }
        }
        li:before {
          content: '';
          width: 16px;
          height: 16px;
          position: absolute;
          top: 16px;
          left: 10px;
        }

        .btn {
          margin: 0;
          padding: 0;
          margin-top: 60px;
          button {
            width: 100%;
            height: 48px;
            line-height: 48px;
            background: #6654f9;
            border-radius: 4px;
            color: #ffffff;
            font-size: 18px;
            letter-spacing: 12px;
            &:hover {
              cursor: pointer;
              background: #7c6df6;
              box-shadow: 0px 4px 6px 1px rgba(71, 71, 71, 0.3);
            }
            &:focus {
              background: #523dfa;
            }
          }
        }
        .btn::before {
          content: none;
        }
        input {
          width: 100%;
          height: 50px;
          line-height: 50px;
          outline: none;
          background: rgba(255, 255, 255, 0.06);
          border-radius: 2px;
          border: 1px solid #b7b7b7;
          color: #373737;
          font-size: 16px;
          border-radius: 4px;
          padding-left: 30px;
        }
        input::focus {
          border: 1px solid #6654f9;
          background: rgba(255, 255, 255, 0.05);
        }
        .verfiycode {
          display: flex;
          input {
            width: calc(100% - 140px);
          }
          > div {
            width: 140px;
            display: inline-block;
            margin-left: 4px;
            display: flex;
            img {
              width: 90px;
              height: 48px;
            }
            i {
              display: inline-block;
              width: 48px;
              height: 48px;
              font-size: 32px;
              text-align: center;
              line-height: 48px;
              background: #ededed;
              cursor: pointer;
            }
          }
        }
      }
    }
  }
}
</style>
