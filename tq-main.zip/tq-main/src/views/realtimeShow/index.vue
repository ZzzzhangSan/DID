<template>
  <div class="realtimeShowContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="realtimeForm">
          <el-form-item label="时间">
            <el-date-picker
              v-model="realtimeForm.time"
              type="datetimerange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              align="right"
            ></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="loadAPI">查询</el-button>
            <el-button class="buttonReset" @click="resetForm">重置</el-button>
          </el-form-item>
        </el-form>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <div class="lookDetail" @click="goHistory">查看详情></div>
        <div class="topChart">
          <div class="juPot">
            局点：
            <el-select v-model="orginPot" placeholder="请选择" multiple collapse-tags @change="loadData(1)">
              <el-option v-for="item in potOpt" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </div>
          <div class="chartTitle">原始流量</div>
          <LineChart :data="lineOriginData" :option="lineOriginOpt"></LineChart>
        </div>
        <div class="bottomChart">
          <div class="juPot">
            局点：
            <el-select v-model="fdPot" placeholder="请选择" multiple collapse-tags @change="loadData(2)">
              <el-option v-for="item in potOpt" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </div>
          <div class="chartTitle">封堵流量</div>
          <LineChart :data="lineFdData" :option="lineFdOpt"></LineChart>
        </div>
      </BorderBox>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import LineChart from '@/components/ChartsCom/LineChart.vue'
import router from '@/router/index'
import { entranceSelect } from '@/api/common'
import { realTimeShowOriginList, realTimeShowFdList } from '@/api/realtimeShow'
import { Loading, MessageBox, Message } from 'element-ui'
export default defineComponent({
  name: 'realtimeShow',
  components: { BorderBox, LineChart },
  setup() {
    // 表单form
    const realtimeForm: any = ref({
      time: ''
    })
    const topBoxRef: any = ref(null)
    const orginPot: any = ref('')
    const fdPot: any = ref('')
    const potOpt: any = ref([])
    // 原始流量折线图数据
    const lineOriginData: any = ref([])
    const lineOriginOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      }
    })
    // 封堵流量折线图数据
    const lineFdData: any = ref([])
    const lineFdOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      }
    })
    function goHistory() {
      router.push({ path: '/realtimeHistory', params: {} })
    }
    // 局点下拉
    function getEntranceSelect() {
      entranceSelect().then(resp => {
        potOpt.value = resp
      })
    }
    // 原始流量
    function loadRealTimeShowOriginList() {
      const params = {
        startTime: realtimeForm.value.time ? realtimeForm.value.time[0] : '',
        endTime: realtimeForm.value.time ? realtimeForm.value.time[1] : '',
        entrance: orginPot.value || []
      }
      realTimeShowOriginList(params).then(resp => {
        lineOriginData.value = resp
      })
    }
    // 封堵流量
    function loadRealTimeShowFdList() {
      const params = {
        startTime: realtimeForm.value.time ? realtimeForm.value.time[0] : '',
        endTime: realtimeForm.value.time ? realtimeForm.value.time[1] : '',
        entrance: fdPot.value || []
      }
      realTimeShowFdList(params).then(resp => {
        lineFdData.value = resp
      })
    }

    function loadAPI() {
      if (realtimeForm.value.time === '') {
        Message({
          type: 'warning',
          message: '请选择时间段!'
        })
      } else {
        loadRealTimeShowFdList()
        loadRealTimeShowOriginList()
      }
    }

    function loadData(type) {
      if (realtimeForm.value.time === '') {
        Message({
          type: 'warning',
          message: '请选择时间段!'
        })
      } else {
        if (type === 1) {
          loadRealTimeShowOriginList()
        } else {
          loadRealTimeShowFdList()
        }
      }
    }

    function resetForm() {
      realtimeForm.value.time = ''
    }
    onMounted(() => {
      getEntranceSelect()
    })
    return {
      realtimeForm,
      topBoxRef,
      lineOriginData,
      lineOriginOpt,
      lineFdData,
      lineFdOpt,
      orginPot,
      fdPot,
      potOpt,
      goHistory,
      loadAPI,
      loadData,
      resetForm
    }
  }
})
</script>
<style lang="less">
.realtimeShowContainer {
  width: 100%;
  height: 100%;
  .topBox {
    margin-bottom: 10px;
    .el-form {
      display: flex;
      justify-content: space-between;
    }
    .el-form--inline .el-form-item:last-child {
      margin-right: 0;
    }
  }
  .bottomBox {
    height: calc(100% - 90px);
    .topChart,
    .bottomChart {
      position: relative;
      width: 100%;
      height: calc((100% - 50px) / 2);
      padding: 20px 10px;
      .chartTitle {
        position: absolute;
        top: 10px;
        left: 10px;
      }
    }
    .lookDetail {
      color: #4d7cdd;
      text-align: right;
      margin-bottom: 10px;
      cursor: pointer;
    }
    .juPot {
      position: absolute;
      right: 10px;
      z-index: 999;
      top: 0px;
      .el-select .el-input .el-input__inner {
        background: #f0f5ff;
        border: none;
        height: 32px;
        line-height: 32px;
      }
      .el-input__icon {
        line-height: 32px;
      }
    }
  }
}
</style>
