<template>
  <div class="realtimeHistoryContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="historyForm" label-width="80px">
          <el-row>
            <el-col :span="7">
              <el-form-item label="数据源">
                <el-select v-model="historyForm.dataSrc" @change="handleOriginChange">
                  <el-option :label="item" :value="item" v-for="(item, index) in originOpt" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item label="流量类型">
                <el-select v-model="historyForm.flowType" :disabled="isFlowTypeDisable">
                  <el-option :label="item" :value="item" v-for="(item, index) in flowTypeOpt" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="9">
              <el-form-item label="局点">
                <el-select v-model="historyForm.entranceName" :disabled="isPotDisable">
                  <el-option :label="item" :value="item" v-for="(item, index) in potOpt" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="7">
              <el-form-item label="协议类型">
                <el-select v-model="historyForm.protocolType" :disabled="isProtocolTypeDisable">
                  <el-option :label="item" :value="item" v-for="(item, index) in protocolTypeOpt" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item label="TOP">
                <el-select v-model="historyForm.topNum" :disabled="isTopDisable">
                  <el-option :label="item" :value="item" v-for="(item, index) in topOpt" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="9">
              <el-form-item label="时间段">
                <el-date-picker
                  v-model="historyForm.time"
                  type="datetimerange"
                  range-separator="-"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  align="right"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="btns">
          <el-button type="primary" @click="loadAPI">查询</el-button>
          <el-button class="buttonReset" @click="resetForm">重置</el-button>
        </div>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <div class="chartBox">
          <LineChart :data="lineOriginData" :option="lineOriginOpt"></LineChart>
        </div>
      </BorderBox>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import LineChart from '@/components/ChartsCom/LineChart.vue'
import { entranceSelect, topSelect, originSelect, typeSelect, protocolSelect } from '@/api/common'
import { realTimeDetailList } from '@/api/realtimeShow'
import { Loading, MessageBox, Message } from 'element-ui'
export default defineComponent({
  name: 'realtimeHistory',
  components: { BorderBox, LineChart },
  setup() {
    // 表单form
    const historyForm: any = ref({
      dataSrc: '', // 数据源
      flowType: '', // 流量类型
      entranceName: '', // 局点
      protocolType: '', //协议类型
      topNum: '', // top
      time: ''
    })
    const topBoxRef: any = ref(null)
    const originOpt: any = ref([]) // 数据源
    const flowTypeOpt: any = ref([]) // 流量类型
    const potOpt: any = ref([]) //局点
    const protocolTypeOpt: any = ref([]) //协议类型
    const topOpt: any = ref([]) // top
    const isFlowTypeDisable: any = ref(false)
    const isPotDisable: any = ref(false)
    const isProtocolTypeDisable: any = ref(false)
    const isTopDisable: any = ref(false)
    const isTimeDisable: any = ref(false)
    // 原始流量折线图数据
    const lineOriginData = ref([
      // { name: '0:00', value: 11, category: 'A' },
      // { name: '1:00', value: 82, category: 'A' },
      // { name: '2:00', value: 105, category: 'A' },
      // { name: '3:00', value: 26, category: 'A' },
      // { name: '4:00', value: 11, category: 'A' },
      // { name: '5:00', value: 26, category: 'A' },
      // { name: '6:00', value: 44, category: 'A' },
      // { name: '7:00', value: 15, category: 'A' },
      // { name: '0:00', value: 33, category: 'B' },
      // { name: '1:00', value: 99, category: 'B' },
      // { name: '2:00', value: 45, category: 'B' },
      // { name: '3:00', value: 26, category: 'B' },
      // { name: '4:00', value: 49, category: 'B' },
      // { name: '5:00', value: 26, category: 'B' },
      // { name: '6:00', value: 44, category: 'B' },
      // { name: '7:00', value: 15, category: 'B' },
      // { name: '0:00', value: 53, category: 'C' },
      // { name: '1:00', value: 19, category: 'C' },
      // { name: '2:00', value: 35, category: 'C' },
      // { name: '3:00', value: 16, category: 'C' },
      // { name: '4:00', value: 79, category: 'C' },
      // { name: '5:00', value: 16, category: 'C' },
      // { name: '6:00', value: 24, category: 'C' },
      // { name: '7:00', value: 15, category: 'C' }
    ])
    const lineOriginOpt: any = ref({
      smooth: true,
      colors: ['#205BD4', 'rgba(0,178,255,0.2)', 'rgba(255,110,31,0.2)'],
      yText: '',
      splitLine: {
        xAxis: false,
        yAxis: true
      },
      axisLine: {
        color: '#666',
        xAxis: true,
        yAxis: false
      }
    })

    // 加载数据源
    function loadOriginOpt() {
      originSelect().then((resp: any) => {
        originOpt.value = resp
      })
    }
    // 加载流量类型
    function loadFlowTypeOpt() {
      typeSelect().then((resp: any) => {
        flowTypeOpt.value = resp
      })
    }
    // 加载局点
    function loadPotOpt() {
      entranceSelect().then((resp: any) => {
        potOpt.value = resp
      })
    }
    // 加载协议类型
    function loadProtocolTypeOpt() {
      protocolSelect().then((resp: any) => {
        protocolTypeOpt.value = resp
      })
    }
    // 加载TOP
    function loadTopOpt() {
      topSelect().then((resp: any) => {
        topOpt.value = resp
      })
    }
    function handleOriginChange(val) {
      if (val === '北极星') {
        isProtocolTypeDisable.value = true
        isTopDisable.value = true
        isTimeDisable.value = false
        isPotDisable.value = false
        isFlowTypeDisable.value = false
      } else if (val === '封堵探针') {
        isProtocolTypeDisable.value = false
        isTopDisable.value = false
        isTimeDisable.value = false
        isPotDisable.value = false
        isFlowTypeDisable.value = true
      }
    }
    function loadAPI() {
      if (historyForm.value.dataSrc === '') {
        Message({
          type: 'warning',
          message: '请选择数据源!'
        })
      } else if (historyForm.value.time === '') {
        Message({
          type: 'warning',
          message: '请选择时间段!'
        })
      } else {
        let params: any = {}
        if (historyForm.value.dataSrc === '北极星') {
          params = {
            dataSrc: historyForm.value.dataSrc, // 数据源
            flowType: historyForm.value.flowType, // 流量类型
            entranceName: historyForm.value.entranceName, // 局点
            startTime: historyForm.value.time ? historyForm.value.time[0] : '',
            endTime: historyForm.value.time ? historyForm.value.time[1] : ''
          }
        } else if (historyForm.value.dataSrc === '封堵探针') {
          params = {
            dataSrc: historyForm.value.dataSrc, // 数据源
            entranceName: historyForm.value.entranceName, // 局点
            protocolType: historyForm.value.protocolType, //协议类型
            topNum: historyForm.value.topNum, // top
            startTime: historyForm.value.time ? historyForm.value.time[0] : '',
            endTime: historyForm.value.time ? historyForm.value.time[1] : ''
          }
        }
        realTimeDetailList(params).then((resp: any) => {
          lineOriginData.value = resp
        })
      }
    }

    function resetForm() {
      historyForm.value = {
        origin: '', // 数据源
        flowType: '', // 流量类型
        entrance: '', // 局点
        protocolType: '', //协议类型
        top: '', // top
        time: ''
      }
      isProtocolTypeDisable.value = false
      isTopDisable.value = false
      isTimeDisable.value = false
      isPotDisable.value = false
      isFlowTypeDisable.value = false
    }
    onMounted(() => {
      loadOriginOpt()
      loadFlowTypeOpt()
      loadPotOpt()
      loadProtocolTypeOpt()
      loadTopOpt()
    })
    return {
      historyForm,
      topBoxRef,
      lineOriginData,
      lineOriginOpt,
      originOpt,
      flowTypeOpt,
      potOpt,
      protocolTypeOpt,
      topOpt,
      isFlowTypeDisable,
      isPotDisable,
      isProtocolTypeDisable,
      isTopDisable,
      isTimeDisable,
      handleOriginChange,
      loadAPI,
      resetForm
    }
  }
})
</script>
<style lang="less">
.realtimeHistoryContainer {
  width: 100%;
  height: 100%;
  .topBox {
    margin-bottom: 10px;

    .btns {
      text-align: right;
      margin-top: 16px;
    }
    .el-form--inline .el-form-item {
      display: flex;
    }
    .el-form--inline .el-form-item__label {
      white-space: nowrap;
      flex-grow: 0;
      flex-shrink: 0;
    }
    .el-form--inline .el-form-item__content {
      flex-grow: 1;
    }
  }
  .bottomBox {
    height: calc(100% - 90px);
    .chartBox {
      position: relative;
      width: 100%;
      height: 100%;
      padding: 20px 10px;
    }
  }
}
</style>
