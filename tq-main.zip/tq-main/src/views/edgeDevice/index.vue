<template>
  <div class="edgeDeviceContainer">
    <div class="topBox" ref="topBoxRef">
      <BorderBox>
        <el-form :inline="true" :model="edgeDeviceForm">
          <el-form-item label="连接状态">
            <el-select v-model="edgeDeviceForm.state">
              <el-option v-for="(item, index) in stateOpt" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="时间">
            <el-date-picker v-model="edgeDeviceForm.time" type="datetime" placeholder="选择日期时间"></el-date-picker>
          </el-form-item>
        </el-form>
        <div class="btns">
          <el-button type="primary" @click="loadAPI">查询</el-button>
          <el-button class="buttonReset" @click="resetForm">重置</el-button>
        </div>
      </BorderBox>
    </div>
    <div class="bottomBox">
      <BorderBox>
        <el-table :data="tableData" stripe style="width: 100%" @cell-click="handlerCellClick">
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="srcIP" label="源IP"></el-table-column>
          <el-table-column prop="srcPort" label="源端口"></el-table-column>
          <el-table-column prop="dstIP" label="目的IP"></el-table-column>
          <el-table-column prop="dstPort" label="目的端口"></el-table-column>
          <el-table-column prop="state" label="连接状态"></el-table-column>
          <el-table-column prop="time" label="时间"></el-table-column>
        </el-table>
        <el-pagination
          background
          layout="total, prev, pager, sizes,next"
          prev-text="上一页"
          next-text="下一页"
          :total="pageOption.total"
          :current-page="pageOption.page"
          :page-size="pageOption.size"
          @size-change="handleSizeChange"
          @current-change="handlerCurrentChange"
        ></el-pagination>
      </BorderBox>
    </div>
    <el-dialog title="告警描述" :visible.sync="dialogVisible" width="30%">
      <div>这是一段信息</div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        <el-button class="buttonCancel" @click="dialogVisible = false">返回</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from '@vue/composition-api'
import BorderBox from '@/components/Common/BorderBox.vue'
import { deviceList, stateList } from '@/api/edgeDevice'
import { isArray } from '@/utils/is'

export default defineComponent({
  name: 'edgeDevice',
  components: { BorderBox },
  setup() {
    // 表单form
    const edgeDeviceForm: any = ref({
      state: '',
      time: ''
    })
    const stateOpt: any = ref([])
    const topBoxRef: any = ref(null)
    // 表格数据
    const tableData: any = ref([])
    // 分页参数
    const pageOption: any = ref({
      total: 10, // 总页数
      page: 1, // 当前页
      size: 10
    })
    // 告警描述弹框
    const dialogVisible: any = ref(false)
    // 翻页事件
    function handlerCurrentChange(val) {
      pageOption.value.page = val
      loadAPI()
    }
    function handleSizeChange(val) {
      pageOption.value.size = val
      loadAPI()
    }
    // 单元格点击事件
    function handlerCellClick(row, column) {
      console.log(row, column)
      if (column.label === '告警描述') {
        dialogVisible.value = true
      }
    }
    // 重置
    function resetForm() {
      edgeDeviceForm.value = {
        state: '',
        time: ''
      }
    }
    function loadAPI() {
      deviceList(edgeDeviceForm).then((resp: any) => {
        tableData.value = resp.items
        pageOption.value.total = resp.total
      })
    }
    function laodStateList() {
      stateList().then((resp: any) => {
        stateOpt.value = resp
      })
    }
    onMounted(() => {
      laodStateList()
      loadAPI()
    })
    return {
      edgeDeviceForm,
      topBoxRef,
      tableData,
      pageOption,
      dialogVisible,
      stateOpt,
      handlerCurrentChange,
      handleSizeChange,
      handlerCellClick,
      resetForm,
      loadAPI
    }
  }
})
</script>
<style lang="less">
.edgeDeviceContainer {
  width: 100%;
  height: 100%;
  .topBox {
    margin-bottom: 10px;
    .content {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    // .el-form {
    //   display: flex;
    //   justify-content: space-between;
    // }
    .el-form--inline .el-form-item:last-child {
      margin-right: 0;
    }
  }
  .bottomBox {
    height: calc(100% - 90px);
    .el-table {
      height: calc(100% - 40px);
      .jumpText {
        color: #2093ff;
        text-decoration: underline;
        cursor: pointer;
      }
    }
  }
}
</style>
