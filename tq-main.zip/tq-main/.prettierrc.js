module.exports = {
  htmlWhitespaceSensitivity: 'ignore',
  endOfLine: 'auto',
  printWidth: 150,
  singleQuote: true,
  semi: false
}
