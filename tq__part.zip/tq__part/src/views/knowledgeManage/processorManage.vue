<template>
    <div>
        processorManage
    </div>
  </template>
  
  <script>
  export default {
    name: 'processorManage',
    data() {
      return {
      };
    },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  