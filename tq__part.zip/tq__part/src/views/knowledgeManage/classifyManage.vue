<template>
    <div>
        classifyManage
    </div>
  </template>
  
  <script>
  export default {
    name: 'classifyManage',
    data() {
      return {
      };
    },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  