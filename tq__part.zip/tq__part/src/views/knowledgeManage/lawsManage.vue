<template>
  <div>
    lawsManage
  </div>
</template>

<script>
export default {
  name: 'classifyManage',
  data() {
    return {
    };
  },
  methods: {
  }
}

</script>

<style lang="less" scoped>

</style>
