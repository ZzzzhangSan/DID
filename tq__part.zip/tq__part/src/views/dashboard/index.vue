<template>
  <div>
    首页
  </div>
</template>

<script>
// import { reqProductStatus } from '@/api'
export default {
  name: 'Dashboard',
  data() {
    return {
    }
  },
  methods: {
  }
}

</script>

<style lang="less" scoped>

</style>
