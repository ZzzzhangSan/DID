<template>
    <div>
        systemManage
    </div>
  </template>
  
  <script>
  export default {
    name: 'systemManage',
    data() {
      return {
      };
    },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  