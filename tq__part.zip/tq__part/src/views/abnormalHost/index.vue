<template>
    <div>
        <hostBehavior/>
    </div>
  </template>
  
  <script>
  import hostBehavior from '../../components/abnormalHost/hostBehavior.vue'
  export default {
    name: 'abnormalHost',
    data() {
      return {
      };
    },
      // 路由第一步
  components: {
    hostBehavior
  },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  