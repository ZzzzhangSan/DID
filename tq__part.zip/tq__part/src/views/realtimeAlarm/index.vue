<template>
    <div>
        <realtimeAlarm/>
    </div>
  </template>
  
  <script>
  import realtimeAlarm from '../../components/realtimeAlarm/index.vue'
  export default {
    name: 'realtimealarm',
    data() {
      return {
      };
    },
      // 路由第一步
  components: {
    realtimeAlarm
  },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  