<template>
    <div>
        incidentSearch
    </div>
  </template>
  
  <script>
  export default {
    name: 'incidentSearch',
    data() {
      return {
      };
    },
    methods: {
    }
  }
  
  </script>
  
  <style lang="less" scoped>
  
  </style>
  