import { request } from '../utils/request'
import api from './index'

// export function GetHostQueryList() {
//     return request({
//         url: api.GetHostQueryList,
//         method: 'GET',
//         data: data,
//         params: query
//     })
// }