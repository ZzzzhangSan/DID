const api = {
    //主机行为异常

    //主机监控
    //GetHostQueryList: "/tq/m3/host_query",
    //主机监控-详情



};

export default api;