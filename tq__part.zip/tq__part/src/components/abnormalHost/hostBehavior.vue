<template>
    <div class="main" style=" padding-bottom: 20px; padding-top: 20px;">
        <div class="shadow-div" style="height: 80px;">
            <div class="search">
                <el-form :inline="true" ref="abnormalHostForm" :model="abnormalHostForm">
                    <el-form-item prop="entrance" label="局点:">
                        <el-input v-model="abnormalHostForm.entrance" placeholder="请输入关键字"
                            style="width: 200px;margin-right: 20px;"></el-input>
                    </el-form-item>
                    <el-form-item prop="ip" label="主机IP:">
                        <el-input v-model="abnormalHostForm.ip" placeholder="请输入关键字"
                            style="width: 200px;margin-right: 20px;"></el-input>
                    </el-form-item>
                    <el-form-item label="检测时间" prop="metric_time">
                        <el-date-picker v-model="abnormalHostForm.metric_time" type="datetime" format="yyyy-MM-dd HH:mm:ss"
                            value-format="yyyy-MM-dd HH:mm:ss" placement="bottom-start" class="input-time"
                            placeholder="请选择时间">
                        </el-date-picker>
                    </el-form-item>
                    <div style="display: inline-block;float: right;  ">
                        <el-button type="primary" @click="searchForm()">查询</el-button>
                        <el-button type="info" @click="resetForm()">重置</el-button>
                    </div>
                </el-form>
            </div>

        </div>
        <div class="shadow-div hosttable">
            <div class="base_table">
                <el-table :data="tableData" style="width: 100%" ref="hostTable"
                    :header-cell-style="{ background: '#DAE8FC', color: '#101010', padding: '0px' }"
                    :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }" :header-row-style="{ height: '38px' }"
                    class="filetbale">
                    <!-- 指令的元素上添加element-loading-text属性，其值会被渲染为加载文案，并显示在加载图标的下方。
                        类似地，element-loading-spinner和element-loading-background属性分别用来设定图标类名和背景色值 -->
                    <el-table-column label="序号" min-width="2%" align="center">
                        <template slot-scope="scope">
                            {{ scope.$index + (currentPage - 1) * pageSize + 1 }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="id" label="主机id" min-width="3%" align="center" :show-overflow-tooltip="true">
                    </el-table-column>
                    <el-table-column prop="entrance" label="局点" min-width="6%" align="center" :show-overflow-tooltip="true">
                    </el-table-column>
                    <el-table-column prop="ip" label="主机IP" min-width="4%" align="center" :show-overflow-tooltip="true">
                    </el-table-column>
                    <el-table-column prop="cpu_avg_rate" label="CPU占用率" min-width="5%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.cpu_avg_rate.match(/\d+/)[0] > 12 }">{{
                                scope.row.cpu_avg_rate }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="memory_rate" label="内存占用率" min-width="5%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.memory_rate.match(/\d+/)[0] > 12 }">{{
                                scope.row.memory_rate }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="disk_iops_total" label="IOPS" min-width="3%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.disk_iops_total.match(/\d+/)[0] > 12 }">{{
                                scope.row.disk_iops_total }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="disk_read_total" label="磁盘读取字节数" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.disk_read_total.match(/\d+/)[0] > 12 }">{{
                                scope.row.disk_read_total }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="disk_write_total" label="磁盘写入字节数" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.disk_write_total.match(/\d+/)[0] > 12 }">{{
                                scope.row.disk_write_total }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="net_receive_flow" label="网络接收字节数" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.net_receive_flow.match(/\d+/)[0] > 12 }">{{
                                scope.row.net_receive_flow }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="net_transfer_flow" label="网络转发字节数" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.net_transfer_flow.match(/\d+/)[0] > 12 }">{{
                                scope.row.net_transfer_flow }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="connect_ip_nums" label="通信IP数量" min-width="5%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.connect_ip_nums > 12 }">{{ scope.row.connect_ip_nums }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="abnormal_ip_nums" label="异常通信IP数量" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.abnormal_ip_nums > 12 }">{{ scope.row.abnormal_ip_nums }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="external_ip_nums" label="外网通信IP数量" min-width="6%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.external_ip_nums > 12 }">{{ scope.row.external_ip_nums }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="dpdk_drive_flow" label="dpdk驱动捕获流量" min-width="7%" align="center"
                        :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <div :class="{ 'red-cell': scope.row.dpdk_drive_flow.match(/\d+/)[0] > 12 }">{{
                                scope.row.dpdk_drive_flow }}
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="insert_time" label="检测时间" min-width="5%" align="center" style="">
                    </el-table-column>
                    <el-table-column prop="operate" label="操作" min-width="4%" align="center" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <el-button type="text" size="small" style="color: #3286FF;"
                                @click="detailsShow(scope.row.entrance, scope.row.ip, scope.row.insert_time)">详情</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <div class="block" style="display: flex; justify-content: center;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
                :page-size="pageSize" :page-sizes="[10, 20, 50]" layout="total, sizes, prev, pager, next, jumper"
                :total="hostTotal">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { readFile } from 'fs';


export default {

    data() {
        return {
            input: '',
            //metric_time: new Date(2016, 9, 10, 18, 40),
            abnormalHostForm: {
                entrance: '',
                ip: '',
                metric_time: ''
            },
            tableData: [], //表格数据初始化
            currentPage: 1, //当前页码
            pageSize: 10, //每页最大条数
            hostTotal: 0, //实际数据总条数
            tableDataLoading: false, // 表格加载动画            
        }

    },
    created() {
        if (this.$route.query.from == 'update') { //获取浏览器url的参数，from页面来源: table客户端列表页面，update更新客户端信息页面 
            this.currentPage = parseInt(this.$route.query.page); //请求对应的页码数据
            this.pageSize = parseInt(this.$route.query.pageSize);
        }
        this.searchForm();

    },
    mounted() {
        window.addEventListener("keydown", this.handleSearch);
    },
    destroyed() {
        window.removeEventListener("keydown", this.handleSearch, false); //销毁回车事件，如果不销毁，在其他页面敲回车也会执行回车登录操作。
    },
    methods: {
        //查询客户端
        async searchForm() {
            // 列表初始
            let list = {
                entrance: this.abnormalHostForm.entrance,
                ip: this.abnormalHostForm.ip,
                metric_time: this.abnormalHostForm.metric_time,
                page: this.currentPage,
                size: this.pageSize
            };
            const { data: res } = await this.$http.get("/tq/m3/host_query", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.tableData = res.content.data;
                this.hostTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["hostTable"].doLayout();
                });
            }
        },
        //清空
        resetForm() {
            this.abnormalHostForm.entrance = "";
            this.abnormalHostForm.ip = "";
            this.abnormalHostForm.metric_time = ""
        },
        //分页
        //改变页面大小
        handleSizeChange(val) {
            //console.log("size:" + val);
            this.pageSize = val;
            this.searchForm();
        },
        //改变页码
        handleCurrentChange(val) {
            //console.log("Current11111:" + val);
            this.currentPage = val;
            this.searchForm();
        },

        detailsShow(entrance, ip, insert_time) {
            this.$router.push("/abnormalHost/details?entrance=" + entrance + "&ip=" + ip + "&insert_time=" + insert_time);
            console.log(entrance);
            console.log(ip);
            console.log(insert_time);
        },

        // cellStyle({ row, column, rowIndex, columnIndex }) {
        //     if (column.label == "CPU占用率" && row[column.property].match(/\d+/)[0] >= 80) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "内存占用率" && row[column.property].match(/\d+/)[0] >= 80) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "IOPS" && row[column.property] >= 70) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘读取字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘写入字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "网络接收字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘读取字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "通信IP数量" && row[column.property] >= 16) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "异常通信IP数量" && row[column.property] >= 15) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "外网通信IP数量" && row[column.property] >= 10) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "dpdk驱动捕获流量" && row[column.property].match(/\d+/)[0] >= 1001) {
        //         return `background-color: #f8cecc`;
        //     }
        //     return `padding: 0px`;


        // }

    },
}
</script>
<style>
.main {
    padding: 20px;
}

.search {
    width: 97%;

    margin: 0 auto;


}

.shadow-div {

    background-color: white;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;

}

.hosttable {
    padding: 20px 10px 20px 10px;
}

.block {
    padding-bottom: 20px;
    /* padding-top: 20px; */
}

/* 表格边距 */
.el-table th.el-table__cell>.cell {
    padding-left: 0px;
    padding-right: 0px;
}

.el-table .cell {
    padding: 0px;
}

.el-button--info {
    color: black;
    background-color: white;
    border-color: #BBBBBB;
}

.el-table td.el-table__cell div {
    font-size: 12px !important;
    ;
}

/* 单元格根据值变色 */

.red-cell {
    background-color: #f8cecc;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}

.cellstyle {
    background-color: red
}

/* .zeroClass {
    background-color: red;
    padding: 0px;
} */
</style>