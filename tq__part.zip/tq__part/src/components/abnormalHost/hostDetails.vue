<template>
    <div class="main">
        <div style="padding: 10px;">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>主机行为异常</el-breadcrumb-item>
                <el-breadcrumb-item breadcrumb-item>详情</el-breadcrumb-item>
            </el-breadcrumb>
            <div class="host-go-back" @click="goBackHost">
                <span>返回上一级</span>
                <i class="el-icon-arrow-left"></i>
            </div>
        </div>


        <div class="shadow-div" style="height: 50px;margin-bottom: 20px;padding: 0 0 0 20px;">
            <!-- 详情信息 -->
            <div class="search" style="display: flex;justify-content: space-between;width: 100%;">
                <div style="line-height: 50px;">
                    <span class="client-device">局点: </span>
                    <span class="client-device-num">{{ entrance }}</span>
                    <span class="client-device" style=" padding-left: 24px;">主机IP：
                    </span>
                    <span class="client-device-num">{{ ip }}</span>
                </div>
            </div>
        </div>
        <div class="shadow-div hardware">
            <div class="region-header" style="color: #6A61E3;">硬件指标</div>
            <div>
                <!-- 饼状图居中 -->
                <div style="display: inline-block;width: 50%;text-align: center;">
                    <el-progress type="circle" :percentage="memory_usage" :stroke-width="15"
                        :color="changeBarColor(memory_usage_alert)"></el-progress>
                    <span class="piechartName">内存占用率</span>
                </div>
                <div style="display: inline-block;width: 50%;text-align: center;">
                    <el-progress type="circle" :percentage="cpu_usage" :stroke-width="15"
                        :color="changeBarColor(cpu_usage_alert)"></el-progress>
                    <span class="piechartName">平均CPU占用率</span>
                </div>
            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #6A61E3;">磁盘</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="disktableData" style="width: 100%" tooltip-effect="dark" ref="diskTable"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="4%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="盘符名称_序列号" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="磁盘占用率" min-width="8%" align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': disk_usage_alert[scope.$index] == 1 }">
                                    {{ scope.row[1] }}%
                                </div>
                            </template>

                        </el-table-column>
                        <el-table-column prop="2" :show-overflow-tooltip="true" label="磁盘iops" min-width="8%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': iops_alert[scope.$index] == 1 }">
                                    {{ scope.row[2] }}
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="3" :show-overflow-tooltip="true" label="磁盘写入字节数" min-width="12%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': write_byteps_alert[scope.$index] == 1 }">
                                    {{ scope.row[3] }}KB/s
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="4" :show-overflow-tooltip="true" label="磁盘读取字节数" min-width="12%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': read_byteps_alert[scope.$index] == 1 }">
                                    {{ scope.row[4] }}KB/s</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="5" :show-overflow-tooltip="true" label="磁盘可用性" min-width="10%"
                            align="center">
                            <template slot-scope="scope">
                                <div v-if="scope.row[5] == 1" class="istrue">
                                    是
                                </div>
                                <div v-if="scope.row[5] == 2" class="isfalse">
                                    否
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #6A61E3;">CPU</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="cputableData" style="width: 100%," ref="cpuTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="20%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="核" min-width="40%" align="center">
                            <template slot-scope="scope">
                                {{ scope.row[0] }}
                            </template>
                        </el-table-column>
                        <!-- 使用width设置列百分比，会将%变为px，使用min-width -->
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="占用率" min-width="40%" align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': cputable_usage_alert[scope.$index] == 1 }">
                                    {{ scope.row[1] }}%</div>
                            </template>
                        </el-table-column>
                    </el-table>

                </div>


            </div>
            <div class="small-region" style="width: 100%;">
                <div class="small-region-header" style="color: #6A61E3;">文件</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="filetableData" style="width: 100%" ref="fileTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="文件" min-width="12%" align="center">
                            <template slot-scope="scope">{{ scope.row[0] }}</template>
                        </el-table-column>
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="文件MD5值" min-width="12%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': file_md5_alert[scope.$index] == 1 }">{{ scope.row[1] }}</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="2" :show-overflow-tooltip="true" label="文件大小" min-width="8%" align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': file_size_alert[scope.$index] == 1 }">{{ scope.row[2] }}KB</div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="3" :show-overflow-tooltip="true" label="文件修改时间" min-width="12%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': file_edit_time_alert[scope.$index] == 1 }">{{ scope.row[3] }}
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>

            </div>
        </div>

        <div class="shadow-div network">
            <div class="region-header" style="color: #1385FF;">网络指标</div>
            <div style=" margin-top: 20px;">
                <!-- 进度条 -->
                <div style="margin-bottom: 20px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="host-process">
                                <!-- 变蓝，警告变红 -->
                                <div class="process-header" style="color:  #1385FF;">主机网络每秒转发字节数</div>
                                <el-row>
                                    <el-col :span="20"> <el-progress :percentage="calculatePercentage(0)" :show-text="false"
                                            style="margin-top: 4px;"
                                            :color="changeBarColor(netBarData[0].alert)"></el-progress>
                                    </el-col>
                                    <el-col :span="4">
                                        <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[0].currentValue }}mbps
                                        </div>
                                    </el-col>
                                </el-row>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="host-process">
                                <div class="process-header" style="color: #1385FF;">主机网络每秒接收字节数</div>
                                <el-row>
                                    <el-col :span="20"> <el-progress :percentage="calculatePercentage(1)" :show-text="false"
                                            style="margin-top: 4px;"
                                            :color="changeBarColor(netBarData[1].alert)"></el-progress>
                                    </el-col>
                                    <el-col :span="4">
                                        <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[1].currentValue }}mbps
                                        </div>
                                    </el-col>
                                </el-row>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="grid-content bg-purple"></div>
                        </el-col>
                    </el-row>


                </div>
                <div style="margin-bottom: 20px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">dpdk驱动捕获流量</div>
                                <el-col :span="20"> <el-progress :percentage="calculatePercentage(2)" :show-text="false"
                                        style="margin-top: 4px;" :color="changeBarColor(netBarData[2].alert)"></el-progress>
                                </el-col>
                                <el-col :span="4">
                                    <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[2].currentValue }}mbps
                                    </div>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">主机所有cap网口总流量</div>
                                <el-row>
                                    <el-col :span="20"> <el-progress :percentage="calculatePercentage(3)" :show-text="false"
                                            style="margin-top: 4px;"
                                            :color="changeBarColor(netBarData[3].alert)"></el-progress>
                                    </el-col>
                                    <el-col :span="4">
                                        <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[3].currentValue }}mbps
                                        </div>
                                    </el-col>
                                </el-row>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">主机丢包率</div>
                                <el-col :span="20"> <el-progress :percentage="calculatePercentage(4)" :show-text="false"
                                        style="margin-top: 4px;" :color="changeBarColor(netBarData[4].alert)"></el-progress>
                                </el-col>
                                <el-col :span="4">
                                    <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[4].currentValue }}.0%</div>
                                </el-col>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div style="margin-bottom: 30px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color: #1385FF;">主机通信IP数</div>
                                <el-col :span="20"> <el-progress :percentage="calculatePercentage(5)" :show-text="false"
                                        style="margin-top: 4px;" :color="changeBarColor(netBarData[5].alert)"></el-progress>
                                </el-col>
                                <el-col :span="4">
                                    <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[5].currentValue }}个</div>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color:  #1385FF;">主机异常通信IP数</div>
                                <el-col :span="20"> <el-progress :percentage="calculatePercentage(6)" :show-text="false"
                                        style="margin-top: 4px;" :color="changeBarColor(netBarData[6].alert)"></el-progress>
                                </el-col>
                                <el-col :span="4">
                                    <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[6].currentValue }}个</div>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color: #1385FF;">主机外网通信IP数</div>
                                <el-col :span="20"> <el-progress :percentage="calculatePercentage(7)" :show-text="false"
                                        style="margin-top: 4px;" :color="changeBarColor(netBarData[7].alert)"></el-progress>
                                </el-col>
                                <el-col :span="4">
                                    <div style="font-size: 14px;margin-left: 6px;">{{ netBarData[7].currentValue }}个</div>
                                </el-col>
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #1385FF;">网口</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="porttableData" style="width: 100%" ref="portTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#C1DFFF', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="网口名称" min-width="8%" align="center">
                            <template slot-scope="scope">{{ scope.row[0] }}</template>
                        </el-table-column>
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="网口处理流量" min-width="8%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': cap_flow_alert[scope.$index] == 1 }">
                                    {{ scope.row[1] }}MB
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="2" :show-overflow-tooltip="true" label="网口丢包率" min-width="8%" align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': cap_drop_rate_alert[scope.$index] == 1 }">{{ scope.row[2] }}%
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>


            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #1385FF;">核</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="coretableData" style="width: 100%" ref="coreTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#C1DFFF', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="核名称" min-width="8%" align="center">
                            <template slot-scope="scope">{{ scope.row[0] }}</template>
                        </el-table-column>
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="核处理流量" min-width="8%" align="center">
                            <template slot-scope="scope">{{ scope.row[1] }}MB</template>
                        </el-table-column>
                        <el-table-column prop="2" :show-overflow-tooltip="true" label="核丢包率" min-width="8%" align="center">
                            <template slot-scope="scope">{{ scope.row[2] }}%</template>
                        </el-table-column>
                    </el-table>

                </div>

            </div>
        </div>

        <div class="shadow-div process">
            <div class="region-header" style="color: #19855A;">进程指标</div>
            <div style="justify-content: space-between;width: 100%;">
                <div style="line-height: 30px;display: flex; float:right;">
                    <span class="process-info">主程序是否在运行： </span>

                    <span v-if="netProgramRun == 1" class="isnettrue">
                        是
                    </span>
                    <span v-if="netProgramRun == 2" class="isnetfalse">
                        否
                    </span>

                    <span class="process-info" style=" padding-left: 24px;">网卡驱动是否在运行：
                    </span>

                    <span v-if="netCardDriver == 1" class="isnettrue">
                        是
                    </span>
                    <span v-if="netCardDriver == 2" class="isnetfalse">
                        否
                    </span>

                </div>
            </div>
            <div class="small-region" style="width: 100%;">
                <!-- <div class="small-region-header" style="color: #1385FF;">进程指标</div> -->
                <div style="padding-bottom: 10px;">
                    <el-table :data="processtableData" style="width: 100%" ref="processTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#DEF0E6', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" height="250">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="10%"
                            align="center">
                            <template slot-scope="scope">
                                <span>{{ scope.$index + 1 }}</span>
                            </template>
                        </el-table-column>
                        <el-table-column prop="0" :show-overflow-tooltip="true" label="进程名称" min-width="16%" align="center">
                            <template slot-scope="scope">{{ scope.row[0] }}</template>
                        </el-table-column>
                        <el-table-column prop="1" :show-overflow-tooltip="true" label="CPU占用率" min-width="16%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': process_usage_alert[scope.$index] == 1 }">{{ scope.row[1] }}%
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column prop="2" :show-overflow-tooltip="true" label="每秒转发字节数" min-width="16%"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="{ 'red-cell': process_byte_alert[scope.$index] == 1 }">{{ scope.row[2] }}MB
                                </div>
                            </template>
                        </el-table-column>
                        <!-- <el-table-column prop="healthy" :show-overflow-tooltip="true" label="磁盘可用性" min-width="10%"
                            align="center">
                            <template slot-scope="scope">
                                <div v-if="scope.row.healthy == 1" class="isfalse">
                                    是
                                </div>
                                <div v-if="scope.row.healthy == 2" class="istrue">
                                    否
                                </div>
                            </template>
                        </el-table-column> -->
                    </el-table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

export default {

    data() {
        return {
            entrance: '',
            ip: '',
            metric_time: '',
            input: '',
            cpu_usage: '',//CPU环形图
            memory_usage: '',//内存环形图
            cpu_usage_alert: '',
            memory_usage_alert: '',


            //单元格告警项
            disk_usage_alert: [],
            iops_alert: [],
            write_byteps_alert: [],
            read_byteps_alert: [],
            cputable_usage_alert: [],
            file_md5_alert: [],
            file_size_alert: [],
            file_edit_time_alert: [],
            cap_flow_alert: [],
            cap_drop_rate_alert: [],
            process_usage_alert: [],
            process_byte_alert: [],

            // //进度条
            // host_transfer_bit_per_sec: '1000MB',//主机网络每秒转发字节数            
            // host_recieve_bit_per_sec: '1000MB',//主机网络每秒接受字节数
            // connect_ip_num: 30,//主机通信IP数
            // abnormal_connect_ip_num: 15,//主机异常通信IP 数
            // foreign_connect_ip_num: 15,//主机外网通信IP数
            // dpdk_flow: '1000MB',//dpdk驱动捕获流量
            // host_cap_flow: '2GB',//主机所有cap网口总流量
            // host_packet_loss_rate: '1.0%',//主机丢包率

            // 进程-主程序是否运行
            netProgramRun: 2,
            // 进程-网卡驱动是否运行
            netCardDriver: 1,


            // 网络进度条
            netBarData: [
                { currentValue: '', maxValue: 1500, alert: '' },
                { currentValue: '', maxValue: 2500, alert: '' },
                { currentValue: '', maxValue: 1500, alert: '' },
                { currentValue: '', maxValue: 1500, alert: '' },
                { currentValue: '', maxValue: 5, alert: '' },
                { currentValue: '', maxValue: 30, alert: '' },
                { currentValue: '', maxValue: 30, alert: '' },
                { currentValue: '', maxValue: 30, alert: '' },
            ],


            disktableData: [],
            cputableData: [],// 核
            filetableData: [],// 文件
            porttableData: [],// 网口 
            coretableData: [],// 核
            processtableData: []

        };
    },

    created() {
        this.updateData();
        this.searchForm();

    },
    watch: {
        $route: {
            handler(route) {
                console.log('watch当前路由信息', route);
                console.log('watch当前路由参数', route.query);
                this.updateData();
                this.searchForm();
            },
            immediate: true
        }
    },

    mounted() {
        window.addEventListener("keydown", this.handleSearch);
        console.log("初始化");
        this.updateData();// 初始化时获取一次参数

    },
    destroyed() {
        window.removeEventListener("keydown", this.handleSearch, false); //销毁回车事件，如果不销毁，在其他页面敲回车也会执行回车登录操作。
    },


    methods: {
        //获取传递的参数
        updateData() {
            this.entrance = this.$route.query.entrance || '';
            this.ip = this.$route.query.ip || '';
            this.metric_time = this.$route.query.insert_time || '';
            console.log("调用updateData");
        },
        changeBarColor(alert) {
            if (alert === 1) {
                return 'red';
            }
        },

        //计算进度条
        calculatePercentage(index) {
            console.log("index" + index)
            let current = this.netBarData[index].currentValue;
            let max = this.netBarData[index].maxValue;
            if (!current || !max) {
                return 0;
            }
            return (current / max) * 100;
        },


        // 查询所有
        async searchForm() {
            // 列表初始,传参列表
            let list = {
                entrance: this.entrance,
                ip: this.ip,
                metric_time: this.metric_time,
            };
            const { data: res } = await this.$http.get("/tq/m3/host_detail", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                // 各个表一一对应
                this.disktableData = res.content.disk.map(item => [
                    item.disk_name,
                    parseFloat(item.disk_usage[0].replace(/%/g, '')),
                    item.iops[0],
                    parseInt(item.write_byteps[0]),
                    parseInt(item.read_byteps[0]),
                    item.healthy
                ]);
                //告警值
                this.disk_usage_alert = res.content.disk.map(item => [
                    item.disk_usage[1],
                ]);
                this.iops_alert = res.content.disk.map(item => [
                    item.iops[1],
                ]);
                this.write_byteps_alert = res.content.disk.map(item => [
                    item.write_byteps[1],
                ]);
                this.read_byteps_alert = res.content.disk.map(item => [
                    item.read_byteps[1],
                ]);

                this.cputableData = res.content.cpu_core.map(item => [
                    item.cpu_name,
                    parseFloat(item.cpu_usage[0].replace(/%/g, '')),
                ]);
                this.cputable_usage_alert = res.content.cpu_core.map(item => [
                    item.cpu_usage[1],
                ]);

                this.filetableData = res.content.file.map(item => [
                    item.file_name,
                    item.file_md5[0],
                    parseInt(item.file_size[0]),
                    item.file_edit_time[0],
                ]);
                this.file_md5_alert = res.content.file.map(item => [
                    item.file_md5[1],
                ]);
                this.file_size_alert = res.content.file.map(item => [
                    item.file_size[1],
                ]);
                this.file_edit_time_alert = res.content.file.map(item => [
                    item.file_edit_time[1],
                ]);

                this.porttableData = res.content.network_cap.map(item => [
                    item.cap_name,
                    parseInt(item.cap_flow[0]),
                    parseFloat(item.cap_drop_rate[0].replace(/%/g, '')),
                ]);//cap对应网口
                this.cap_flow_alert = res.content.network_cap.map(item => [
                    item.cap_flow[1],
                ]);
                this.cap_drop_rate_alert = res.content.network_cap.map(item => [
                    item.cap_drop_rate[1],
                ]);
                this.coretableData = res.content.network_core.map(item => [
                    item.core_name,
                    parseInt(item.core_flow[0]),
                    parseFloat(item.core_drop_rate[0]),
                    //parseFloat(item.core_drop_rate[0].replace(/%/g, '')),
                ]);//core对应核
                this.core_flow_alert = res.content.network_core.map(item => [
                    item.core_flow[1],
                ]);
                this.core_drop_rate_alert = res.content.network_core.map(item => [
                    item.core_drop_rate[1],
                ]);

                this.processtableData = res.content.process.map(item => [
                    item.process_name,
                    parseFloat(item.process_usage[0].replace(/%/g, '')),
                    parseInt(item.process_byte[0]),
                ]);
                this.process_usage_alert = res.content.process.map(item => [
                    item.process_usage[1],
                ]);
                this.process_byte_alert = res.content.process.map(item => [
                    item.process_byte[1],
                ]);


                //表格告警项 应该是数组
                //this.disk_usage_alert = res.content.disk.disk_usage[1];

                // this.iops_alert = res.content.disk.iops[1];
                // this.write_byteps_alert = res.content.disk.write_byteps[1];
                // this.read_byteps_alert = res.content.disk.read_byteps[1];
                // this.cpu_usage_alert = res.content.cpu_core.cpu_usage[1];
                // this.file_md5_alert = res.content.file.file_md5[1];
                // this.file_size_alert = res.content.file.file_size[1];
                // this.file_edit_time_alert = res.content.file.file_edit_time[1];
                // this.item.cap_flow_alert = res.content.network_cap.cap_flow[1];
                // this.cap_drop_rate_alert = res.content.network_cap.cap_drop_rate[1];
                // this.process_usage_alert = res.content.process.process_usage[1];
                // this.process_byte_alert = res.content.process.process_byte[1];
                // console.log(' this.process_byte_alert'+this.process_byte_alert)



                //环形进度条
                this.cpu_usage = parseFloat(res.content.cpu_host[0].cpu_usage[0].replace(/%/g, ''));
                console.log('res.content.cpu_host[0].cpu_usage[0].replace(/%/g, ' + res.content.cpu_host[0].cpu_usage[0].replace(/%/g, ''));
                this.memory_usage = parseFloat(res.content.memory[0].memory_usage[0].replace(/%/g, ''));
                this.cpu_usage_alert = parseFloat(res.content.cpu_host[0].cpu_usage[1]);
                this.memory_usage_alert = parseFloat(res.content.memory[0].memory_usage[1]);


                //进度条数据
                this.netBarData[0].currentValue = parseInt(res.content.network_host[0].host_transfer_bit_per_sec[0]);
                this.netBarData[1].currentValue = parseInt(res.content.network_host[0].host_recieve_bit_per_sec[0]);
                this.netBarData[2].currentValue = parseInt(res.content.network_host[0].dpdk_flow[0]);
                this.netBarData[3].currentValue = parseInt(res.content.network_host[0].host_cap_flow[0]);
                this.netBarData[4].currentValue = parseFloat(res.content.network_host[0].host_packet_loss_rate[0].replace(/%/g, ''));
                this.netBarData[5].currentValue = res.content.network_host[0].connect_ip_num[0];
                this.netBarData[6].currentValue = res.content.network_host[0].abnormal_connect_ip_num[0];
                this.netBarData[7].currentValue = res.content.network_host[0].foreign_connect_ip_num[0];

                //进度条数据-告警
                this.netBarData[0].alert = res.content.network_host[0].host_transfer_bit_per_sec[1];
                this.netBarData[1].alert = res.content.network_host[0].host_recieve_bit_per_sec[1];
                this.netBarData[2].alert = res.content.network_host[0].dpdk_flow[1];
                this.netBarData[3].alert = res.content.network_host[0].host_cap_flow[1];
                this.netBarData[4].alert = res.content.network_host[0].host_packet_loss_rate[1];
                this.netBarData[5].alert = res.content.network_host[0].connect_ip_num[1];
                this.netBarData[6].alert = res.content.network_host[0].abnormal_connect_ip_num[1];
                this.netBarData[7].alert = res.content.network_host[0].foreign_connect_ip_num[1];


                // 进程-主程序是否运行
                this.netProgramRun = res.content.process_host[0].main_process_running;
                // 进程-网卡驱动是否运行
                this.netCardDriver = res.content.process_host[0].network_driver_running;


                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["diskTable"].doLayout();
                    this.$refs["cpuTable"].doLayout();
                    this.$refs["fileTable"].doLayout();
                    this.$refs["portTable"].doLayout();
                    this.$refs["coreTable"].doLayout();
                    this.$refs["processTable"].doLayout();
                });
            }
        },

        // 返回上一级
        goBackHost() {
            return this.$router.push("/abnormalHost");
        },

        // cellStyle({ row, column, rowIndex, columnIndex }) {
        //     if (column.label == "CPU占用率" && row[column.property].match(/\d+/)[0] >= 80) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "内存占用率" && row[column.property].match(/\d+/)[0] >= 80) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "IOPS" && row[column.property] >= 70) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘读取字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘写入字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "网络接收字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "磁盘读取字节数" && row[column.property].match(/\d+/)[0] >= 210) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "通信IP数量" && row[column.property] >= 16) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "异常通信IP数量" && row[column.property] >= 15) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "外网通信IP数量" && row[column.property] >= 10) {
        //         return `background-color: #f8cecc`;
        //     }
        //     if (column.label == "dpdk驱动捕获流量" && row[column.property].match(/\d+/)[0] >= 1001) {
        //         return `background-color: #f8cecc`;
        //     }
        //     return `padding: 0px`;


        // }
    },

}


</script>
<style>
.main {
    padding: 0 20px 20px 20px;
}

.search {
    width: 97%;
    margin: 0 auto;
}

.shadow-div {

    background-color: white;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 30px;

}

.block {
    padding-bottom: 20px;
    /* padding-top: 20px; */
}

.client-device {
    font-family: Microsoft YaHei;
    font-size: 16px;
    font-weight: 700;
    line-height: 22px;
    text-align: center;
    color: #1A49AA;
    /* margin-left: 24px; */
}

.client-device-num {
    font-family: Microsoft YaHei;
    font-size: 16px;
    font-weight: 400;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;

}

/* 进程 */
.process-info {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 400;
    line-height: 22px;
    text-align: center;
}

.process-info-num {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 500;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;
    color: #19855A;

}

.region-header {
    height: 40px;
    font-family: "Microsoft YaHei";
    /* font-style: normal; */
    font-weight: 700;
    font-size: 26px;
    line-height: 18px;
    align-items: center;

    padding-left: 10px;
    /* margin-bottom: 20px; */
    /* border-bottom: 1px solid #dedede; */
}

.small-region-header {
    height: 40px;
    font-family: "Microsoft YaHei";
    /* font-style: normal; */
    font-weight: 600;
    font-size: 20px;
    line-height: 18px;
    align-items: center;
    padding-left: 10px;
}

.small-region {
    display: inline-block;
    width: 50%;
    padding: 10px;

}

/* 是否标签 */

.istrue {
    color: #56AB61;
    background-color: rgba(224, 255, 208, 0.94);
    width: 30px;
    height: 27px;
    line-height: 27px;
    display: inline-block;
    border-radius: 4px;
}

.isfalse {
    color: #E2250F;
    background-color: rgba(226, 37, 15, 0.25);
    width: 30px;
    height: 27px;
    line-height: 27px;
    display: inline-block;
    border-radius: 4px;
}

.isnetfalse {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 500;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;
    color: red;
}

.isnettrue {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 500;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;
    color: green;
}

/* 表格边距 */
.el-table th.el-table__cell>.cell {
    padding-left: 0px;
    padding-right: 0px;
}

/* 面包屑 */
.el-breadcrumb__item:first-child .el-breadcrumb__inner {
    color: black !important;
}

.el-breadcrumb__item:last-child .el-breadcrumb__inner {
    color: #1675d5;
}

/* 返回上一级 */
.host-go-back {
    font-family: "Microsoft YaHei";
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
    color: #1675d5;
    float: right;
    margin-top: -15px;
    cursor: pointer;


    i {
        font-weight: 400;
        font-size: 14px;
        line-height: 22px;
        color: #1675d5;
    }
}

.piechartName {
    display: block;
    font-weight: 400;
    font-size: 14px;
    margin-top: 10px;
}

/* 网络指标进度条 */
.process-header {
    height: 24px;
    font-family: "Microsoft YaHei";
    font-size: 14px;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}

.host-process,
.other-process,
.comm-process {
    padding-left: 15px;
}

/* 
.host-process .el-progress-bar__inner {
    background-color: #FDB97A;

}

.other-process .el-progress-bar__inner {
    background-color: #1385FF;
}

.comm-process .el-progress-bar__inner {
    background-color: #DC3545;
} */

.el-progress-bar__outer {
    height: 8px !important
}

/* 滚动条颜色 */
.hardware .el-table .el-table__cell.gutter {
    background-color: #EDE8FE;
}

.network .el-table .el-table__cell.gutter {
    background-color: #c1dfff;
}

.process .el-table .el-table__cell.gutter {
    background-color: #def0e6;
}

.el-table--scrollable-y .el-table__body-wrapper {
    height: 200px !important;
}

/* 单元格变红 */
.red-cell {
    background-color: #f8cecc;

}
</style>