<template>
    <div class="main">
        <div style="padding: 10px;">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>主机行为异常</el-breadcrumb-item>
                <el-breadcrumb-item breadcrumb-item>详情</el-breadcrumb-item>
            </el-breadcrumb>
            <div class="host-go-back" @click="goBackHost">
                <span>返回上一级</span>
                <i class="el-icon-arrow-left"></i>
            </div>
        </div>


        <div class="shadow-div" style="height: 50px;margin-bottom: 20px;padding: 0 0 0 20px;">
            <!-- 详情信息 -->
            <div class="search" style="display: flex;justify-content: space-between;width: 100%;">
                <div style="line-height: 50px;">
                    <span class="client-device">局点: </span>
                    <span class="client-device-num">{{ entrance }}</span>
                    <span class="client-device" style=" padding-left: 24px;">主机IP：
                    </span>
                    <span class="client-device-num">{{ ip }}</span>
                </div>
            </div>
        </div>
        <div class="shadow-div">
            <div class="region-header" style="color: #6A61E3;">硬件指标</div>
            <div>
                <!-- 饼状图居中 -->
                <div style="display: inline-block;width: 50%;text-align: center;">
                    <el-progress type="circle" :percentage="45" :stroke-width="15" :color="memoryColors"></el-progress>
                    <span class="piechartName">内存占用率</span>
                </div>
                <div style="display: inline-block;width: 50%;text-align: center;">
                    <el-progress type="circle" :percentage="60" :stroke-width="15" :color="cpuColors"></el-progress>
                    <span class="piechartName">平均CPU占用率</span>
                </div>
            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #6A61E3;">磁盘</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="disktableData" style="width: 100%" tooltip-effect="dark" ref="diskTable"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale" >
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="4%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="driveLetter" :show-overflow-tooltip="true" label="盘符名称_序列号" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="diskoccupancyRate" :show-overflow-tooltip="true" label="磁盘占用率" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="diskiops" :show-overflow-tooltip="true" label="磁盘iops" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="diskWrite" :show-overflow-tooltip="true" label="磁盘写入字节数" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="diskRead" :show-overflow-tooltip="true" label="磁盘读取字节数" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="diskVaild" :show-overflow-tooltip="true" label="磁盘可用性" min-width="10%"
                            align="center">
                            <template slot-scope="scope">
                                <div v-if="scope.row.diskVaild == 1" class="istrue">
                                    是
                                </div>
                                <div v-if="scope.row.diskVaild == 2" class="isfalse">
                                    否
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="diskTotal"
                        @current-change="handleCurrentChange1"></el-pagination>
                </div>

            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #6A61E3;">CPU</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="cputableData" style="width: 100%" ref="cpuTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="20%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="core" :show-overflow-tooltip="true" label="核" min-width="40%" align="center">
                        </el-table-column>
                        <!-- 使用width设置列百分比，会将%变为px，使用min-width -->
                        <el-table-column prop="occupancyRate" :show-overflow-tooltip="true" label="占用率" min-width="40%"
                            align="center">
                        </el-table-column>
                    </el-table>

                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="cpuTotal"
                        @current-change="handleCurrentChange2"></el-pagination>
                </div>

            </div>
            <div class="small-region" style="width: 100%;">
                <div class="small-region-header" style="color: #6A61E3;">文件</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="filetableData" style="width: 100%" ref="fileTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#EDE8FE', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="file" :show-overflow-tooltip="true" label="文件" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="MD5Value" :show-overflow-tooltip="true" label="文件MD5值" min-width="12%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="fileSize" :show-overflow-tooltip="true" label="文件大小" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="modificationTime" :show-overflow-tooltip="true" label="文件修改时间"
                            min-width="12%" align="center">
                        </el-table-column>
                    </el-table>
                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="fileTotal"
                        @current-change="handleCurrentChange3"></el-pagination>
                </div>
            </div>
        </div>

        <div class="shadow-div">
            <div class="region-header" style="color: #1385FF;">网络指标</div>
            <div style=" margin-top: 20px;">
                <!-- 进度条 -->
                <div style="margin-bottom: 20px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="host-process">
                                <div class="process-header" style="color: #FDB97A;">主机网络每秒转发字节数</div>
                                <el-progress :percentage="40"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="host-process">
                                <div class="process-header" style="color: #FDB97A;">主机网络每秒转发字节数</div>
                                <el-progress :percentage="70"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="grid-content bg-purple"></div>
                        </el-col>
                    </el-row>


                </div>
                <div style="margin-bottom: 20px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">dpdk驱动捕获流量</div>
                                <el-progress :percentage="20"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">主机所有cap网口总流量</div>
                                <el-progress :percentage="50"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="other-process">
                                <div class="process-header" style="color: #1385FF;">主机丢包率</div>
                                <el-progress :percentage="30"></el-progress>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div style="margin-bottom: 30px;">
                    <el-row>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color: #DC3545;">主机通信IP数</div>
                                <el-progress :percentage="50"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color: #DC3545;">主机异常通信IP数</div>
                                <el-progress :percentage="20"></el-progress>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="comm-process">
                                <div class="process-header" style="color: #DC3545;">主机外网通信IP数</div>
                                <el-progress :percentage="10"></el-progress>
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #1385FF;">网口</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="porttableData" style="width: 100%" ref="portTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#C1DFFF', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="portName" :show-overflow-tooltip="true" label="网口名称" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="portTraffic" :show-overflow-tooltip="true" label="网口流量" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="packetlossRate" :show-overflow-tooltip="true" label="网口丢包率" min-width="8%"
                            align="center">
                        </el-table-column>
                    </el-table>
                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="portTotal"
                        @current-change="handleCurrentChange4"></el-pagination>
                </div>

            </div>
            <div class="small-region">
                <div class="small-region-header" style="color: #1385FF;">核</div>
                <div style="padding-bottom: 10px;">
                    <el-table :data="coretableData" style="width: 100%" ref="coreTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#C1DFFF', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="6%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="coreName" :show-overflow-tooltip="true" label="核名称" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="coreflow" :show-overflow-tooltip="true" label="核处理流量" min-width="8%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="corelossRate" :show-overflow-tooltip="true" label="核丢包率" min-width="8%"
                            align="center">
                        </el-table-column>
                    </el-table>

                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="coreTotal"
                        @current-change="handleCurrentChange5"></el-pagination>
                </div>
            </div>
        </div>

        <div class="shadow-div">
            <div class="region-header" style="color: #19855A;">进程指标</div>
            <div style="justify-content: space-between;width: 100%;">
                <div style="line-height: 30px;display: flex; float:right;">
                    <span class="process-info">主程序是否在运行： </span>
                    <span class="process-info-num">是</span>
                    <span class="process-info" style=" padding-left: 24px;">网卡驱动是否在运行：
                    </span>
                    <span class="process-info-num">是</span>
                </div>
            </div>
            <div class="small-region" style="width: 100%;">
                <!-- <div class="small-region-header" style="color: #1385FF;">进程指标</div> -->
                <div style="padding-bottom: 10px;">
                    <el-table :data="processtableData" style="width: 100%" ref="processTable" tooltip-effect="dark"
                        :header-cell-style="{ background: '#DEF0E6', color: '#101010', padding: '0px' }"
                        :cell-style="{ padding: '0px' }" :row-style="{ height: '50px' }"
                        :header-row-style="{ height: '38px' }" class="filetbale">
                        <el-table-column prop="number" :show-overflow-tooltip="true" label="编号" min-width="10%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="processName" :show-overflow-tooltip="true" label="进程名称" min-width="16%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="cpuUsage" :show-overflow-tooltip="true" label="CPU占用率" min-width="16%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="bytesForward" :show-overflow-tooltip="true" label="每秒转发字节数" min-width="16%"
                            align="center">
                        </el-table-column>
                        <el-table-column prop="isRestart" :show-overflow-tooltip="true" label="是否频繁重启" min-width="10%"
                            align="center">
                            <template slot-scope="scope">
                                <div v-if="scope.row.isRestart == 1" class="isfalse">
                                    是
                                </div>
                                <div v-if="scope.row.isRestart == 2" class="istrue">
                                    否
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
                <div style="display: flex; justify-content: center;">
                    <el-pagination layout="prev, pager, next" :total="processTotal"
                        :current-page="currentProcessPage6"></el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

export default {

    data() {
        return {
            entrance: '',
            ip: '',
            input: '',
            pageSize: 10,
            memoryColors: '#FEC16D',
            cpuColors: '#1385FF',
            diskTotal: '50',//磁盘总数
            cpuTotal: '',//cpu总数
            fileTotal: '',//文件总数
            portTotal: '',//网口总数
            coreTotal: '',//核总数
            processTotal: '',//进程总数

            currentDiskPage: '',//disk表格页码
            currentCPUPage: '',//CPU表格页码
            currentFilePage: '',//文件表格页码
            currentPortPage: '',//网口表格页码
            currentCorePage: '',//核表格页码
            currentProcessPage: '',//进程表格页码

            disktableData: [],//磁盘            
            cputableData: [],// 核            
            filetableData: [],// 文件            
            porttableData: [],// 网口            
            coretableData: [],// 核            
            processtableData: [ ]//进程

        };
    },
    created() {
        this.updateData();
        this.searchCPUForm();
        this.searchCoreForm();
        this.searchDiskForm();
        this.searchFileForm();
        this.searchPortForm();
        this.searchProcessForm();
    },
    watch: {
        $route: {
            handler(route) {
                console.log('watch当前路由信息', route);
                console.log('watch当前路由参数', route.query);
                this.updateData();
            },
            immediate: true
        }
    },

    mounted() {
        window.addEventListener("keydown", this.handleSearch);
        console.log("初始化");
        this.updateData();// 初始化时获取一次参数

    },
    destroyed() {
        window.removeEventListener("keydown", this.handleSearch, false); //销毁回车事件，如果不销毁，在其他页面敲回车也会执行回车登录操作。
    },

    methods: {
        //获取传递的参数
        updateData() {
            this.entrance = this.$route.query.entrance || '';
            this.ip = this.$route.query.ip || '';
            console.log("调用updateData");
        },
        // 查询磁盘
        async searchDiskForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentDiskPage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.disktableData = res.content.data;
                this.diskTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["diskTable"].doLayout();
                });
            }
        },
        //磁盘分页
        handleCurrentChange1(val) {
            this.currentDiskPage = val;
            this.searchDiskForm();
        },
        // 查询CPU
        async searchCPUForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentCPUPage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.cputableData = res.content.data;
                this.cpuTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["cpuTable"].doLayout();
                });
            }
        },
        //CPU分页
        handleCurrentChange2(val) {
            this.currentCPUPage = val;
            this.searchCPUForm();
        },


        // 查询文件
        async searchFileForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentFilePage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.filetableData = res.content.data;
                this.fileTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["fileTable"].doLayout();
                });
            }
        },
        //文件分页
        handleCurrentChange3(val) {
            this.currentFilePage = val;
            this.searchFileForm();
        },


        // 查询网口
        async searchPortForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentPortPage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.porttableData = res.content.data;
                this.portTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["portTable"].doLayout();
                });
            }
        },
        //端口分页
        handleCurrentChange4(val) {
            this.currentPortPage = val;
            this.searchPortForm();
        },


        // 查询核
        async searchCoreForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentCorePage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.coretableData = res.content.data;
                this.coreTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["coreTable"].doLayout();
                });
            }
        },
        //核分页
        handleCurrentChange5(val) {
            this.currentCorePage = val;
            this.searchCoreForm();
        },


        // 查询进程指标
        async searchProcessForm() {
            // 列表初始,传参列表
            let list = {
                page: this.currentProcessPage,
                size: this.pageSize//pagesize固定10
            };
            const { data: res } = await this.$http.get("/tq/m3/xxx", { params: list });
            if (res.code == 200) {
                //console.log("3333");
                this.processtableData = res.content.data;
                this.processTotal = res.content.total;
                console.log(res.content.total);
                this.$nextTick(() => {
                    //在数据加载完，重新渲染表格                    
                    this.$refs["processTable"].doLayout();
                });
            }
        },
        //文件分页
        handleCurrentChange6(val) {
            this.currentCorePage = val;
            this.searchProcessForm();
        },




        // 返回上一级
        goBackHost() {
            return this.$router.push("/abnormalHost");
        },
    },

}


</script>
<style>
.main {
    padding: 0 20px 20px 20px;
}

.search {
    width: 97%;
    margin: 0 auto;
}

.shadow-div {

    background-color: white;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 30px;

}

.block {
    padding-bottom: 20px;
    /* padding-top: 20px; */
}

.client-device {
    font-family: Microsoft YaHei;
    font-size: 16px;
    font-weight: 700;
    line-height: 22px;
    text-align: center;
    color: #1A49AA;
    /* margin-left: 24px; */
}

.client-device-num {
    font-family: Microsoft YaHei;
    font-size: 16px;
    font-weight: 400;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;

}

/* 进程 */
.process-info {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 400;
    line-height: 22px;
    text-align: center;
}

.process-info-num {
    font-family: Microsoft YaHei;
    font-size: 14px;
    font-weight: 500;
    line-height: 22px;
    text-align: center;
    margin-right: 24px;
    color: #19855A;

}

.region-header {
    height: 40px;
    font-family: "Microsoft YaHei";
    /* font-style: normal; */
    font-weight: 700;
    font-size: 26px;
    line-height: 18px;
    align-items: center;

    padding-left: 10px;
    /* margin-bottom: 20px; */
    /* border-bottom: 1px solid #dedede; */
}

.small-region-header {
    height: 40px;
    font-family: "Microsoft YaHei";
    /* font-style: normal; */
    font-weight: 600;
    font-size: 20px;
    line-height: 18px;
    align-items: center;
    padding-left: 10px;
}

.small-region {
    display: inline-block;
    width: 50%;
    padding: 10px;

}

/* 是否标签 */

.istrue {
    color: #56AB61;
    background-color: rgba(224, 255, 208, 0.94);
    width: 30px;
    height: 27px;
    line-height: 27px;
    display: inline-block;
    border-radius: 4px;
}

.isfalse {
    color: #E2250F;
    background-color: rgba(226, 37, 15, 0.25);
    width: 30px;
    height: 27px;
    line-height: 27px;
    display: inline-block;
    border-radius: 4px;
}

/* 表格边距 */
.el-table th.el-table__cell>.cell {
    padding-left: 0px;
    padding-right: 0px;
}

/* 面包屑 */
.el-breadcrumb__item:first-child .el-breadcrumb__inner {
    color: black !important;
}

.el-breadcrumb__item:last-child .el-breadcrumb__inner {
    color: #1675d5;
}

/* 返回上一级 */
.host-go-back {
    font-family: "Microsoft YaHei";
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
    color: #1675d5;
    float: right;
    margin-top: -15px;
    cursor: pointer;


    i {
        font-weight: 400;
        font-size: 14px;
        line-height: 22px;
        color: #1675d5;
    }
}

.piechartName {
    display: block;
    font-weight: 400;
    font-size: 14px;
    margin-top: 10px;
}

/* 网络指标进度条 */
.process-header {
    height: 24px;
    font-family: "Microsoft YaHei";
    font-size: 14px;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}

.host-process,
.other-process,
.comm-process {
    padding-left: 15px;
}

.host-process .el-progress-bar__inner {
    background-color: #FDB97A;

}

.other-process .el-progress-bar__inner {
    background-color: #1385FF;
}

.comm-process .el-progress-bar__inner {
    background-color: #DC3545;
}

.el-progress-bar__outer {
    height: 8px !important
}
</style>