<template>
    <div class="main" style="background-color: #eff3fe;">
        <div style="padding: 10px;">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>实时告警</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="shadow-div">
            <div class="region-header">DDOS攻击告警</div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>

        </div>
        <div class="shadow-div">
            <div class="region-header">边界渗透告警</div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>
            <div class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>单局点封堵流量异常：北京电信163亦庄，流量值为：59.99Mbps；可疑的域名为：www.xxxxcom,www.xxxxcom,www.xxxxcom.</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        2023-05-01 09:00:05
                    </el-col>
                </el-row>
            </div>

        </div>
        <div class="shadow-div">
            <div class="region-header">主机异常行为告警</div>
            <div v-for="(alarm, index) in alerts" :key="index" class="alarmregion">
                <el-row :gutter="20" type="flex" align="middle">
                    <el-col :span="21" class="messcol">
                        <span>{{ alarm.type }}:{{ alarm.msg }}</span>
                    </el-col>
                    <el-col :span="3" class="timecol">
                        {{ alarm.time }}
                    </el-col>
                </el-row>
            </div>

        </div>
    </div>
</template>

<script>


export default {

    data() {
        return {
            alerts: []
        };
    },
    created() {
        if (this.$route.query.from == 'update') { //获取浏览器url的参数，from页面来源: table客户端列表页面，update更新客户端信息页面 
            this.currentPage = parseInt(this.$route.query.page); //请求对应的页码数据
            this.pageSize = parseInt(this.$route.query.pageSize);
        }
        // this.hostList(); //初始化表格
        this.alertMessage();

    },
    methods: {
        //查询主机警告
        async alertMessage() {
            // 列表初始
            const { data: res } = await this.$http.get("/tq/m3/host_alert");
            if (res.code == 200) {
                console.log("res.code == 200");
                this.alerts = res.content.alerts;
            }
        },

    },

}
</script>
<style>
.main {
    padding: 0 20px 20px 20px;
}


.shadow-div {
    background-color: white;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;

}

.region-header {
    height: 40px;
    font-family: "Microsoft YaHei";
    /* font-style: normal; */
    font-weight: 700;
    font-size: 24px;
    line-height: 18px;
    align-items: center;
    padding-left: 10px;
    color: #3d3d3d;
    margin-bottom: 15px;
    margin-top: 10px;
    /* margin-bottom: 20px; */
    /* border-bottom: 1px solid #dedede; */
}

/* 消息 */
.alarmregion .el-row {
    background-color: rgba(243, 246, 255, .8);
    padding: 10px;
    border-radius: 5px;
    /* position: relative; */
}

.messcol {
    color: #414142;

}

.timecol {
    font-size: 14px;
    font-weight: 400;
    color: #999999;
    text-align: center;
    height: 100%;
    padding: 0 !important;
}

.alarmregion {
    margin-bottom: 20px;
    border-color: #414142;
    /* box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1) */
}

.warningtype {
    color: red;
}
</style>